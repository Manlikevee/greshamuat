import { format } from "date-fns"

export const formatString = (string) => {



    const formatedNumber = new Intl.NumberFormat('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(string)
    return formatedNumber
}

export const formatedBalance = (string) => {
    return (
        <> <sup><del className="decoration-double text-2xl">N</del></sup> {string.toLocaleString('en-US').split('.')[0]}.<span className="self-end text-2xl">{string.toString().split('.')[1]}</span> </>
    )
}

export const formatDate = (string, seperator) => {
    if (!seperator) {
        console.log("you need to specify a seperator in formatDate")
    }

    if (string) {
        const formattedDate = format(new Date(string), `dd${seperator}MM${seperator}yyyy`)
        return formattedDate
    }

}