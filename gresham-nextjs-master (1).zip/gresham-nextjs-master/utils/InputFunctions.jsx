export const handleSelect = (label, value, setFormData) => {
    setFormData((prev) => ({
        ...prev,
        [label]: value,
    }))

}

export const handleChange = (e, setFormData) => {
    setFormData((prev) => ({
        ...prev,
        [e.target.name]: e.target.value
    }))
}
export const handleNoChange = (e, setFormData) => {
    const numOnly = e.target.value.replace(/[^0-9]/g, '');

    setFormData((prev) => ({
        ...prev,
        [e.target.name]: numOnly
    }))
}

export const handleDateChange = (dateName, setFormData, startDate) => {
    setFormData((prev) => ({
        ...prev,
        [dateName]: startDate,

    }))
}

export const handlePhoneNoChange = (label, value, setFormData) => {
    setFormData((prev) => ({
        ...prev, [label]: value
    }))
}