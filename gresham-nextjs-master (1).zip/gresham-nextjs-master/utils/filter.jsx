export const getRelevantData = (allFields, initData) => {


    const relevantData = Object.keys(allFields).reduce((acc, key) => {


        if (initData && key in initData) {
            acc[key] = initData[key]
        }
        return acc
    }, {});



    if (Object.keys(relevantData).length) {
        return relevantData
    }


}