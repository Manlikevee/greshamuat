import { Success } from "@/components/modals/Modal"
import { validationSchema } from "./validationSchema"

export const validateInput = (data) => {
    const errors = {}

    Object.keys(validationSchema).forEach((field) => {
        const value = data[field]
        const rule = validationSchema[field]

        if (rule.required && !value) {
            errors[field] = rule.message.required
        }
        else if (rule.minLength && (value.length < rule.minLength)) {
            errors[field] = rule.message.minLength
        } else if (rule.exactLength && (value.length !== rule.exactLength)) {
            errors[field] = rule.message.exactLength
        }
        else if (rule.pattern && !rule.pattern.test(value)) {
            errors[field] = rule.message.pattern
        }
    })

    return errors
}


export const validateForm = (data, setError, SuccessFunc) => {
    const errors = validateInput(data)
    const relevantError = Object.keys(data).reduce((acc, key) => {
        if (key in errors) {
            acc[key] = errors[key]
        }
        return acc
    }, {});

    if (Object.keys(relevantError).length > 0) {
        setError(relevantError)
        window.scrollTo(0, 0)
    } else {
        SuccessFunc()
    }
}

