export const validationSchema = {
    title: {
        required: true,
        message: {
            required: "Please select a title"
        }

    },
    firstName: {
        required: true,
        minLength: 2,
        message: {
            required: "First Name is required",
            minLength: "First Name must contain at least two characters"
        }
    },
    middleName: {
        required: true,
        minLength: 2,
        message: {
            required: "First Name is required",
            minLength: "First Name must contain at least two characters"
        }
    },
    lastName: {
        required: true,
        minLength: 2,
        message: {
            required: "Last Name is required",
            minLength: "Last Name must contain at least two characters"
        }
    },
    email: {
        required: true,
        pattern: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
        message: {
            required: "Email is required",
            pattern: "Email is invalid please try again"
        }
    },
    password: {
        required: true,
        pattern: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
        message: {
            required: "Password is required",
            pattern: "Password must at least 8 characters long, and contain small letter, capital letter, special character"
        }
    },
    confirmPassword: {
        required: true,
        validate: (value, { password }) => value === password,
        message: {
            required: "Please retype password",
            validate: "password do not match"
        }
    },

    phoneNo: {
        required: true,
        message: {
            required: "Phone No is required",
        }
    },
    dob: {
        required: true,
        message: {
            required: "Please enter your date of birth",
        }
    },

    nin: {
        required: true,
        exactLength: 11,
        message: {
            required: "Please enter your NIN number",
            exactLength: "NIN must be 11 digits long"
        }
    },
    maritalStatus: {
        required: true,
        message: {
            required: "Please select marital status",
        }
    },
    sex: {
        required: true,
        message: {
            required: "Please select Gender",
        }
    },
    nationality: {
        required: true,
        message: {
            required: "Please select a nationality"
        }
    },
    country: {
        required: true,
        message: {
            required: "Please select a country"
        }
    },
    risk: {
        required: true,
        message: {
            required: "Please select Risk tolerance level"
        }
    },
    state: {
        required: true,
        message: {
            required: "Please select a state"
        }
    },
    stateOfOrigin: {
        required: true,
        message: {
            required: "Please select a state of Origin"
        }
    },
    lga: {
        required: true,
        message: {
            required: "Please select LGA"
        }
    },
    religion: {
        required: true,
        message: {
            required: "Please select a religion"
        }
    },
    mothersMaidenName: {
        required: true,
        message: {
            required: "Mothers Maiden name is required"
        }
    },
    residentAddress: {
        required: true,
        message: {
            required: "Resident Address is required"
        }
    },
    nearestLandmark: {
        required: true,
        message: {
            required: "Nearest Landmark is required"
        }
    },
    id: {
        required: true,
        message: {
            required: "Please select a means of identification"
        }
    },
    idNo: {
        required: true,
        message: {
            required: "ID number is required"
        }
    },
    parentName: {
        required: true,
        message: {
            required: "Parent Name is required"
        }
    },
    parentPhoneNo: {
        required: true,
        message: {
            required: "Please enter Parent or Guardian Phone Number"
        }
    },
    parentEmail: {
        required: true,
        pattern: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
        message: {
            required: "Email is required",
            pattern: "Email is invalid please try again"
        }
    },
    parentOccupation: {
        required: true,
        message: {
            required: "Enter Parent or Guardian Occupation"
        }
    },
    parentEmployer: {
        required: true,
        message: {
            required: "Parent or Guardian Employers Name is required"
        }
    },
    parentSourceOfIncome: {
        required: true,
        message: {
            required: "Enter Parent or Guardian Source of Income"
        }
    },
    investmentObjective: {
        required: true,
        message: {
            required: "Investment Objective is required"
        }
    },
    jobTitle: {
        required: true,
        message: {
            required: "Enter Job Title"
        }
    },
    officeAddress: {
        required: true,
        message: {
            required: "Enter Office Address"
        }
    },
    sourceOfIncome: {
        required: true,
        message: {
            required: "Select Source of Income"
        }
    },
    workSector: {
        required: true,
        message: {
            required: "Please Select Work Sector"
        }
    },
    parentOfficeAddress: {
        required: true,
        message: {
            required: "Please enter Parent or Guardian Office Address"
        }
    },
    bankName: {
        required: true,
        message: {
            required: "Select Bank Name"
        }
    },
    accountName: {
        required: true,
        message: {
            required: "This field is required"
        }
    },
    accountNo: {
        required: true,
        exactLength: 10,
        message: {
            required: "Enter Account Number",
            exactLength: "Account Number must be only 10 digits"
        }
    },
    bvn: {
        required: true,
        exactLength: 11,
        message: {
            required: "Enter Bank Verification Number",
            exactLength: "BVN must be only 11 digits"
        }
    },
    nokFirstName: {
        required: true,
        message: {
            required: "Next of Kin's First Name is required"
        }
    },
    nokLastName: {
        required: true,
        message: {
            required: "Next of Kin's Last Name is required"
        }
    },
    nokEmail: {
        required: true,
        pattern: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,

        message: {
            required: "Next of Kin's Email is required",
            pattern: "Email is invalid please try again"

        }
    },
    nokPhoneNo: {
        required: true,
        message: {
            required: "Next of Kin's Phone Number is required"
        }
    },
    nokAddress: {
        required: true,
        message: {
            required: "Next of Kin's Address is required"
        }
    },
    jointName: {
        required: true,
        minLength: 2,
        message: {
            required: "First Name is required",
            minLength: "First Name must contain at least two characters"
        }
    },

}