
"use client"

import { createContext, useState } from "react"

export const PopUpContext = createContext()

export const PopUpProvider = ({ children }) => {
    const [popupOpen, setPopupOpen] = useState(false)

    return (
        <PopUpContext.Provider value={{ popupOpen, setPopupOpen, }}>
            {children}
        </PopUpContext.Provider>
    )

}

