"use client"

import { createContext, useState } from "react"


export const DataStoreContext = createContext()

export const DataStoreProvider = ({ children }) => {
    const [formData, setFormData] = useState(null)
    const [formName, setFormName] = useState("Form Name")

    return (
        <DataStoreContext.Provider value={{ formData, setFormData, formName, setFormName }}>
            {children}
        </DataStoreContext.Provider>
    )

}

