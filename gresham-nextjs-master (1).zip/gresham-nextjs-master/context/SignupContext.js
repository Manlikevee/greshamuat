"use client"
import { createContext, useEffect, useState } from "react"

export const SignupContext = createContext()

export const SignupProvider = ({ children }) => {

    let signupInfo

    if (typeof window !== "undefined") {

        signupInfo = JSON.parse(sessionStorage.getItem("signupData")) || {
            firstName: "",
            lastName: "",
            email: "",
            password: "",
            bvn: "",
            phoneNo: "",
            customerType: "individual",
        }
    }




    const [signupData, setSignupData] = useState(signupInfo)




    useEffect(() => {
        if (typeof window !== "undefined") {
            sessionStorage.setItem("signupData", JSON.stringify(signupData))
        }
    }, [signupData])

    return (
        <SignupContext.Provider value={{ signupData, setSignupData }}>
            {children}
        </SignupContext.Provider>
    )
}