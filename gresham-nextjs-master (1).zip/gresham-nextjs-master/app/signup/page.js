
import AuthLayout from "@/components/layout/auth/AuthLayout"
import dynamic from "next/dynamic"


const SignupForm = dynamic(() => import("@/components/layout/auth/SignUpForm"), { ssr: false })

const Signup = () => {

    return (
        <AuthLayout>
            <SignupForm />
        </AuthLayout>
    )

}

export default Signup

// devops@issl.ng