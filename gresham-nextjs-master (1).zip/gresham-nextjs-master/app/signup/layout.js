"use client"
import { SignupProvider } from "@/context/SignupContext"
import { useSearchParams } from "next/navigation"



const SignupLayout = ({ children }) => {

    return (
        <SignupProvider>
            {children}
        </SignupProvider>


    )
}

export default SignupLayout