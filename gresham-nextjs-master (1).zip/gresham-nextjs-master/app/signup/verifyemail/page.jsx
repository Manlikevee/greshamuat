"use client"
import logo from "@/assets/greshamw.svg"
import { VerificationFailModal, VerificationSuccessModal } from "@/components/modals/VerificationModal"
import { Button } from "@/components/ui/Button"
import usePopup from "@/hooks/usePopup"
import useSignupData from "@/hooks/useSignupData"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { useState } from "react"
import toast, { Toaster } from "react-hot-toast"

const VerifyEmail = () => {
    const notify = (type, message) => {
        toast[type](message)
    }
    const [otp, setOtp] = useState('')
    const [errMsg, setErrMsg] = useState("")
    const [isloading, setIsLoading] = useState(false)
    const [isSendingCode, setIsSendingCode] = useState(false)
    const [path, setPath] = useState("")
    const [isVerified, setIsVerified] = useState(false)
    const [errorMsg, setErrorMsg] = useState(<> Your Email couldn't be verified! <br /> Kindly try again!
    </>)
    const router = useRouter()


    const { signupData } = useSignupData()
    const { openPopup, closePopup, popupOpen } = usePopup()
    const sendableData = signupData ? Object.fromEntries(
        Object.entries(signupData).filter(([key, value]) => key !== "confirmPassword")
    ) : {}


    const sendOTP = async () => {
        try {
            setIsSendingCode(true)
            const res = await fetch("/api/send-otp", {
                method: "POST",
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ email: signupData.email })
            })
            const result = await res.json()

            if (result.status === 500) {
                notify("error", "No internet connection")

            }

        } catch (err) {
            notify("error", "No internet connection")

        } finally {
            setIsSendingCode(false)
        }

    }

    const verifyOtp = async () => {

        if (!otp) {
            setErrMsg("Kindly enter OTP sent to your mail")
            return
        } else if (otp.length !== 6) {
            setErrMsg("OTP must be Six(6) digits")
            return
        }

        try {
            setIsLoading(true)
            setErrMsg("")

            const res = await fetch("/api/verify-otp", {
                method: "POST",
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ otp: otp, email: signupData.email })
            })
            // const result = await res.json()
            if (res.status === 200) {
                try {
                    const res = await fetch("/api/signup", {
                        method: "POST",
                        headers: {
                            'Content-Type': "appplication/json"
                        },
                        body: JSON.stringify(sendableData)
                    })

                    if (res.status === 201) {
                        setIsVerified(true)
                        openPopup()
                        setPath("/")
                    } else if (res.status === 409) {
                        setErrorMsg("This email is already registered to another user. Please log in or Sign up with a different email")
                        setIsVerified(false)
                        openPopup()
                        setPath("/")
                    }

                } catch (err) {
                    console.log(err)
                }


            } else {
                setIsVerified(false)
                openPopup()
                setErrorMsg("The OTP you entered is invalid. Please check and try again, or request a new one if needed")
            }

        } catch (err) {
            notify("error", "No internet connection")

        }
        finally {
            setIsLoading(false)
        }
    }





    const handleChange = (e) => {
        const num = e.target.value
        const number = num.replace(/[^0-9]/g, "")

        setOtp(number)
    }

    const handleRedirect = () => {
        closePopup()
        router.push(path)
    }


    return (
        <div className="bg-gray-200 grid place-content-center h-screen w-screen">
            <Toaster />
            <div className="bg-basered w-fit mx-auto py-3 px-8 rounded-t-lg">
                <Image src={logo} width={100} alt="gresham logo" />
            </div>
            <div className="bg-[#f6f6f6] w-[24rem] p-8 text-center grid rounded-xl">
                <p className="text-lg mb-8 font-medium">Email Verification</p>

                <p className="text-sm text-black/80 mb-4">A Six(6) digit code has been sent to the <br />email address you provided</p>
                <div className=" mb-6">

                    <input onChange={(e) => handleChange(e)} maxLength={6} value={otp} type="text" className="py-3 outline-none shadow-[5px_5px_10px_rgba(0,0,0,0.05)] bg-white px-6 w-full placeholder:text-gray-400 rounded-md" placeholder="Enter verification code" />


                    <p className="text-start text-xs pt-1 pl-1 text-red-500">{errMsg}</p>
                    <div className="flex text-sm mt-2 justify-between">
                        <p>Didn't get the code?</p>
                        <p onClick={sendOTP} className="text-baseblue cursor-pointer">
                            {isSendingCode ? <span className="animate-pulse">Resending...</span> : "Resend Code"}</p>
                    </div>


                </div>
                <Button onClick={() => verifyOtp()} type={"black"} className={"w-full"}>{isloading ? <span className="animate-pulse"> Verifying...</span> : "Verify"}</Button>


            </div>

            {
                popupOpen && <div>
                    {isVerified
                        ? <VerificationSuccessModal clickFunc={handleRedirect} />
                        : <VerificationFailModal errormessage={<div>{errorMsg}</div>} clickFunc={handleRedirect} />
                    }

                </div>


            }


        </div>
    )
}

export default VerifyEmail