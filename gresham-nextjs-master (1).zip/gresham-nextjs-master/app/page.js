"use client"
import LoginForm from "@/components/layout/auth/LoginForm"
import AuthLayout from "@/components/layout/auth/AuthLayout"

const Login = () => {
  return (
    <AuthLayout>
      <LoginForm />
    </AuthLayout>


  )
}

export default Login