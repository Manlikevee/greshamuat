import "./globals.css";
import Header from "@/components/layout/Header";
import { PopUpProvider } from "@/context/PopUpContext";
import { DataStoreProvider } from "@/context/DataStoreContext";

export const metadata = {
  title: "Gresham",
  description: "Gresham an investment platform",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="font-[Urbanist] max-w-[100vw] bg-[#f1f1f1] h-full min-h-screen antialiased">
        <PopUpProvider>
          <DataStoreProvider>
            {children}
          </DataStoreProvider>
        </PopUpProvider>

      </body>
    </html>
  );
}

