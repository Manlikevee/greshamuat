"use client"
import GeneralFormLayout from "@/components/layout/GeneralFormLayout"
import InvestSummary from "@/components/layout/InvestSummary"
import { SuccessModal } from "@/components/modals/Modal"
import usePopup from "@/hooks/usePopup"
import { useFormData } from "@/hooks/useStore"
import { formatDate, formatString } from "@/utils/FormatString"
import { redirect } from "next/navigation"
import { useEffect, useState } from "react"

const FixedDepositSummary = () => {
    const { popupOpen, openPopup, closePopup } = usePopup()
    const [storedData, setStoredData] = useState()

    useEffect(() => {
        if (window !== "undefined") {
            setStoredData(JSON.parse(localStorage.getItem("investData")))
        }
    }, [])

    console.log(storedData)
    return (

        <GeneralFormLayout formName={storedData?.productType}>
            <InvestSummary investType={storedData?.productType} onClick={() => { openPopup() }}>
                <li>Principal - <span className="text-baseblue">₦ {formatString(storedData?.amount)}</span></li>
                <li>Effective Date - <span className="text-baseblue">{formatDate(storedData?.effectiveDate, '-')} </span></li>
                <li>Tenure - <span className="text-baseblue">{storedData?.tenor} days</span></li>
                <li>Interest Rate - <span className="text-baseblue">{storedData?.interestRate}%</span></li>
                <li>Maturity Date - <span className="text-baseblue"> {formatDate(storedData?.maturityDate, '-')} </span></li>
                <li>Interest Payable at Maturity - <span className="text-baseblue"> <span>₦ </span> {formatString(storedData?.payableInterest)}</span></li>
                <li>Total Payable at Maturity - <span className="text-baseblue"> ₦  {formatString(storedData?.payableAtMaturity)}</span></li>
            </InvestSummary>


            {
                popupOpen && < SuccessModal
                    message={"Your Investment request for a Fixed Deposit was successfully submitted. "}
                    header={"Successful"}
                    path={"/"}
                    clickFunc={() => { closePopup() }}
                />
            }



        </GeneralFormLayout>

    )
}

export default FixedDepositSummary