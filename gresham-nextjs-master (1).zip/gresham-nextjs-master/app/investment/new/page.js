"use client"
import FixedDepositForm from "@/components/formComponents/FixedDepositForm"
import GeneralFormLayout from "@/components/layout/GeneralFormLayout"
import { useEffect, useState } from "react"

// const FixedDepositForm = import 



const page = () => {

    const [startDate, setStartDate] = useState(new Date())

    const [formData, setFormData] = useState({
        tenor: 140,
        effectiveDate: startDate,


    })
    const [isMount, setIsMount] = useState(false)

    useEffect(() => {
        if (typeof window !== "undefined") {
            setFormData(JSON.parse(localStorage.getItem("investData")))
        }
    }, [])

    useEffect(() => {
        if (typeof window !== "undefined" && isMount) {
            localStorage.setItem("investData", JSON.stringify(formData))
        }

        setIsMount(true)
    }, [formData])
    return (
        <>
            <GeneralFormLayout formName={formData?.productType}>
                <FixedDepositForm formData={formData} setFormData={setFormData} startDate={startDate} setStartDate={setStartDate} />

            </GeneralFormLayout>

        </>
    )
}


export default page