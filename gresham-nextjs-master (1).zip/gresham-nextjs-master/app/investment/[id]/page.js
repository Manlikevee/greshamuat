"use client"

import React, { useEffect, useState } from 'react'
import { investment } from '@/utils/constants'
import InvestHead from '@/components/layout/InvestHead'
import { bonds, investmentInstruments } from '@/data/data'
import BondsCard from '@/components/cards/BondsCard'
import TreasuryCard from '@/components/cards/TreasuryCard'
import { userFormData } from '@/hooks/useFormData'
import { useRouter } from 'next/navigation'


const page = async ({ params }) => {
    const product = investment.filter(deal => deal.type === params.id)[0]
    const deal = investmentInstruments[params.id]
    const navigate = useRouter()



    const handleClick = (data) => {
        localStorage.setItem("investData", JSON.stringify(data))
        navigate.push('/investment/new')
    }
    return (


        <div className='grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:flex xl:flex-wrap gap-4 my-16'>
            {
                deal.map((card, index) => {
                    const cardData = {
                        productName: card.name,
                        productType: card.productType,
                        value: card.value,
                        interestRate: card.rate
                    }

                    return (
                        <TreasuryCard
                            key={index}
                            name={card.name}
                            rate={card.rate}
                            maturity={card.maturity}
                            yieldValue={card.yieldValue}
                            onClick={() => { handleClick(cardData) }}
                        />
                    )

                })
            }

        </div>




    )
}


export default page