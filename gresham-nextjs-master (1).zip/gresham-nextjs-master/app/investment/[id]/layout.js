import InvestHead from "@/components/layout/InvestHead"
import { investment } from "@/utils/constants"
import Link from "next/link"


const InvestLayout = ({ children, params }) => {
    const product = investment.filter(deal => deal.type === params.id)[0]

    return (
        <div>
            <InvestHead
                investName={product.name}
                investType={product.name}
                investDescription={product.description}
            />

            <ul className="flex gap-4  overflow-auto pt-8 pb-6">
                {
                    investment.map((item, index) => {
                        return (

                            <>
                                <li key={index} >
                                    <Link href={item.link} className={`${product.name === item.name ? "bg-baseblue text-white" : "bg-white"} whitespace-nowrap shadow-md rounded-md px-4 py-3`}>
                                        {item.name}

                                    </Link>

                                </li>

                            </>

                        )
                    })
                }

            </ul>
            {children}
        </div>
    )
}

export default InvestLayout