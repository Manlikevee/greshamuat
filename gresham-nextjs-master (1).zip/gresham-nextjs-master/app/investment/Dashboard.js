"use client"

import BalanceCard from "@/components/cards/BalanceCard"
import { BalanceCardNames } from "@/data/data"
import usePopup from "@/hooks/usePopup"
import NoInvestment from "../../components/layout/dashboard/NoInvestment"
import { Button } from "@/components/ui/Button"
import AccountCard from "@/components/cards/AccountCard"
import ProfileUpdateModal from "@/components/modals/ProfileUpdateModal"
import { formatedBalance } from "@/utils/FormatString"
import { FaPlus } from "react-icons/fa6"
import { format } from "date-fns"
import { Carousel } from "@/components/carousel/Carousel"
import { useState } from "react"
import InvestmentModal from "@/components/modals/InvestmentModal"





const Dashboard = ({ userData }) => {

    const [newUser, setNewUser] = useState(true)
    const { openPopup, popupOpen, closePopup } = usePopup()




    let totalBalance = 0

    if (userData) {
        userData.forEach((item) => {
            totalBalance += item.amountPayable
        })
    }

    const renderSlide = (card, index) => (

        <BalanceCard
            totalText={card}
            value={
                index === 0 ? formatedBalance(totalBalance)
                    : index === 1 ? formatedBalance(totalBalance)
                        : userData?.length || 0
            }
            firstIndex={index === 0 && true}
        />
    )



    return (
        <div >
            <h1 className="headText mb-6  font-bold mt-2 lg:mt-[51px]">Investment</h1>

            <div className="w-full mb-8">
                <Carousel slides={BalanceCardNames} renderSlide={renderSlide} />
            </div>


            <div className=" flex flex-wrap items-end justify-between gap-4 mb-10">
                <div>
                </div>

                <Button className={"w-fit"} onClick={openPopup} type={"blue"}>
                    <FaPlus />
                    Add Investment
                </Button>

            </div>

            {
                (userData?.length === 0 || !userData)
                    ? <NoInvestment /> :
                    <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6 flex-wrap">
                        {
                            userData?.map((card) => (
                                <AccountCard
                                    key={card.dealNo}
                                    name={card.dealTypeName}
                                    accountNo={`#${card.accountNo}`}
                                    principal={card.principal}
                                    maturityDate={
                                        format(card.maturityDate, " dd/MM/yyyy")
                                    }
                                    interest={card.interestRate}
                                    path={`/investment/info/${card.dealNo}`}

                                />
                            ))

                        }



                    </div>
            }

            {
                popupOpen && <>
                    {
                        newUser ? <ProfileUpdateModal
                            clickFunc={() => { closePopup, setNewUser(false) }} />
                            : <InvestmentModal clickFunc={() => { closePopup() }} />
                    }

                </>
            }
        </div >
    )
}

export default Dashboard
