import { Button } from "@/components/ui/Button"
import { formatDate, formatString } from "@/utils/FormatString"

const getData = async () => {

    try {
        const res = await fetch("http://api.issl.ng:7777/ibank/api/v1/customermmdeals/00348", {
            headers: {
                'Content-Type': 'application/json',
                'X-TENANTID': 'crystalfinanceuat'
            },
        })

        if (!res.ok) {
            throw new Error("failed to fetch data")
        }

        const result = await res.json()
        return result

    } catch (error) {
        console.error
    }

}


const page = async ({ params }) => {
    const userData = await getData()
    const currentDeal = userData?.find(data => data.dealNo === params.id)

    const daysLeft = 40
    const totalDays = currentDeal?.tenor
    const daysCompleted = totalDays - daysLeft
    const percentageCompleted = (daysCompleted / totalDays) * 100


    return (
        <div className="mt-4">
            <p className="text-baseblue font-medium mb-8">#{currentDeal?.accountNo}</p>
            <div className="mb-8 lg:mb-16 xl:mb-20 rounded-md bg-white p-4 lg:bg-transparent lg:p-0">

                <h1 className="text-xl mb-4 font-semibold text-[#737373]">{currentDeal?.dealTypeName}</h1>
                <p className="max-w-[1200px] text-[#737373] ">Welcome to your investment details page for your {currentDeal?.dealTypeName} with Gresham Asset Management Limited. This page provides you with a comprehensive overview of your active {currentDeal?.dealTypeName} investment, allowing you to track its progress and manage your finances effectively.</p>
            </div>



            <div className="grid gap-12">
                <div className="grid gap-6 lg:grid-cols-2 lg:content-start">

                    <div className="box-container grid gap-6 w-full lg:content-start" >

                        <div className="bg-white p-4 lg:p-6 rounded-md">

                            <div className=" gap-3 pb-4 border-b border-[#a5abad]">
                                <p className="font-bold text-[#737373]">Account Number</p>
                                <p className="text-baseblue">{currentDeal?.accountNo}</p>
                            </div>

                            <div className="grid gap-3  mt-6 sm:grid-cols-3">

                                <ul className="flex justify-between sm:grid sm:gap-2">
                                    <li className="text-[#737373] font-semibold">Current Principal</li>
                                    <li className="text-baseblue "><del className="decoration-double">N</del> {formatString(currentDeal?.netAmountPayable)}</li>
                                </ul>

                                <ul className="flex justify-between sm:grid sm:gap-2">
                                    <li className="text-[#737373] font-semibold"> Principal Amount</li>
                                    <li className="text-baseblue "><del className="decoration-double">N</del> {formatString(currentDeal?.principal)}</li>
                                </ul>
                                <ul className="flex justify-between sm:grid sm:gap-2">
                                    <li className="text-[#737373] font-semibold">
                                        Interest Amount
                                    </li>
                                    <li className="text-baseblue "><del className="decoration-double">N</del> {formatString(currentDeal?.interestPayable)}</li>
                                </ul>

                            </div>

                        </div>



                        <div className="bg-white p-4 lg:p-6 grid gap-3 rounded-md sm:grid-cols-3">

                            <ul className="flex justify-between sm:grid sm:gap-2">
                                <li className="text-[#737373] font-semibold">Tenor</li>
                                <li className="text-baseblue ">
                                    {currentDeal?.tenor} days
                                </li>
                            </ul>

                            <ul className="flex justify-between sm:grid sm:gap-2">
                                <li className="text-[#737373] font-semibold"> Effectivate Date
                                </li>
                                <li className="text-baseblue ">
                                    {formatDate(currentDeal?.effectiveDate, '/')}
                                </li>
                            </ul>
                            <ul className="flex justify-between sm:grid sm:gap-2">
                                <li className="text-[#737373] font-semibold">
                                    Maturity Date
                                </li>
                                <li className="text-baseblue ">
                                    {formatDate(currentDeal?.maturityDate, '/')}
                                </li>
                            </ul>

                        </div>
                    </div>

                    <div className="grid gap-6 lg:content-start ">

                        <div className="bg-white lg:p-6 p-4 grid gap-3 rounded-md sm:grid-cols-3">
                            <ul className="flex justify-between sm:grid sm:gap-2">
                                <li className="text-[#737373] font-semibold">
                                    Interest Rate
                                </li>
                                <li className="text-baseblue ">
                                    {currentDeal?.interestRate}%
                                </li>
                            </ul>
                            <ul className="flex justify-between sm:grid sm:gap-2">
                                <li className="text-[#737373] font-semibold">
                                    Interest Basis
                                </li>
                                <li className="text-baseblue ">
                                    {currentDeal?.rateBasis}
                                </li>
                            </ul>
                            <ul className="flex justify-between sm:grid sm:gap-2">
                                <li className="text-[#737373] font-semibold">
                                    Interest to Date
                                </li>
                                <li className="text-baseblue ">
                                    {formatString(currentDeal?.accruedInterest)}
                                </li>
                            </ul>

                        </div>

                        <div className="bg-white p-4 grid lg:p-6 gap-3 rounded-md">
                            <div className="flex justify-between">
                                <p>Days Left</p>
                                <p className="text-baseblue font-semibold">{daysLeft} days</p>
                            </div>
                            <div className="h-3 p-[1px] w-full bg-[#e5e5e5] mt-1 rounded-xl">
                                <div className="bg-baseblue h-full rounded-xl relative before:inline-block before:w-5 before:h-5 before:bg-white before:border before:border-[#737373] before:absolute before:rounded-full before:top-1/2 before:right-0 before:-translate-y-1/2  "
                                    style={{ width: `${percentageCompleted}%` }}>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="grid gap-3 sm:grid-cols-3 lg:flex lg:justify-end">
                    <Button
                        type={"transparent"}
                        className={"justify-center lg:w-[183px]"}
                    >
                        Top Up
                    </Button>
                    <Button
                        type={"white"}
                        className={"justify-center lg:w-[183px]"}

                    >
                        Roll over
                    </Button>
                    <Button
                        className={"justify-center lg:w-[183px]"}

                    >
                        Liquidate

                    </Button>

                </div>


            </div>
        </div >

    )
}

export default page