import GeneralFormLayout from "@/components/layout/GeneralFormLayout"
import GeneralLayout from "@/components/layout/GeneralLayout"

const ProfileUpdateLayout = ({ children }) => {
    return (
        <GeneralFormLayout formName={"Profile Update"}>
            {children}
        </GeneralFormLayout>

    )
}

export default ProfileUpdateLayout