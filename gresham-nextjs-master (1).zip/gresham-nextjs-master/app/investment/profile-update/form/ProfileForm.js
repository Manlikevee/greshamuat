"use client"
import { forms } from '@/utils/constants'
import { SuccessModal } from '@/components/modals/Modal'
import { Button } from '@/components/ui/Button'
import usePopup from '@/hooks/usePopup'
import { addYears } from 'date-fns'
import { useEffect, useState } from 'react'
import FormPageNo from './FormPageNo'


const ProfileForm = () => {
    const [currentForm, setCurrentForm] = useState(0)
    const { popupOpen, closePopup } = usePopup()
    const [activeId, setActiveId] = useState(null)
    const [validate, setValidate] = useState(false)
    const [files, setFiles] = useState({})
    const [file, setFile] = useState({})
    const [date, setDate] = useState(new Date())
    const [isFileSelected, setIsfileSelected] = useState({
        passportPhoto: false,
        utility: false
    })


    const user = JSON.parse(localStorage.getItem("user"))

    const formType = forms[user?.customerType]
    const customerCategory = formType === "children" ? "C"
        : formType === "estate" ? "E"
            : formType === "joint" ? "J"
                : formType === "cooperate" ? "CO"
                    : "I"
    const formData = JSON.parse(sessionStorage.getItem("formData"))
    const sendableData = {
        "customerType": customerCategory,
        "customerCategory": customerCategory,
        ...formData,
    }

    const passportFormData = new FormData()
    passportFormData.append("file", file.passportPhoto)

    const utilityFormData = new FormData()
    utilityFormData.append("file", file.utility)


    const NextForm = () => {
        setCurrentForm(currentForm + 1)
        window.scrollTo(0, 0)
    }

    const PrevForm = () => {
        setCurrentForm(currentForm - 1)
        window.scrollTo(0, 0)

    }

    let FormComponent
    if (formType) {
        FormComponent = formType[currentForm].component
    }



    const displayForm = () => {

        for (let i = 1; i <= formType?.length; i++) {
            if (formType[currentForm].id === i) {

                return <FormComponent
                    activeId={activeId}
                    setActiveId={setActiveId}
                    NextForm={NextForm}
                    validate={validate}
                    setValidate={setValidate}
                    submitForm={handleSubmit}
                    isFileSelected={isFileSelected}
                    setIsfileSelected={setIsfileSelected}
                    files={files}
                    setFiles={setFiles}
                    file={file}
                    setFile={setFile}

                />
            }
        }

    }


    const handleSubmit = async () => {
        const result = await sendFormData()
        console.log(result)
        const rqid = await result.message.requestId
        await submitPassport(rqid)
        await submitUtility(rqid)
    }

    const sendFormData = async () => {

        const res = await fetch("/api/update-profile", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(sendableData)
        })

        const result = await res.json()
        if (res.status === 200) {
            return result
        } else {
            console.log("didn't upload successfully")
        }

    }

    console.log(file)
    const submitPassport = async (rqid,) => {
        const res = await fetch(`/api/submitkycdoc/passport`, {
            method: "POST",
            body: JSON.stringify({
                rqid: rqid,
                formData: passportFormData
            })

        })
    }

    const submitUtility = async (rqid,) => {
        const res = await fetch(`/api/submitkycdoc/utility`, {
            method: "POST",
            body: JSON.stringify({
                rqid: rqid,
                formData: utilityFormData
            })

        })
    }





    return (
        <div className="p-4 pb-8 md:px-12">
            {
                formType && <FormPageNo
                    formName={formType[currentForm].formName}
                    formNo={formType[currentForm].id}
                    formLength={formType?.length}
                />

            }



            {
                displayForm()
            }



            <div className=" w-full mt-16 grid gap-4 sm:flex sm:justify-between bg-red">
                <div className='w-full sm:-fit'>
                    {currentForm > 0 && <Button className={"w-full sm:w-40 font-bold"} onClick={() => { PrevForm() }} type={"transparent"}>Prev</Button>}
                </div>


                <div className='w-full sm:w-fit'>

                    {
                        currentForm === (formType?.length - 1) ?
                            <Button className={"w-full sm:w-40 font-bold"} onClick={handleSubmit}> Submit </Button>
                            : <Button className={"w-full sm:w-40 font-bold cursor-pointer"} onClick={() => {
                                setValidate(true)
                            }}
                            >
                                Continue
                            </Button>
                    }




                </div>

            </div>

            {
                popupOpen && <SuccessModal
                    clickFunc={closePopup}
                    header={"Profile Updated Successful"}
                    message={<>Your profile information have been submitted successfully, continue to your dashboard to begin your investment journey with Gresham Asset Management Ltd.</>}
                    path={"/"}
                />
            }


        </div >
    )
}

export default ProfileForm



