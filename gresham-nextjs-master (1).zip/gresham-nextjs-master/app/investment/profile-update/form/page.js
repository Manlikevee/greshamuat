import dynamic from "next/dynamic"

const ProfileForm = dynamic(() => import("./ProfileForm"), { ssr: false })
const Forms = () => {
    return (
        <ProfileForm />
    )
}

export default Forms