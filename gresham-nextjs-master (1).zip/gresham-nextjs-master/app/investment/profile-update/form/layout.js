import React from 'react'

const ProfileLayout = ({ children }) => {
    return (
        <div>

            {children}

        </div>
    )
}

export default ProfileLayout