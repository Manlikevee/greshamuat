const FormPageNo = ({ formName, formNo, formLength }) => {


    const totalFormNo = formLength
    const completed = formNo - 1
    const remaining = totalFormNo - formNo




    return (
        <div className="flex justify-between mb-6 ">
            <div className="grid w-full"> {
                completed >= 1 && <>
                    <p className="text-sm"> <strong>Completed {completed}</strong></p>
                    <div className="flex mt-3 relative">
                        <div className="bg-[#e5e5e5] rounded-full w-[45px] h-[45px] grid place-content-center absolute left-0 bottom-0">
                            <p className="bg-[#b6b9bc] text-white h-[35px] w-[35px] grid place-content-center rounded-full">1</p>
                        </div>
                        {
                            completed >= 2 &&
                            <div className="bg-[#e5e5e5] rounded-full w-[45px] h-[45px] grid place-content-center absolute left-[2.15rem] bottom-0">
                                {
                                    completed >= 3 ? <p className="bg-[#b6b9bc] text-white h-[35px] w-[35px] grid place-content-center rounded-full">+{completed - 1}</p> : <p className="bg-[#b6b9bc] text-white h-[35px] w-[35px] grid place-content-center rounded-full">2</p>
                                }

                            </div>
                        }

                    </div>
                </>
            }

            </div>
            <div className="place-items-center text-center grid w-full ">
                <p className=" text-sm max-w-24 sm:max-w-full text-nowrap overflow-hidden text-ellipsis"> <strong>{formName}</strong> </p>
                <div className="flex mt-3">
                    <div className="bg-[#e5e5e5] rounded-full w-[45px] h-[45px] grid place-content-center current">
                        <p className="bg-baseblue text-white h-[35px] w-[35px] grid place-content-center rounded-full">{formNo}</p>
                    </div>
                </div>
            </div>
            <div className="grid w-full text-end">

                {
                    remaining >= 1 && <>
                        <p className=" text-sm ">Remaining {remaining} </p>
                        <div className="flex mt-3 relative ">

                            {remaining >= 2 &&
                                <div className="bg-[#e5e5e5] rounded-full w-[45px] h-[45px] grid place-content-center absolute right-[2.15rem] z-50 bottom-0 ">
                                    {remaining > 1 && <p className="bg-[#b6b9bc] text-white h-[35px] w-[35px] grid place-content-center rounded-full">{formNo + 1}</p>}

                                </div>
                            }

                            <div className="bg-[#e5e5e5] rounded-full w-[45px] h-[45px] grid place-content-center absolute right-0 bottom-0">
                                {remaining > 2 ? <p className="bg-[#b6b9bc] text-white h-[35px] w-[35px] grid place-content-center rounded-full">+{remaining - 1}</p> : <p className="bg-[#b6b9bc] text-white h-[35px] w-[35px] grid place-content-center rounded-full">{formLength}</p>}

                            </div>
                        </div>
                    </>
                }

            </div>
        </div>

    )
}

export default FormPageNo