"use client"

import ChildrenRequirement from "@/components/layout/form/requirement/ChildrenRequirement"
import CorporateRequirement from "@/components/layout/form/requirement/CorporateRequirement"
import EstateRequirement from "@/components/layout/form/requirement/EstateRequirement"
import IndividualRequirement from "@/components/layout/form/requirement/IndividualRequirement"
import JointRequirement from "@/components/layout/form/requirement/JointRequirement"
import { LinkButton } from "@/components/ui/Button"
import { useActiveUser } from "@/hooks/useStore"

const Requirement = () => {

    const { user } = useActiveUser()
    const customerType = user?.customerType || ""


    return (
        <div className="p-4 pb-8 md:px-12 text-black/60">
            <div className="pb-4 border-b border-black/5 mb-4">
                <h1 className="text-xl font-bold">Profile Update Requirement</h1>
            </div>

            {
                customerType === "children" ? <ChildrenRequirement />
                    : customerType === "joint" ? <JointRequirement />
                        : customerType === "estate" ? <EstateRequirement />
                            : customerType === "corporate" ? <CorporateRequirement />
                                : <IndividualRequirement />
            }





            <div className="w-full mt-6  font-semibold">
                <LinkButton
                    path={"profile-update/form"}
                    className={"w-full sm:ml-auto sm:w-[150px]"}
                >
                    Continue
                </LinkButton>
            </div>


        </div>
    )
}

export default Requirement