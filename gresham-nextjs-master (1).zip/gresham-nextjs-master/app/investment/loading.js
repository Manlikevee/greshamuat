

const loading = () => {
    return (
        <div>
            <span class="smooth spinner" ></span>

        </div>
    )
}

export default loading