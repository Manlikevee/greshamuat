import Dashboard from "./Dashboard"

// const getData = async () => {


//     try {
//         const res = await fetch("http://api.issl.ng:7777/ibank/api/v1/customermmdeals/00348", {
//             headers: {
//                 'Content-Type': 'application/json',
//                 'X-TENANTID': 'crystalfinanceuat'
//             },
//         })

//         if (!res.ok) {
//             throw new Error("failed to fetch data")
//         }

//         const result = await res.json()
//         return result

//     } catch (error) {
//         console.error
//     }

// }


const HomePage = async () => {

    const userData = []

    return (
        <Dashboard userData={userData} />
    )
}

export default HomePage