import GeneralLayout from "@/components/layout/GeneralLayout"
import { investment } from "@/utils/constants"

const InvestLayout = ({ children }) => {
    return (
        <GeneralLayout>


            {children}
        </GeneralLayout>
    )
}

export default InvestLayout