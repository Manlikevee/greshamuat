import { NextResponse } from "next/server";

export const POST = async (req) => {
    const body = await req.json()
    const email = body.email
    const otp = body.otp

    try {
        const response = await fetch(`http://api.issl.ng:7777/ibank/api/v1/validateotp/${email}/${otp} `)
        const result = await response.json()
        if (response.ok) {
            if (result.response_code === "00") {
                return NextResponse.json({ message: "Email Successfully verified", }, { status: 200 })
            } else {
                return NextResponse.json({ message: "OTP is invalid" }, { status: 400 })
            }

        } else {
            return NextResponse.json({ message: "OTP is invalid" }, { status: 400 })
        }
    } catch (err) {
        console.error(err)
    }
}