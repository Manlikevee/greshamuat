import { NextResponse } from "next/server";

export const POST = async (req) => {
    const data = await req.json()
    console.log(data)

    try {
        const res = await fetch(`http://api.issl.ng:7777/onboarding-api/1.0/newcustomer2/1/${data.firstName}/${data.lastName}`,
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "X-Tenantid": "greshamuat"
                },
                body: JSON.stringify(data)
            }
        )
        const result = await res.json()
        if (res.status == 200) {
            return NextResponse.json({ message: result }, { status: 200 })
        } else {
            return NextResponse.json({ message: "failed to update profile" }, { status: 500 })

        }
    } catch (error) {
        console.log(error)
        return NextResponse.json({ message: "server Error" }, { status: 500 })

    }

}