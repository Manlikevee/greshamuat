import { NextResponse } from "next/server";

const keycloakUrl = process.env.NEXT_PUBLIC_URL
const realm = process.env.NEXT_PUBLIC_REALM
const clientID = process.env.NEXT_PUBLIC_CLIENTID
const clientSecret = process.env.SECRET_KEY



const urlencoded = new URLSearchParams()
urlencoded.append("client_id", clientID);
urlencoded.append("client_secret", clientSecret);
urlencoded.append("grant_type", "client_credentials");


const getAccessToken = async () => {

    const response = await fetch(
        `${keycloakUrl}/realms/${realm}/protocol/openid-connect/token`,
        {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: urlencoded
        }
    )

    const data = await response.json()
    if (response.ok) {
        return data.access_token
    } else {
        return NextResponse.json({ message: "Failed to generate Access Token" }, { status: 500 })
    }
}


export const POST = async (req) => {
    const user = await req.json()
    const token = await getAccessToken()


    const newUser = {
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        username: `${user.firstName}_${user.lastName}${Math.floor(Math.random() * 9999)}`,
        emailVerified: false,
        enabled: true,
        credentials: [
            {
                type: "password",
                value: user.password,
                temporary: false
            }
        ],
        attributes: {
            customerType: user.customerType,
            phoneNo: user.phoneNo
        }


    }


    // create a user 

    try {
        const response = await fetch(`${keycloakUrl}/admin/realms/${realm}/users`, {
            method: "POST",
            headers: {
                Authorization: `Bearer ${token}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(newUser)
        })
        const data = await response.json()

        if (!response.ok) {
            return NextResponse.json({
                message: data.errorMessage
            }, { status: 409 })

        }
    } catch (error) {
        return NextResponse.json({ message: "user created successfully" }, { status: 201 })
    }



}