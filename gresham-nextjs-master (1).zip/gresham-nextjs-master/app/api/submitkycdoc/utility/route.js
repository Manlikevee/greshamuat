import { addDays, addYears } from "date-fns";
import { NextResponse } from "next/server";

export const POST = async (req) => {
    const data = await req.json()
    const rqid = data.rqid
    const date = new Date()
    const expDate = addDays(date, 1000)

    try {
        const res = await fetch(`http://api.issl.ng:7777/ibank/api/v1/newcustomerv4kycdoc?rqid=${rqid}&kycDocType=utility&docId=utility${rqid}&docIssueDate=${date}&docExpDate=${expDate}`, {
            method: "POST",
            headers: {
                "Content-Type": "multipart/form-data",
                "X-Tenantid": "greshamuat"
            },
            body: JSON.stringify(data.image)
        })
        const result = await res.json()
        if (res.status == 200) {
            return NextResponse.json({ message: result }, { status: 200 })
        } else {
            return NextResponse.json({ message: "failed to upload utility" }, { status: 500 })

        }
    } catch (error) {
        console.log(error)
        return NextResponse.json({ message: "server Error" }, { status: 500 })

    }

}