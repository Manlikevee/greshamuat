import { NextResponse } from "next/server";




const getOtp = async (phoneNo) => {
    try {
        const res = await fetch(`http://api.issl.ng:7777/ibank/api/v1/generateotp?userId=${phoneNo}`);
        const otp = await res.json();
        if (!res.ok) {
            throw new Error(`Failed to generate OTP: ${res.status}`);
        }
        return otp;
    } catch (err) {
        console.error(err);
        return null;
    }
};

export const POST = async (req) => {

    try {
        const data = await req.json();
        const phoneNo = data.phoneNo.replace(/^\+/, "");
        const otp = await getOtp(phoneNo);
        if (!otp) {
            return NextResponse.json({ error: "Failed to generate OTP" }, { status: 500 });
        }
        if (!phoneNo) {
            return NextResponse.json({ error: "Phone Number is Invalid" }, { status: 500 });
        }

        const text = `Your One Time Password(OTP) for Gresham Phone Number Verification is ${otp}`
        const encodedText = encodeURIComponent(text)
        const res = await fetch(`http://api.issl.ng:7777/ibank/api/v1/sendsms?recipient=${phoneNo}&message=${encodedText}`);
        const result = await res.json()
        console.log(result)
        if (res.ok && result.sentOK) {

            return NextResponse.json({ message: "Phone No Verification code sent successfully" }, { status: 200 });
        } else {
            return NextResponse.json({
                message: "Failed to send Phone No verification code"
            }, { status: 500 });
        }
    } catch (error) {
        return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
    }
};