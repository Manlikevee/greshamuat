
import { NextResponse } from "next/server";
import { cookies } from "next/headers";

const keycloakUrl = process.env.NEXT_PUBLIC_URL
const realm = process.env.NEXT_PUBLIC_REALM
const clientID = process.env.NEXT_PUBLIC_CLIENTID
const clientSecret = process.env.SECRET_KEY



const urlencoded = new URLSearchParams()
urlencoded.append("client_id", clientID);
urlencoded.append("client_secret", clientSecret);
urlencoded.append("grant_type", "client_credentials");






const getAccessToken = async () => {

    const response = await fetch(
        `${keycloakUrl}/realms/${realm}/protocol/openid-connect/token`,
        {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: urlencoded
        }
    )

    const data = await response.json()
    if (response.ok) {
        return data.access_token
    } else {
        return NextResponse.json({ message: "Failed to generate Access Token" }, { status: 500 })
    }
}


export const POST = async (req) => {
    const token = await getAccessToken()
    const details = await req.json()


    try {
        const res = await fetch(
            `${keycloakUrl}/realms/${realm}/protocol/openid-connect/token`,
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                body: new URLSearchParams({
                    username: details.email,
                    password: details.password,
                    grant_type: 'password',
                    client_id: clientID,
                    client_secret: clientSecret
                }),
            }
        )

        const data = await res.json()


        if (res.ok) {
            cookies().set("accessToken",
                data.access_token,
                { httpOnly: true, maxAge: 20 * 60, sameSite: "strict", })

            cookies().set("refreshToken",
                data.refresh_token,
                { httpOnly: true, maxAge: 60 * 30, sameSite: "strict", })


            const email = details.email


            try {
                const res = await fetch(`${keycloakUrl}/admin/realms/${realm}/users?email=${encodeURIComponent(email)}`,
                    {
                        method: 'GET',
                        headers: {
                            Authorization: `Bearer ${token}`,
                            'Content-Type': 'application/json',
                        },
                    }
                );

                const user = await res.json()

                if (res.ok) {
                    const activeUser = user[0]
                    const userInfo = {
                        firstName: activeUser.firstName,
                        lastName: activeUser.lastName,
                        email: activeUser.email,
                        customerType: activeUser.attributes.customerType[0],
                        phoneNo: activeUser.attributes.phoneNo[0],
                        id: activeUser.id
                    }
                    return NextResponse.json({
                        message: "Authorised", user: userInfo

                    }, { status: 200 })
                }

            } catch (err) {
                console.log(err)
            }


        } else {
            return NextResponse.json({
                message: "Invalid login details"
            }, { status: 404 })
        }
    } catch (err) {
        return NextResponse.json({
            message: "Internal server Error",
        }, { status: 500 })
    }



}



