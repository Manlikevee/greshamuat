import { NextResponse } from "next/server";

const keycloakUrl = process.env.NEXT_PUBLIC_URL
const realm = process.env.NEXT_PUBLIC_REALM
const clientID = process.env.NEXT_PUBLIC_CLIENTID
const clientSecret = process.env.SECRET_KEY



const urlencoded = new URLSearchParams()
urlencoded.append("client_id", clientID);
urlencoded.append("client_secret", clientSecret);
urlencoded.append("grant_type", "client_credentials");


const getAccessToken = async () => {

    const response = await fetch(
        `${keycloakUrl}/realms/${realm}/protocol/openid-connect/token`,
        {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: urlencoded
        }
    )

    const data = await response.json()
    if (response.ok) {
        return data.access_token
    } else {
        return NextResponse.json({ message: "Failed to generate Access Token" }, { status: 500 })
    }
}

export const POST = async (req) => {
    const activeUser = await req.json()
    const token = await getAccessToken()

    const userEmail = activeUser.email
    console.log(userEmail)
    console.log(token)

    try {

        const response = await fetch(`${keycloakUrl}/admin/realms/${realm}/users?email=${encodeURIComponent(userEmail)}`, {
            method: "GET",
            headers: {
                Authorization: `Bearer ${token}`,
                "Content-Type": "application/json"
            }
        })




        const user = await response.json()


        return NextResponse.json({
            message: "Authorised", user: user

        }, { status: response.status })


    } catch (err) {
        console.log(err)
    }

}
