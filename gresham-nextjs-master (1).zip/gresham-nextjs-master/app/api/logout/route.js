import { NextResponse } from "next/server";
import { cookies } from "next/headers";


const keycloakUrl = process.env.NEXT_PUBLIC_URL
const realm = process.env.NEXT_PUBLIC_REALM
const clientID = process.env.NEXT_PUBLIC_CLIENTID
const clientSecret = process.env.SECRET_KEY





export const POST = async (req) => {
    cookies().set("accessToken", "", { httpOnly: true, maxAge: 0, sameSite: "strict", })
    cookies().set("refreshToken", "", { httpOnly: true, maxAge: 0, sameSite: "strict", })

    return NextResponse.json({
        message: "logout successful"
    }, { status: 200 })


};