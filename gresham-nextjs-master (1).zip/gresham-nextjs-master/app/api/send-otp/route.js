import { NextResponse } from "next/server";




const getOtp = async (email) => {
    try {
        const res = await fetch(`http://api.issl.ng:7777/ibank/api/v1/generateotp?userId=${email}`);
        const otp = await res.json();
        if (!res.ok) {
            throw new Error(`Failed to generate OTP: ${res.status}`);
        }
        return otp;
    } catch (err) {
        console.error(err);
        return null;
    }
};

export const POST = async (req) => {
    try {
        const data = await req.json();
        const email = data.email;

        // Validate email input
        if (!email || !email.includes("@")) {
            return NextResponse.json({ error: "Invalid email address" }, { status: 400 });
        }

        const otp = await getOtp(email);
        if (!otp) {
            return NextResponse.json({ error: "Failed to generate OTP" }, { status: 500 });
        }


        const mailResponse = await fetch('http://api.issl.ng:7777/ibank/api/v1/sendmail', {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                "from": "devops@issl.ng",
                "to": email,
                "subject": "verification message",
                "attachments": [
                    {}
                ],
                "body": `To verify your email address, please enter the following One-Time Password code: ${otp}`
            }),
        });

        if (mailResponse.ok) {
            return NextResponse.json({ message: "Verification code sent successfully" }, { status: 200 });
        } else {
            return NextResponse.json({
                status: mailResponse.status,
                message: "Failed to send email verification code"
            }, { status: 500 });
        }
    } catch (error) {
        console.error(error);
        return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
    }
};