import { Button } from "@/components/ui/Button"

const instrument = [
    {
        name: "Bonds",
        rate: "60%",
        costValue: 917.54,
        currentValue: 917.54,
        color: "006388"

    },
    {
        name: "Treasury Bills",
        rate: "15%",
        costValue: 674604054,
        currentValue: 674604054,
        color: "219ECC"
    },
    {
        name: "CPs",
        rate: "20%",
        costValue: 724604054,
        currentValue: 724604054,
        color: "C7E0EA"

    },
    {
        name: "Fixed Deposit Notes",
        rate: "5%",
        costValue: 1224604054,
        currentValue: 1224604054,
        color: "75CCEC"

    },

]

const equitiesInvestment = [
    {
        stocks: "FIRST BANK OF NIG. PLC",
        bought: 90000,
        sold: 0,
        avgUnitCost: 26.82,
        aggregateUnits: 90000,
        currentPrice: 25.55,
        currentValue: 2513800.00,
        gainLoss: -114300,
        gainLossPercent: -4.73
    },
    {
        stocks: "ACCESS BANK NIGERIA PLC.",
        bought: 90000,
        sold: 0,
        avgUnitCost: 26.82,
        aggregateUnits: 90000,
        currentPrice: 25.55,
        currentValue: 2513800.00,
        gainLoss: -114300,
        gainLossPercent: -4.73
    },
    {
        stocks: "TRANS NATIONAL CORPORATION",
        bought: 90000,
        sold: 0,
        avgUnitCost: 26.82,
        aggregateUnits: 90000,
        currentPrice: 25.55,
        currentValue: 2513800.00,
        gainLoss: -114300,
        gainLossPercent: -4.73
    },
]
const Portfolio = () => {
    return (
        <div className="grid gap-8">
            <div >
                <p>Portfolio Value</p>
                <div className="flex justify-between items-center">
                    <div className="text-3xl font-bold">25,658,999.23</div>
                    <Button>Download</Button>
                </div>
            </div>
            <div className="flex gap-4  ">

                {
                    instrument.map((item) => {
                        return (
                            <div className="bg-white rounded-lg p-4 w-[300px] ">
                                <div className="flex justify-between pb-2 border-b border-gray-200">
                                    <div className="flex gap-1">
                                        <span className={`w-6 aspect-square bg-[#${item.color}] `}></span>
                                        <p>{item.name}</p>
                                    </div>
                                    <p className="font-bold">{item.rate}</p>
                                </div>
                                <div className="flex justify-between">
                                    <div className="grid  gap-2">
                                        <p className="font-bold">Cost Value</p>
                                        <p>{item.costValue}</p>
                                    </div>
                                    <div className="grid  gap-2">
                                        <p className="font-bold">Current Value</p>
                                        <p>{item.currentValue}</p>
                                    </div>
                                </div>
                            </div>
                        )
                    })
                }
            </div>
            <div className=" grid gap-4">
                <h2 className="text-2xl text-white bg-[#0C526C] p-3">EQUITIES INVESTMENT</h2>

                <div>
                    <table className="border-collapse">

                        <thead className="bg-[#E3F3FD]">
                            <tr>
                                <th  >Stock</th>
                                <th>Bought</th>
                                <th>Sold</th>
                                <th>Avg. Unit Cost</th>
                                <th>Aggregate Units</th>
                                <th>Current Price</th>
                                <th>Current Value</th>
                                <th>Gain/Loss</th>
                                <th>Gain/Loss (%)</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                equitiesInvestment.map(item => {
                                    return (
                                        <tr>
                                            <td>{item.stocks}</td>
                                            <td>{item.bought}</td>
                                            <td>{item.sold}</td>
                                            <td>{item.avgUnitCost}</td>
                                            <td>{item.aggregateUnits}</td>
                                            <td>{item.currentPrice}</td>
                                            <td>{item.currentValue}</td>
                                            <td>{item.gainLoss}</td>
                                            <td>{item.gainLossPercent}</td>
                                        </tr>
                                    )
                                })
                            }
                            <tr>
                                <tb></tb>
                            </tr>

                        </tbody>
                    </table>

                </div>


            </div>



        </div>
    )
}

export default Portfolio