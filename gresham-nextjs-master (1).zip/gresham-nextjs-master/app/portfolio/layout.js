import GeneralLayout from "@/components/layout/GeneralLayout"


const layout = ({ children }) => {
    return (
        <GeneralLayout>
            {children}
        </GeneralLayout>
    )
}

export default layout