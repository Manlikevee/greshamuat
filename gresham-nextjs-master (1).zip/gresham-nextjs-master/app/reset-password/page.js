"use client"
import logo from "@/assets/greshamw.svg"
import { Button } from '@/components/ui/Button'
import Image from "next/image"
import Link from "next/link"
import { useEffect, useRef, useState } from 'react'
import { Toaster } from 'react-hot-toast'

const PasswordReset = () => {
    const [email, setEmail] = useState()
    const [isLoading, setIsLoading] = useState(false)
    const [isSendingCode, setIsSendingCode] = useState(false)
    const emailRef = useRef()
    useEffect(() => {
        emailRef.current.focus()

    }, [])

    const handleChange = (e) => {
        setEmail(e.target.value)
    }

    return (
        <div className="bg-gray-200 grid place-content-center h-screen w-screen">
            <Toaster />
            <div className="bg-basered w-fit mx-auto py-3 px-8 rounded-t-lg">
                <Image src={logo} width={100} alt="gresham logo" />
            </div>
            <div className="bg-[#f6f6f6] w-[24rem] p-8 text-center grid rounded-xl">
                <p className="text-xl font-bold">Reset your Password</p>

                <p className="text-sm mt-4  text-black/80 mb-4">Enter the email associated with your account and we will send an instruction on how to reset your password</p>
                <div className="  mb-6">

                    <div className={"relative"}>
                        {
                            email && <label className={"absolute translate-y-1/2 left-2 z-10 text-xs px-2 text-black/80  -top-[25%] bg-[#f1f1f1]"} >Email Address</label>
                        }
                        <input
                            id="email"
                            ref={emailRef}
                            autoComplete='off'
                            type="email"
                            name="email"
                            onChange={handleChange}
                            placeholder='Email Address'
                            required
                            className={"px-4 py-3 mb-4  placeholder:text-sm bg-[#f1f1f1] w-full rounded-md border-2 border-black/20"}
                        />



                    </div>

                    {/* <p className="text-start text-xs pt-1 pl-1 text-red-500">{errMsg}</p> */}

                    <Button
                        // onClick={() => verifyOtp()}
                        type={"black"} className={"w-full"}>{isLoading ? <span className="animate-pulse"> Verifying...</span> : "Reset Password"}

                    </Button>

                    <p className="mt-2 text-sm">
                        Remember Password? <Link className="text-baseblue" href={"/"}>Login</Link>
                    </p>

                    {/* <div className="flex text-sm mt-2 justify-between">
                        <p>Didn't get the code?</p>
                        <p
                            // onClick={sendOTP}
                            className="text-baseblue cursor-pointer">
                            {isSendingCode ? <span className="animate-pulse">Resending...</span> : "Resend Code"}</p>
                    </div> */}


                </div>



            </div>
            {/* 
            {
                popupOpen && <div>
                    {isVerified
                        ? <VerificationSuccessModal clickFunc={handleRedirect} />
                        : <VerificationFailModal errormessage={<div>{errorMsg}</div>} clickFunc={handleRedirect} />
                    }

                </div>


            } */}


        </div>
    )
}

export default PasswordReset