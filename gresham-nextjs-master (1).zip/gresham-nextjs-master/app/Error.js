import React from 'react'

const ErrorPage = () => {
    return (
        <div className='grid h-screen'>Error</div>
    )
}

export default Error