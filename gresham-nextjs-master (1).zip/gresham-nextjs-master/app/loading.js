

const loading = () => {
    return (
        <div>
            <span className="smooth spinner" ></span>
        </div>
    )
}

export default loading