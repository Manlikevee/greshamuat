import { NextResponse } from "next/server";
import { cookies } from "next/headers";

const keycloakUrl = process.env.NEXT_PUBLIC_URL
const realm = process.env.NEXT_PUBLIC_REALM
const clientID = process.env.NEXT_PUBLIC_CLIENTID
const clientSecret = process.env.SECRET_KEY



export const middleware = async (req) => {
    const cookie = cookies()


    const accessToken = cookie.get("accessToken")
    const refreshToken = cookie.get("refreshToken")

    console.log(req.url)



    if (refreshToken && !accessToken) {
        try {
            const res = await fetch(`${keycloakUrl}/realms/${realm}/protocol/openid-connect/token`,
                {
                    method: "POST",
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: new URLSearchParams({
                        grant_type: "refresh_token",
                        client_id: clientID,
                        refresh_token: refreshToken.value,
                        client_secret: clientSecret
                    })

                }
            )

            const data = await res.json()
            if (res.status === 200) {
                let response = NextResponse.next()
                response.cookies.set("accessToken",
                    data.access_token,
                    { httpOnly: true, maxAge: 20 * 60, sameSite: "strict" })
                response.cookies.set("refreshToken",
                    data.refresh_token,
                    { httpOnly: true, maxAge: 30 * 60, sameSite: "strict" })

                return response

            }


        } catch (error) {


            return NextResponse.next()
        }
    }


    if ((req.nextUrl.pathname.startsWith('/investment') || req.nextUrl.pathname.startsWith('/profileupdate')) && !accessToken) {
        return NextResponse.redirect(new URL("/", req.url));
    }
    if ((req.nextUrl.pathname === '/' || req.nextUrl.pathname === '/signup') && accessToken) {
        return NextResponse.redirect(new URL("/investment", req.url));
    }



    return NextResponse.next()
}

// export const config = {
//     matcher: ["/investment/:path*", "/profile/:path*"]
// }


