import React from 'react'
import { Modal } from './Modal'
import Link from 'next/link'

const OtpModal = ({ clickFunc }) => {
    return (
        <Modal>
            <div className='grid gap-6 text-center p-8'>
                <h1 className='text-2xl font-bold'> 2 Steps away!</h1>
                <div className='space-y-4 text-black/60'>
                    <p>you are 2 steps away from creating <br />your online profile</p>
                    <p>A Six(6) digit code has been sent to your <br /> Phone Number for verification</p>

                </div>

                <Link onClick={clickFunc} className='bg-black/70 text-white rounded-md py-3 px-4' href={"/signup/verifyphoneno"} replace >
                    Proceed
                </Link>
            </div>

        </Modal>
    )
}

export default OtpModal