"use client"
import { LinkButton } from "@/components/ui/Button";
import { Modal } from "@/components/modals/Modal"
import { FaXmark } from "react-icons/fa6";
import { investment } from "@/utils/constants";
import { useState } from "react";


const InvestmentModal = ({ clickFunc }) => {

    // const [product, setProduct] = useState()

    // const getProducts = async () => {
    //     } catch (err) {
    //         console.log(err)
    //      try {
    //         const res = await fetch("http://api.issl.ng:7777/ibank/api/v1/mmliabilityproducts")
    //         const data = await res.json()
    //         if (res.status === "ok") {
    //             console.log(data)
    //             setProduct(data)
    //         }
    //    }

    // }
    return (

        <Modal>


            <div className="max-w-[670px] leading-[1.5]">
                <div className=" flex justify-between mb-3 md:mb-6 items-center">
                    <h1 className=" md:text-2xl font-bold ">Add Investment</h1>
                    <FaXmark className="text-xl text-[#4A4C4E]" cursor={"pointer"} onClick={clickFunc} />
                </div>

                <div className="overflow-y-auto h-[25rem] grid gap-8 p-4">
                    {
                        investment.map(item => {
                            return (
                                <div className="bg-[#e5e5e54a] rounded-xl p-4 md:p-6">
                                    <h2 className=" font-bold mb-2 mt-2 md:text-xl">
                                        {item.name}
                                    </h2>
                                    <p className="text-[rgba(0,0,0,0.7)] text-justify">{item.description}
                                    </p>

                                    <h2 className="font-bold mt-4 mb-2 md:text-lg">Features:</h2>
                                    <ol className="text-[rgba(0,0,0,0.7)] text-pretty  grid gap-2">
                                        {
                                            item.features.map(feature => {
                                                return (
                                                    <li className="pl-2 ml-5 list-decimal list-outside"> {
                                                        feature
                                                    }
                                                    </li>
                                                )
                                            })
                                        }

                                    </ol>

                                    <div onClick={clickFunc}
                                        className="grid place-content-end mt-4">

                                        <LinkButton
                                            type={"blue"}
                                            path={item.link}
                                            className={"w-[121px] grid place-content-center"}
                                        >
                                            Invest
                                        </LinkButton>
                                    </div>





                                </div>
                            )
                        })
                    }

                </div>

            </div>
        </Modal>

    )
}

export default InvestmentModal