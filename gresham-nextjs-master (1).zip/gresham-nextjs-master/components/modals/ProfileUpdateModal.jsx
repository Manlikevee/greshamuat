import { Modal } from "@/components/modals/Modal"
import { Button, LinkButton } from "@/components/ui/Button"
import { FaXmark } from "react-icons/fa6";
import usePopup from "@/hooks/usePopup";
import { useRouter } from "next/navigation";


const ProfileUpdateModal = ({ clickFunc }) => {
    const { closePopup } = usePopup()
    const router = useRouter()

    const handleClick = () => {
        closePopup()
        router.push("/investment/profile-update")
    }

    return (
        <Modal>
            <div className="grid gap-8 items-center">

                <div className="text-center">

                    <FaXmark onClick={clickFunc} className="ml-auto top-6 text-[#424243] text-2xl right-6 cursor-pointer" />

                    <h1 className="text-2xl mb-2 font-semibold">Profile</h1>
                    <p className="max-w-[389px] text-[#424243] leading-[1.5]">Welcome!! Please update your profile information to us completely set up your account.</p>
                </div>

                <Button
                    onClick={handleClick}

                >
                    Proceed

                </Button>
            </div >

        </Modal>
    )
}

export default ProfileUpdateModal