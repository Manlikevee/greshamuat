import { FaCheck, FaXmark } from "react-icons/fa6"
import { Button } from "../ui/Button"
import { Modal } from "./Modal"
import Link from "next/link"


export const VerificationFailModal = ({ clickFunc, errormessage }) => {
    return (
        <Modal>
            <div className="grid gap-4 mb-8 w-full md:w-[20rem]">
                <div className="grid mx-auto place-content-center font-bold border-[5px] h-16 text-red-500 text-3xl aspect-square border-red-500 rounded-full">
                    <FaXmark />

                </div>
                <p className="text-center font-bold">             Verification failed
                </p>

                <p className="text-center text-sm">
                    {errormessage}
                </p>
            </div>

            <Button className={"w-full"} onClick={clickFunc} type={"black"}>
                Cancel
            </Button>
        </Modal>
    )
}

export const VerificationSuccessModal = ({ clickFunc, type }) => {
    return (
        <Modal>
            <div className="grid gap-4 mb-8 w-full md:w-[20rem]">

                <div className="grid mx-auto place-content-center font-extrabold border-[5px] h-16 text-green-600 text-4xl aspect-square border-green-600 rounded-full">
                    <FaCheck className="" />
                </div>
                <p className="text-center text-lg  text-black/80 font-bold">             Verification Successful
                </p>
                <p className="text-center text-gray-400 text-sm">You have successfully verified your
                    {
                        type === "phoneNo" ? " Phone Number click on proceed to verify your Email Address" : "Email address Click Proceed to log into you account"
                    }
                </p>

            </div>

            <Button className={"w-full"} onClick={clickFunc} type={"black"}>
                Proceed
            </Button>
        </Modal >
    )
}