import { FaCheck } from "react-icons/fa6";
import { Button, LinkButton } from "@/components/ui/Button";
import { HiMiniXMark } from "react-icons/hi2";


const modalContainer = "w-full text-center mb-8"
const h1Style = "text-2xl my-4 font-bold"
const pStyle = "max-w-[410px] leading-[1.5] text-center"


export const Success = ({ message, header, targetAction, targetId, clickFunc }) => {
    return (
        <div className="bg-white modal relative min-h-[10rem] rounded-xl  p-4 md:p-8  overflow-auto max-h-[90vh]">
            <div className={modalContainer}>
                <div className="grid place-items-center w-[72px] h-[72px] text-8 bg-[#08a534] text-white rounded-full mx-auto mb-2">
                    <FaCheck className="text-3xl" />
                </div>


                <h1 className={h1Style}>{header}</h1>
                <p className={pStyle}>{message}</p>

            </div>

            <Button
                onClick={clickFunc}
                type={"blue"}
                targetId={targetId}
                targetAction={targetAction}
            >
                Proceed
            </Button>
        </div>
    )
}

export const SuccessModal = ({ message, header, path, clickFunc, id }) => {
    return (
        <Modal id={id}>
            <div className={modalContainer}>
                <div className="grid place-items-center w-[72px] h-[72px] text-8 bg-[#08a534] text-white rounded-full mx-auto mb-2">
                    <FaCheck className="text-3xl" />
                </div>


                <h1 className={h1Style}>{header}</h1>
                <p className={pStyle}>{message}</p>

            </div>

            <LinkButton
                path={path}
                onClick={clickFunc}
                type={"blue"}
            >
                Proceed
            </LinkButton>
        </Modal>
    )
}

export const ErrorModal = ({ message, header, path, clickFunc }) => {
    return (
        <Modal>
            <div className={modalContainer}>
                <div className="grid place-content-center w-[72px] h-[72px] text-4xl bg-white border border-basered text-basered rounded-full mx-auto mb-1">
                    <HiMiniXMark />
                </div>


                <h1 className={h1Style}>{header}</h1>
                <p className={pStyle}>{message}</p>

            </div>

            <LinkButton
                path={path}
                onClick={clickFunc}
                type={"blue"}
            >
                Cancel
            </LinkButton>
        </Modal>
    )
}
export const InstructionModal = ({ message, header, path, clickFunc }) => {
    return (
        <Modal>
            <div className="modalContainer">


                <h1 className={h1Style}>{header}</h1>
                <p className={pStyle}>{message}</p>


            </div>

            <LinkButton
                path={path}
                onClick={clickFunc}
                type={"blue"}

            >
                Proceed
            </LinkButton>
        </Modal>
    )
}



export const Modal = ({ children, id }) => {
    return (
        <div id={id} className="bg-[rgba(0,0,0,0.7)] fixed w-full h-screen grid place-items-center top-0 left-0 z-[9999999] p-4 md:p-6">
            <div className="bg-white modal relative min-h-[10rem] rounded-xl p-4 md:p-8 overflow-auto max-h-[90vh]">
                {children}
            </div>
        </div>
    )
}




