import Link from "next/link"


const TreasuryCard = ({ name, rate, yieldValue, maturity, onClick, LinkTo }) => {


    return (
        <div onClick={onClick} className="bg-white grid gap-4 items-start rounded- w-full md:max-w-[20rem] py-6 px-6" href={LinkTo}>


            <h1 className="text-2xl font-bold">{name}</h1>

            <div className="grid gap-2 pt-6 border-t border-baseblue">
                <div className="flex justify-between">
                    <p>Rate</p>
                    <p className="font-bold" >{rate}%</p>
                </div>

                <div className="flex justify-between">
                    <p>Yield</p>
                    <p className="font-bold">{yieldValue}% per annum</p>
                </div>

                <div className="flex justify-between">
                    <p>Maturity</p>
                    <strong>{maturity}</strong>

                </div>
            </div >
        </div >
    )
}

export default TreasuryCard