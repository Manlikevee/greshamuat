import Link from "next/link";
import { HiOutlineDotsHorizontal } from "react-icons/hi";


const AccountCard = ({ accountNo, name, principal, maturityDate, interest, path, className }) => {
    return (
        <Link href={path} className={`bg-white ${className} w-full cursor-pointer pt-6 px-6 rounded-xl`}>
            <div className="mb-6">
                <div className="flex justify-between mb-2 text-[#737373]">
                    <p className="text-sm">Account Number</p>
                    <HiOutlineDotsHorizontal />
                </div>
                <p className="text-[#222222] text-sm">{accountNo}</p>
            </div>

            <div>
                <h1 className="text-[#011620] font-bold text-2xl mb-3 ">
                    {name}
                </h1>
                <ul className="grid gap-4 py-6 border-t border-t-baseblue">
                    <li className="flex justify-between text-sm ">
                        <p className="text-[#737373] ">Current Principal</p>
                        <p className="font-semibold text-[#222222] "> <del className="decoration-double ">N</del> {principal}</p>
                    </li>
                    <li className="flex justify-between text-sm">
                        <p className="text-[#737373] ">Maturity Date</p>
                        <p className="font-semibold text-[#222222]"> {maturityDate}</p>
                    </li>
                    <li className="flex justify-between text-sm">
                        <p className="text-[#737373] " >Interest Rate</p>
                        <p className="font-semibold text-[#222222]"> {interest}%</p>
                    </li>
                </ul>

            </div>
        </Link>
    )
}

export default AccountCard