import border from "@/assets/border-design.svg"

const BalanceCard = ({ totalText, value, firstIndex }) => {
    return (
        <div
            className={` ${!firstIndex && "border border-[#ffffff80]"} bg-left-top bg-cover relative p-2 h-[164px] lg:h-[194px] w-full rounded-2xl `}
        >
            <div
                className={` ${firstIndex ? "bg-baseblue  blueBalance text-white" : "bg-[#ffffff80]"} h-full p-6 lg:py-8 rounded-lg content-end grid gap-4 font-semibold  text-[#0F172A]`}
            >
                <p className="whitespace-nowrap">{totalText}</p>

                <h1 className=" text-4xl  md:text-[2.5rem] ">{value}</h1>

            </div>
        </div>
    )
}

export default BalanceCard