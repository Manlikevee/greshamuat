
import Image from "next/image"
import Link from "next/link"




const BondsCard = ({ bondImg, bondName, bondCompany, value, rate, onClick, LinkTo, imgAlt }) => {

    return (
        <Link onClick={onClick} className="bg-white rounded-lg p-[18px] xl:w-[200px]" href={LinkTo} >

            <div className="mb-3 ">
                <Image src={bondImg} width={50} height={50} alt={imgAlt || ""} />
            </div>
            <h1 className="font-bold mb-1 text-2xl">{bondName}</h1>
            <p className="pb-3">{bondCompany}</p>
            <div className="grid gap-3 pt-3 border-t border-baseblue">
                <div className="flex justify-between" >
                    <p>Value</p>
                    <p className="font-bold"> <del className="decoration-double">N</del> {value}</p>
                </div>

                <div className="flex justify-between">
                    <p>Rate</p>
                    <p className="font-bold" >{rate}%</p>
                </div>

            </div>
        </Link>
    )
}

export default BondsCard