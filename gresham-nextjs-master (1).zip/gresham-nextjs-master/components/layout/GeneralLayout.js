
import dynamic from 'next/dynamic'

const Header = dynamic(() => import("./Header"), { ssr: false })

const GeneralLayout = ({ children }) => {
    return (
        <>

            <div className="inline-block w-full z-[-999999999999] absolute h-[225px] lg:h-[285px] bg-[#219ecc1a]"> </div>

            <Header />

            <main className="px-inline pb-8">
                {children}
            </main>

        </>
    )
}

export default GeneralLayout