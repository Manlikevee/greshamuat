"use client"

import { useEffect, useRef, useState } from 'react'
import Link from 'next/link'
import { FaEye } from "react-icons/fa";
import { FaEyeSlash } from "react-icons/fa";
import { useRouter } from 'next/navigation';
import toast, { Toaster } from 'react-hot-toast';



const styles = {
    formContainer: "grid gap-4 md:gap-x-14 sm:grid-cols-2",
    inputFieldStyle: "grid  relative content-end w-full",
    // inputStyle: "grid gap-2 relative content-start bg-[#f6f6f6] py-2 px-4 rounded-md w-full placeholder:text-sm",
    inputStyle: "px-4 py-2  placeholder:text-sm bg-[#f1f1f1] w-full rounded-md border-2 border-black/20",
    label: "absolute translate-y-1/2 left-2 z-10 text-xs px-2 text-black/80  -top-[40%] bg-[#f1f1f1]",

    circle: "w-4 aspect-square inline-block rounded-full bg-white cursor-pointer",
    red: "text-red-500 text-xl",
    errMsg: "text-red-500 text-xs ",
    // errMsg: "text-red-500 text-xs absolute -bottom-4 h-4"
}



const LoginForm = () => {
    const REGEX = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/

    const [errMsg, setErrMsg] = useState("")
    const [showPassword, setShowPassword] = useState(false)
    const [isLoading, setIsLoading] = useState(false)

    const [formData, setFormData] = useState({
        email: "",
        password: "",
    })

    const router = useRouter()

    const emailRef = useRef()

    const notify = (type, message) => toast[type](message)


    useEffect(() => {
        emailRef.current.focus()
    }, [])


    const handleChange = (e) => {

        setFormData((prev) => ({
            ...prev,
            [e.target.name]: e.target.value
        }))
        setErrMsg("")

    }

    const showPass = () => {
        setShowPassword(prev => !prev)
    }



    const validateInput = (e) => {
        const { email, password } = formData
        const isValid = REGEX.test(email)

        if (email === "" || password === "") {
            setErrMsg("Kindly enter a valid email and password to login")
            return false
        } else if (!isValid) {
            setErrMsg("Please enter a valid email")
            return false
        } else {
            return true
        }

    }

    const handleSubmit = async (e) => {
        e.preventDefault()

        const valid = validateInput()

        if (valid) {

            setIsLoading(true)

            try {
                const res = await fetch("/api/login", {
                    method: "POST",
                    body: JSON.stringify(formData)
                })

                const data = await res.json()

                if (res.status === 200) {

                    localStorage.setItem("user", JSON.stringify(data.user))

                    router.replace("/investment")


                } else {
                    notify("error", "Invalid login details")

                }
            } catch (error) {
                notify("error", "No internet connection")
            } finally {
                setIsLoading(false)
            }
        }
    }

    return (
        <>
            <Toaster />

            <div className='grid gap-1 mb-10'>
                <h1 className='text-basered text-lg font-semibold'>Welcome Back!</h1>
                <p className='tex-black/70 text-sm'>Log into your account</p>
            </div>


            <form noValidate onSubmit={handleSubmit} className="grid gap-4">
                <div className='grid gap-8'>

                    <div className={"relative"}>
                        {
                            formData?.email && <label className={styles.label} >Email Address</label>
                        }
                        <input
                            id="email"
                            ref={emailRef}
                            autoComplete='off'
                            type="email"
                            name="email"
                            onChange={handleChange}
                            placeholder='Email Address'
                            required
                            className={styles.inputStyle}
                        />



                    </div>




                    <div className={styles.inputFieldStyle}>
                        {
                            formData?.password && <label className={styles.label} >Password</label>
                        }

                        <div className='relative'>
                            <input
                                id="pwd"
                                name="password"
                                type={showPassword ? "text" : "password"}
                                placeholder='Password'
                                onChange={handleChange}
                                required
                                className={styles.inputStyle}
                            />
                            <div
                                onClick={showPass}
                                className='absolute right-4 cursor-pointer top-1/2 -translate-y-1/2'>
                                {showPassword ? <FaEye /> : <FaEyeSlash />}


                            </div>


                            <div>

                            </div>


                        </div>

                        <span className="text-red-500 text-sm ">
                            {errMsg}
                        </span>
                    </div>

                </div>

                <div>
                    <Link className='text-sm hover:text-baseblue' href={"./reset-password"}> Forgot password?</Link>

                </div>



                <button className={`${isLoading ? "bg-black/60 pointer-events-none" : "bg-black/80"} text-white  py-2 px-4 rounded-lg`}>
                    Login

                </button>
                <p className="text-center text-black/80 text-xs mt-2">Don't have an account? <Link className='text-red-500 font-bold' href={"/signup"}>Sign Up</Link></p>



            </form>

            <div>
                <p className="text-center text-xs mt-8">By Using the Gresham portal you are agreeing to the <Link className="font-bold text-red-500" href="">Privacy policy</Link>  and <a className="font-bold text-red-500">Terms of use</a>  of Gresham Asset Managements Limited</p>

            </div>





        </>
    )
}

export default LoginForm
