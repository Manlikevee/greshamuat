import sideImage from "@/assets/nationaltheater.png"
import logo from "@/assets/greshamw.svg"
import Image from "next/image"

const paginationNo = [1, 2, 3, 4]

const AuthLayout = ({ children }) => {
    return (
        <div className="min-h-screen lg:h-screen grid place-content-center max-w-[100vw] p-2 lg:p-4 bg-inherit overflow-auto" >

            <div className=" md:max-w-[600px] lg:w-[980px] lg:max-w-[1000px]">
                <div className="bg-basered mx-auto lg:ml-auto  lg:mr-8 h-fit  w-fit py-2 px-4 lg:py-3 lg:px-10 rounded-t-xl">
                    <Image src={logo} width={120} alt="gresham logo" />
                </div>
                <div className="flex p-4 md:p-8 lg:p-4 gap-8 bg-inherit shadow-lg lg:h-[500px] border rounded-3xl relative ">


                    <div className="w-full  lg:pl-4">
                        {children}

                    </div>

                    <div
                        style={{
                            background: ` linear-gradient(to top, #219ecc 15%, transparent, transparent), url(${sideImage.src})`,
                            backgroundSize: "cover",
                            backgroundPosition: "center",
                            backgroundRepeat: "no-repeat"
                        }}

                        className=" w-[40rem] hidden border lg:grid content-end border-white rounded-3xl text-white h-full relative px-4 pb-10">

                        <h1 className="text-[22px] font-bold">Gresham Fund Placement </h1>
                        <p className="text-xs font-thin">Investing funds in various financial instruments <br /> to achieve optimal returns </p>
                        <div className="flex mt-8 gap-1 w-full p-4 justify-center items-center absolute bottom-0">
                            {
                                paginationNo.map((dot, index) => {
                                    return (
                                        <div key={index} className={`w-2.5 aspect-square rounded-full ${index === 2 ? "bg-gray-300 " : "bg-white "} `}>
                                        </div>
                                    )
                                })
                            }
                        </div>
                    </div>
                </div>
            </div>










            {/* <div className="">
                <div className="bg-basered mx-auto lg:ml-auto lg:mr-8  w-fit py-3 px-10 rounded-t-xl">
                    <Image src={logo} width={120} alt="gresham logo" />
                </div>
               
            </div> */}

        </div >
    )

}

export default AuthLayout