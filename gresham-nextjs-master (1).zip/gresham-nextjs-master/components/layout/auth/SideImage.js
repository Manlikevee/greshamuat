import sideImage from "@/assets/sideImage.png"


const SideImage = ({ className }) => {
    return (
        <section

            className="sideCarouselCard">
            <h1>Gresham Fund Placement </h1>
            <p>Investing funds in various financial instruments <br /> to achieve optimal returns </p>
            <small>Invest now, secure tomorrow</small>
        </section>
    )
}

export default SideImage