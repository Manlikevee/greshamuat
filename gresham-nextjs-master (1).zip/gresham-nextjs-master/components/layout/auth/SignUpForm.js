"use client"

import { useEffect, useRef, useState } from 'react'
import Link from 'next/link'
import PhoneNoInput from '@/components/ui/PhoneNoInput'
import { FaEye } from "react-icons/fa";
import { FaEyeSlash } from "react-icons/fa";
import { validateForm, validateInput } from '@/utils/FormValidator';
import usePopup from '@/hooks/usePopup';
import OtpModal from '@/components/modals/OtpModal';
import useSignupData from '@/hooks/useSignupData';
import toast, { Toaster } from 'react-hot-toast';
import { handleChange, handleNoChange, handlePhoneNoChange } from '@/utils/InputFunctions';

const allFields = {
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    bvn: "",
    phoneNo: "",
}

const styles = {
    formContainer: "grid gap-4 md:gap-x-14 sm:grid-cols-2",
    inputFieldStyle: "grid  relative content-end w-full",
    // inputStyle: "grid gap-2 relative content-start bg-[#f6f6f6] py-2 px-4 rounded-md w-full placeholder:text-sm",
    inputStyle: "px-4 py-2  placeholder:text-sm bg-[#f1f1f1] w-full rounded-md border-2 border-black/20",
    label: "absolute translate-y-1/2 left-2 z-10 text-xs px-2 text-black/80  -top-[40%] bg-[#f1f1f1]",

    circle: "w-4 aspect-square inline-block rounded-full bg-white cursor-pointer",
    red: "text-red-500 text-xl",
    errMsg: "text-red-500 text-xs ",
    // errMsg: "text-red-500 text-xs absolute -bottom-4 h-4"
}




const SignupForm = () => {
    const { signupData, setSignupData } = useSignupData()

    const { openPopup, closePopup, popupOpen } = usePopup()
    const [showPassword, setShowPassword] = useState(false)
    const [showConfirmPassword, setShowConfirmPassword] = useState(false)
    const [errors, setErrors] = useState({})
    const [isLoading, setIsLoading] = useState(false)

    const [isFormValid, setIsFormValid] = useState(false)

    const [cusType, setCusType] = useState("")

    const notify = (type, message) => toast[type](message)

    useEffect(() => {
        signupData && setCusType(signupData.customerType)

    }, [])





    const sendOTP = async () => {
        try {
            setIsLoading(true)
            const res = await fetch("/api/send-Phoneotp", {
                method: "POST",
                body: JSON.stringify({ phoneNo: signupData.phoneNo })
            })
            const data = await res.json()


            if (!res.ok) {
                throw new Error(`Response status ${res.status}`)
            } else {
                if (data.status === 500) {
                    notify("error", "No internet connection")
                } else {
                    openPopup()
                }
            }


        } catch (err) {
            console.log(err)
        } finally {
            setIsLoading(false)
        }

    }
    const handleSubmit = () => {
        validateForm(signupData, setErrors, sendOTP)
        console.log("errors", errors)
        console.log("formData", signupData)
    }



    const firstname = useRef()


    useEffect(() => {
        firstname.current.focus()
    }, [])



    const showPass = () => {
        setShowPassword(prev => !prev)
    }
    const showConfirmPass = () => {
        setShowConfirmPassword(prev => !prev)
    }




    return (
        <div >
            <Toaster />
            <div className='grid gap-2'>
                <div className='grid gap-1 mb-4'>
                    <h1 className='text-basered text-lg lg:text-lg font-semibold'>Open an Account</h1>
                    <p className='tex-black/70 text-sm'>Kindly fill the following details to create an account</p>
                </div>


                <div className=''>

                    <div className="grid gap-2">
                        <div className='grid gap-6 md:grid-cols-2'>
                            <div >
                                <div className={"relative"}>
                                    {
                                        signupData?.firstName && <label className={styles.label} >First Name</label>
                                    }
                                    <input
                                        id="fnameId"
                                        ref={firstname}
                                        autoComplete='off'
                                        type="text"
                                        name='firstName'
                                        className={styles.inputStyle}
                                        value={signupData?.firstName}
                                        placeholder="First Name"
                                        onChange={(e) => {
                                            handleChange(e, setSignupData),
                                                setErrors((prev) => ({
                                                    ...prev, firstName: ""
                                                }))

                                        }}
                                    />

                                </div>
                                <span className={styles.errMsg}>
                                    {errors?.firstName}
                                </span>

                            </div>
                            <div >
                                <div className={"relative"}>
                                    {
                                        signupData?.lastName && <label className={styles.label} >Last Name</label>
                                    }

                                    <input
                                        id="lname"
                                        autoComplete='off'
                                        type="text"
                                        name='lastName'
                                        className={styles.inputStyle}
                                        value={signupData?.lastName}
                                        placeholder="Last name"
                                        onChange={(e) => {
                                            handleChange(e, setSignupData),
                                                setErrors((prev) => ({
                                                    ...prev, lastName: ""
                                                }))

                                        }}
                                    />


                                </div>
                                <span className={styles.errMsg}>
                                    {errors?.lastName}
                                </span>

                            </div>
                            <div >
                                <div className={"relative"}>
                                    {
                                        signupData?.email && <label className={styles.label} >Email Address</label>
                                    }

                                    <input
                                        id="email"
                                        value={signupData?.email}
                                        autoComplete='off'
                                        type="email"
                                        className={styles.inputStyle}
                                        name='email'
                                        placeholder="Email Address"
                                        onChange={(e) => {
                                            handleChange(e, setSignupData),
                                                setErrors((prev) => ({
                                                    ...prev, email: ""
                                                }))
                                        }}
                                    />


                                </div>
                                <span className={styles.errMsg}>
                                    {errors?.email}
                                </span>

                            </div>
                            <div >
                                <div className={"relative"}>
                                    {
                                        signupData?.password && <label className={styles.label} >Password</label>
                                    }
                                    <div className='relative'>
                                        <input
                                            id="pwd"
                                            type={showPassword ? "text" : "password"}
                                            className={styles.inputStyle}
                                            name='password'
                                            value={signupData?.password}
                                            placeholder="Password"
                                            onChange={(e) => {
                                                handleChange(e, setSignupData),
                                                    setErrors((prev) => ({
                                                        ...prev, password: ""
                                                    }))
                                            }}

                                        />
                                        <div
                                            onClick={showPass}
                                            className='absolute right-4 cursor-pointer top-1/2 -translate-y-1/2'>
                                            {showPassword ? <FaEye /> : <FaEyeSlash />}


                                        </div>
                                    </div>



                                </div>
                                <span className={styles.errMsg}>
                                    {errors?.password}
                                </span>

                            </div>


                            <div >
                                <div className={"relative"}>
                                    {
                                        signupData?.bvn && <label className={styles.label} >BVN</label>
                                    }
                                    <input
                                        id="BVN"
                                        name='bvn'
                                        autoComplete='off'
                                        placeholder='BVN'
                                        type="text"
                                        className={styles.inputStyle}
                                        maxLength={11}
                                        value={signupData?.bvn}
                                        onChange={(e) => {
                                            handleNoChange(e, setSignupData),
                                                setErrors((prev) => ({
                                                    ...prev, bvn: ""
                                                }))
                                        }}
                                    />


                                </div>
                                <span className={styles.errMsg}>
                                    {errors?.bvn}
                                </span>

                            </div>
                            <div >
                                <div className={"relative"}>
                                    {
                                        signupData?.phoneNo && <label className={styles.label} >Phone No</label>
                                    }
                                    <PhoneNoInput

                                        value={signupData?.phoneNo}
                                        placeholder={"Phone Number"}
                                        onChange={(e) => {
                                            handlePhoneNoChange("phoneNo", e, setSignupData),
                                                setErrors((prev) => ({
                                                    ...prev, phoneNo: ""
                                                }))
                                        }}
                                        className={styles.inputStyle}


                                    />


                                </div>
                                <span className={styles.errMsg}>
                                    {errors?.phoneNo}
                                </span>

                            </div>











                            <div>
                                <p className={"text-black/80 text-xs"}>Customer Type</p>
                                <div className="flex  flex-col md:flex-row my-2 gap-2 md:items-center">
                                    <div className='flex gap-1' >
                                        <input
                                            checked={cusType === "individual"}
                                            value="individual"
                                            id="radio1"
                                            className="radio"
                                            type="radio"
                                            name="customerType"

                                            onChange={(e) => {
                                                handleChange(e),
                                                    setCusType("individual")
                                            }}

                                        />
                                        <label className='flex gap-1 items-center' htmlFor="radio1">
                                            <span className={styles.circle}></span>
                                            <p className='text-sm'>Individual</p>
                                        </label>
                                    </div>
                                    <div className='flex gap-1'>
                                        <input
                                            checked={cusType === "joint"}

                                            value="joint"
                                            id="radio2"
                                            className="radio"
                                            type="radio"
                                            name="customerType"

                                            onChange={(e) => {
                                                handleChange(e),
                                                    setCusType("joint")

                                            }}

                                        />
                                        <label className='flex gap-1 items-center' htmlFor="radio2">
                                            <span className={styles.circle}></span>
                                            <p className='text-sm'>Joint</p>
                                        </label>
                                    </div>
                                    <div className='flex gap-1'>
                                        <input
                                            checked={cusType === "children"}

                                            value="children"
                                            id="radio3"
                                            className="radio"
                                            type="radio"
                                            name="customerType"

                                            onChange={(e) => {
                                                handleChange(e),
                                                    setCusType("children")

                                            }}
                                        />
                                        <label className='flex gap-1 items-center' htmlFor="radio3">
                                            <span className={styles.circle}></span>
                                            <p className='text-sm'>Children</p>
                                        </label>
                                    </div>
                                    <div className='flex gap-1'>
                                        <input
                                            checked={cusType === "estate"}

                                            value="estate"
                                            id="radio4"
                                            className="radio"
                                            type="radio"
                                            name="customerType"

                                            onChange={(e) => {
                                                handleChange(e),
                                                    setCusType("estate")

                                            }}

                                        />
                                        <label className='flex gap-1 items-center' htmlFor="radio4">
                                            <span className={styles.circle}></span>
                                            <p className='text-sm'> Estate</p>
                                        </label>
                                    </div>
                                    <div >
                                        <input
                                            checked={cusType === "cooperate"}

                                            value="cooperate"
                                            id="radio5"
                                            className="radio"
                                            type="radio"
                                            name="customerType"

                                            onChange={(e) => {
                                                handleChange(e),
                                                    setCusType("cooperate")

                                            }}
                                        />
                                        <label className='flex gap-1 items-center' htmlFor="radio5">
                                            <span className={styles.circle}></span>
                                            <p className='text-sm'> Cooperate</p>
                                        </label>

                                    </div>

                                </div>
                            </div>

                        </div>


                        <div className="grid place-items-center">
                            <button
                                onClick={handleSubmit}
                                className={`${isLoading ? "bg-black/60 pointer-events-none" : "bg-black/80"}
                                 text-white w-full py-2 px-4 rounded-lg`}
                            >
                                Sign Up
                            </button>
                        </div>
                        <p className="text-center text-black/80 text-xs ">Already have an account? <Link className='text-red-500 font-bold' href={"/"}>Login</Link></p>



                    </div>

                    <div>
                        <p className="text-center text-xs mt-4">By Using the Gresham portal you are agreeing to the <Link className="font-bold text-red-500" href="">Privacy policy</Link>  and <a className="font-bold text-red-500">Terms of use</a>  of Gresham Asset Managements Limited</p>

                    </div>
                </div>


            </div>

            {
                popupOpen && <OtpModal clickFunc={closePopup} />
            }

        </div>
    )
}

export default SignupForm
