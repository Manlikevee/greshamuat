"use client"

import Image from "next/image"
import Link from "next/link"
import logo from "@/assets/logo.png"
import lady from "@/assets/lady.png"
import { IoMdNotificationsOutline } from "react-icons/io";
import { IoMdClose } from "react-icons/io";
import { HiDotsVertical } from "react-icons/hi";
import { useState } from 'react'
import { usePathname, useRouter } from "next/navigation"
import { FaUserCircle } from "react-icons/fa";
import { useActiveUser } from "@/hooks/useStore"
import { LuMenu } from "react-icons/lu";





const Header = () => {

    const user = JSON.parse(sessionStorage.getItem("user"))
    const router = useRouter()
    const [meunOpen, setMeunOpen] = useState(false)


    const logout = async () => {

        try {
            const res = await fetch("/api/logout", {
                method: "POST",
                body: ""
            })

            const data = await res.json()

            if (res.ok) {
                console.log(data)
                router.replace("/")
            }

        } catch (error) {
            console.log("network", error)
        }

    }


    const pathname = usePathname()

    return (
        <header className="flex py-4 md:py-6 px-inline items-center justify-between">
            <div className="grid place-content-center logo relative w-[120px] md:w-[160px] ">
                <Image width={"auto"} height={40} className="w-[160px]" priority src={logo} alt="gresham logo" />
            </div>
            <div className="md:flex hidden gap-6 items-center">



                <nav className="block">
                    <ul className="flex gap-4">
                        <li>
                            <Link
                                className={`${pathname.startsWith("/investment")
                                    ? "text-baseblue font-bold"
                                    : "text-black/80"}`} href="/"
                            >
                                Investment
                            </Link>
                        </li>
                        <li>
                            <Link
                                className={`${pathname.startsWith("/portfolio")
                                    ? "text-baseblue font-bold"
                                    : "text-black/80"}`}
                                href={"/portfolio"}>
                                Portfolio
                            </Link>
                        </li>
                    </ul>
                </nav>

                <ul className=" flex gap-4 items-center text-3xl">
                    <li className="bg-white rounded-full h-10 w-10 grid place-content-center"><IoMdNotificationsOutline /></li>


                    <li >
                        {
                            user?.image ? <Image width={40} height={40} src={lady} alt="user display photo" /> : <FaUserCircle className="text-black/80 text-4xl" />


                        }


                    </li>
                    <li onClick={logout}><HiDotsVertical /></li>
                </ul>


            </div>

            {
                meunOpen && <div className="mobileNavigation absolute bg-white w-[70vw] h-screen top-0 right-0 z-[99999999999] py-4 px-6">

                    <div>
                        <IoMdClose onClick={() => setMeunOpen(false)} className="ml-auto text-2xl text-black/80 mb-8" />

                    </div>

                    <div className="flex gap-2 items-center">
                        <div className="grid place-content-center">
                            {
                                user?.image ? <Image width={40} height={40} src={lady} alt="user display photo" /> : <FaUserCircle className="text-black/80 text-3xl" />
                            }
                        </div>



                        <div>

                            <h4 className="font-bold text-sm text-black/80">{`${user?.firstName} ${user?.lastName}`}</h4>
                            <p className="text-baseblue text-xs">{user?.email}</p>

                        </div>

                    </div>

                    <nav className=" mt-6">
                        <ul className="grid gap-6">
                            <li>
                                <Link
                                    className={`${pathname.startsWith("/investment")
                                        ? "text-baseblue font-bold"
                                        : "text-black/80"}`} href="/"
                                >
                                    Investment
                                </Link>
                            </li>
                            <li>
                                <Link
                                    className={`${pathname.startsWith("/portfolio")
                                        ? "text-baseblue font-bold"
                                        : "text-black/80"}`}
                                    href={"/portfolio"}>
                                    Portfolio
                                </Link>
                            </li>
                            <li>
                                <Link
                                    className={`${pathname.startsWith("/profile")
                                        ? "text-baseblue font-bold"
                                        : "text-black/80"}`}
                                    href={"/portfolio"}>
                                    Profile
                                </Link>
                            </li>
                            <li>
                                <Link
                                    className={`${pathname.startsWith("/notifications")
                                        ? "text-baseblue font-bold"
                                        : "text-black/80"}`}
                                    href={"/portfolio"}>
                                    Notification
                                </Link>
                            </li>
                            <li onClick={logout} >
                                Sign Out
                            </li>
                        </ul>
                    </nav>

                </div>
            }


            <div className="text-2xl text-black/80 md:hidden">
                <LuMenu onClick={() => { setMeunOpen(true) }} />
            </div>

        </header>
    )
}

export default Header