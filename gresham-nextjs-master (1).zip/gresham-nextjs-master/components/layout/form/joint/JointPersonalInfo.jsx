
"use client"

import { options } from "@/utils/constants"
import { getRelevantData } from "@/utils/filter"
import { validateForm } from "@/utils/FormValidator"
import { useEffect, useState } from "react"
import FormInfoFields from "../../FormInfoFields"
import { handleChange, handleSelect } from "@/utils/InputFunctions"




const allFields = {
    jointName: "", residentAddress: "", risk: "", investmentObjective: "",
}
const JointPersonalInfo = ({ activeId, setActiveId, validate, setValidate, NextForm }) => {

    const [initData, setInitData] = useState(JSON.parse(sessionStorage.getItem("formData")))
    const relevantData = getRelevantData(allFields, initData)
    const [formData, setFormData] = useState(relevantData || allFields)
    const [error, setError] = useState({})

    useEffect(() => {
        setInitData((prev) => ({ ...prev, ...formData }))
    }, [formData])

    useEffect(() => {
        sessionStorage.setItem("formData", JSON.stringify(initData))
    }, [initData])



    const formInfo = [
        {

            type: "text",
            label: "Joint Name",
            name: "jointName",
            placeholder: "Enter Joint Account Name",
            value: formData?.jointName,
            errMsg: error?.jointName,
            onChange: (e) => {
                handleChange(e, setFormData),
                    setError((prev) => ({ ...prev, jointName: "" }))
            },
        },
        {
            type: "select",
            placeholder: "Select risk level",
            label: "Risk Tolerance",
            id: "risk",
            option: options.risk,
            selected: formData?.risk,
            errMsg: error?.risk,
            onClick: () => { setActiveId("risk") },
            onSelect: (value) => { handleSelect("risk", value, setFormData), setError((prev) => ({ ...prev, risk: "" })) }
        },
        {
            type: "text",
            label: "Investment Objective",
            name: "investmentObjective",
            placeholder: "Please Enter investment objective",
            value: formData.investmentObjective || "",
            errMsg: error?.investmentObjective,

            onChange: (e) => {
                handleChange(e, setFormData),
                    setError((prev) => ({ ...prev, investmentObjective: "" }))

            },
        },
        {
            type: "address",
            label: "Residential Address",
            name: "residentAddress",
            placeholder: "Enter residential address",
            value: formData?.residentAddress,
            errMsg: error?.residentAddress,
            onChange: (e) => { handleChange(e, setFormData), setError((prev) => ({ ...prev, residentAddress: "" })) },
        },



    ]

    useEffect(() => {
        if (validate) {
            validateForm(formData, setError, NextForm)
            setValidate(false)
        }

    }, [validate])

    return (
        <FormInfoFields formInfo={formInfo} activeId={activeId} />
    )
}

export default JointPersonalInfo