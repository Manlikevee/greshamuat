
const CorporateRequirement = () => {
    return (

        <div className="grid gap-6">
            <div className="grid gap-2">
                <p>
                    We're excited to have you on board!
                </p>
                <p>   Before you dive into updating your profile, let's ensure you have everything you need to breeze through the process smoothly. Here's a quick checklist to make sure you're fully prepared:</p>
            </div>



            <div className="grid gap-2">
                <h3 className=" font-semibold"> Corporate Information:</h3>

                <p>
                    We'll need details like your <span className="font-bold" >Company name, Registered Address, Email, Website</span>  etc. Don't forget to add your contact information so we can stay in touch!
                </p>
            </div>

            <div className="grid gap-2">
                <h3 className=" font-semibold">Bank Information </h3>
                <p>

                    Have your bank details handy, including the <span className="font-bold" > Name of your bank</span> and <span className="font-bold" > your Account number,</span> This way, we can ensure smooth transactions.
                </p>

            </div>

            <div className="grid gap-2">
                <h3 className=" font-semibold" >Authorized Signatories</h3>
                <p>Please provide details about Four(4) Authorised Signatory including their Full Names, Roles, and Contact Information. This helps us ensure the correct individuals are authorized to manage and approve transactions on the account.</p>
            </div>

            <div className="grid gap-2">
                <h3 className=" font-semibold" >Signature Mandate</h3>
                <p>Kindly tick the authorized combination of signatories for all mandates </p>
            </div>



        </div>
    )
}

export default CorporateRequirement