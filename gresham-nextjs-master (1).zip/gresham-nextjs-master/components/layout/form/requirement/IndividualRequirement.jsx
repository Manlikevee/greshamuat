
const IndividualRequirement = () => {
    return (
        <div className="grid gap-6">

            <div className="grid gap-2">
                <h3 className=" font-semibold"> Personal Information:</h3>

                <p>
                    We'll need details like your <span className="font-bold" >Full name, Date of birth, Nationality, Current address</span>  etc. Don't forget to add your contact information so we can stay in touch!
                </p>
            </div>

            <div className="grid gap-2">
                <h3 className=" font-semibold" >Employment Information</h3>
                <p>Share a bit about your current <span>Employment status, Employer details, Job title,</span> etc. It helps us understand your financial situation better.</p>
            </div>

            <div className="grid gap-2">
                <h3 className=" font-semibold"> Next of Kin Information</h3>
                <p>  Provide us with the <span className="font-bold"> Full name and contact information </span>of your next of kin. It's important for us to have someone to reach out to in case of emergencies.</p>

            </div>
            <div className="grid gap-2">
                <h3 className=" font-semibold">Account Details</h3>
                <p>

                    Have your bank details handy, including the <span className="font-bold" > Name of your bank</span> and <span className="font-bold" > your Account number,</span> This way, we can ensure smooth transactions.
                </p>

            </div>

            <div className="grid gap-2">

                <h3 className=" font-semibold"> Document Upload</h3>
                <p>
                    Show us your credentials! Please have your <strong>identification document</strong>  (passport, national ID, driver's license), <strong > proof of address </strong>(utility bill, bank statement), etc., ready for upload.
                </p>


            </div>

        </div >
    )
}

export default IndividualRequirement