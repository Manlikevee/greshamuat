"use client"

import { Country, State } from 'country-state-city'
import { useEffect, useState } from 'react'
import { options, stateLga } from '@/utils/constants'
import { getRelevantData } from '@/utils/filter'
import FormInfoFields from '../../FormInfoFields'
import { validateForm } from '@/utils/FormValidator'
import { handleChange, handleDateChange, handlePhoneNoChange, handleSelect } from '@/utils/InputFunctions'

const allFields = {
    title: "", firstName: "", middleName: "", lastName: "", email: "", phoneNo: "", dob: "", maritalStatus: "", nationality: "", country: "", stateOfOrigin: "", lga: "", religion: "", mothersMaidenName: "", residentAddress: "", nearestLandmark: "", id: "", idNo: "", sex: "",
}

const PersonalInfo = ({ activeId, setActiveId, validate, setValidate, NextForm }) => {

    const user = JSON.parse(sessionStorage.getItem("user"))

    const [initData, setInitData] = useState(JSON.parse(sessionStorage.getItem("formData")))

    const relevantData = getRelevantData(allFields, initData)
    const [formData, setFormData] = useState(relevantData || {
        ...allFields, firstName: user.firstName, lastName: user.lastName, email: user.email, phoneNo: user.phoneNo
    })
    const [startDate, setStartDate] = useState(new Date())
    const allCountry = Country.getAllCountries()
    const countryNames = allCountry.map(country => country.name)
    const [selectedCountry, setSelectedCountry] = useState(formData.country || null)
    const selectedCountryInfo = allCountry.find(country => country.name === selectedCountry)
    const [selectedCountryStatesName, setSelectedCountryStatesName] = useState(null)
    const [error, setError] = useState({})
    const [resetState, setResetState] = useState(false)
    const [resetLga, setResetLga] = useState(false)
    const nigeriaState = stateLga.find((state) => state.state === formData?.stateOfOrigin)
    const [naijaState, setNaijaState] = useState("")

    useEffect(() => {
        setNaijaState(nigeriaState)
    }, [nigeriaState])

    useEffect(() => {
        if (selectedCountry) {
            if (selectedCountryInfo) {
                const countryStates = State.getStatesOfCountry(selectedCountryInfo.isoCode);
                setSelectedCountryStatesName(countryStates.map(state => state.name));
            } else {
                setSelectedCountryStatesName([]);
            }
        }

    }, [selectedCountry]);

    useEffect(() => {
        setInitData((prev) => ({ ...prev, ...formData }))
    }, [formData])



    useEffect(() => {

        sessionStorage.setItem("formData", JSON.stringify(initData))

    }, [initData])



    console.log(error)
    const formInfo = [
        {
            type: "select",
            placeholder: "Select Suffix",
            label: "Title",
            id: "title",
            option: options.title,
            selected: formData?.title,
            errMsg: error?.title,
            onClick: () => { setActiveId("title") },
            onSelect: (value) => { handleSelect("title", value, setFormData), setError((prev) => ({ ...prev, title: "" })) }

        },
        {

            type: "text",
            label: "First Name",
            name: "firstName",
            placeholder: "Enter First Name",
            value: formData.firstName,
            readOnly: true

        },
        {
            type: "text",
            label: "Middle Name",
            name: "middleName",
            placeholder: "Enter Middle Name",
            value: formData?.middleName,
            errMsg: error?.middleName,
            onChange: (e) => { handleChange(e, setFormData), setError((prev) => ({ ...prev, middleName: "" })) },
        },
        {
            type: "text",
            label: "Last Name",
            name: "lastName",
            placeholder: "Enter Last Name",
            value: formData?.lastName,
            readOnly: true



        },
        {
            type: "email",
            name: "email",
            value: formData.email,
            errMsg: error.email,
            readOnly: true,

            // onChange: (e) => {
            //     handleChange(e, setFormData),
            //         setError((prev) => ({ ...prev, email: "" }))
            // },
        },
        {
            type: "phoneNo",
            name: "phoneNo",
            value: formData.phoneNo || "",
            errMsg: error.phoneNo,
            onChange: (value) => {
                handlePhoneNoChange("phoneNo", value, setFormData),
                    setError((prev) => ({ ...prev, phoneNo: "" }))
            },
        },
        {
            type: "date",
            label: "Date of Birth",
            selected: formData?.dob || startDate,
            readOnly: false,
            errMsg: error?.dob,
            onCalendarClose: () => { handleDateChange("dob", setFormData, startDate) },
            onChange: (date) => {
                setStartDate(date), setError((prev) => ({ ...prev, dob: "" }))
            }
        },
        {
            type: "select",
            placeholder: "Select Marital Status",
            label: "Marital Status",
            id: "maritalStatus",
            option: options.maritalStatus,
            selected: formData?.maritalStatus,
            errMsg: error?.maritalStatus,
            onClick: () => { setActiveId("maritalStatus") },
            onSelect: (value) => {
                handleSelect("maritalStatus", value, setFormData),
                    setError((prev) => ({ ...prev, maritalStatus: "" }))
            }

        },
        {
            type: "select",
            placeholder: "Select Nationality",
            label: "Nationality",
            id: "nationality",
            option: countryNames,
            selected: formData?.nationality,
            errMsg: error?.nationality,

            onClick: () => {
                setActiveId("nationality"),
                    setResetState(true),
                    setResetLga(true)
            },
            onSelect: (value) => {
                handleSelect("nationality", value, setFormData),
                    setSelectedCountry(value), setError((prev) => ({ ...prev, nationality: "" }))
            }
        },
        {
            type: "select",
            placeholder: "Select Country",
            label: "Country",
            id: "country",
            option: countryNames,
            selected: formData?.country,
            errMsg: error?.country,

            onClick: () => {
                setActiveId("country"),
                    setResetState(true),
                    setResetLga(true)
            },
            onSelect: (value) => {
                handleSelect("country", value, setFormData),
                    setSelectedCountry(value), setError((prev) => ({ ...prev, country: "" }))
            }
        },
        {
            type: "select",
            placeholder: "Select State of Origin",
            label: "State of Origin",
            id: "stateOfOrigin",
            option: selectedCountryStatesName || ["Others"],
            selected: formData?.stateOfOrigin,
            reset: resetState,
            setReset: setResetState,
            errMsg: error?.stateOfOrigin,

            onClick: () => { setActiveId("stateOfOrigin"), setResetLga(true) },
            onSelect: (value) => { handleSelect("stateOfOrigin", value, setFormData), setError((prev) => ({ ...prev, stateOfOrigin: "" })) }
        },
        {
            type: "select",
            placeholder: "Select LGA",
            label: "LGA",
            id: "lga",
            option: naijaState?.lgas || ["Others"],
            selected: formData?.lga,
            reset: resetLga,
            setReset: setResetLga,
            errMsg: error?.lga,

            onClick: () => { setActiveId("lga") },
            onSelect: (value) => { handleSelect("lga", value, setFormData), setError((prev) => ({ ...prev, lga: "" })) }
        },
        {
            type: "select",
            placeholder: "Select Gender",
            label: "sex",
            id: "sex",
            option: options.sex,
            selected: formData?.sex,
            errMsg: error?.sex,

            onClick: () => { setActiveId("sex") },
            onSelect: (value) => { handleSelect("sex", value, setFormData), setError((prev) => ({ ...prev, sex: "" })) }

        },
        {
            type: "select",
            placeholder: "Select Religion",
            label: "Religion",
            id: "religion",
            option: options.religion,
            selected: formData?.religion,
            errMsg: error?.religion,

            onClick: () => { setActiveId("religion") },
            onSelect: (value) => { handleSelect("religion", value, setFormData), setError((prev) => ({ ...prev, religion: "" })) }
        },
        {
            type: "text",
            label: "Mother's Maiden Name",
            name: "mothersMaidenName",
            placeholder: "Enter Mothers Maiden Name",
            value: formData.mothersMaidenName || "",
            errMsg: error.mothersMaidenName,

            onChange: (e) => { handleChange(e, setFormData), setError((prev) => ({ ...prev, mothersMaidenName: "" })) },
        },
        {
            type: "text",
            label: "Nearest Landmark",
            name: "nearestLandmark",
            placeholder: "Enter Nearest LandMark",
            value: formData.nearestLandmark || "",
            errMsg: error.nearestLandmark,

            onChange: (e) => { handleChange(e, setFormData), setError((prev) => ({ ...prev, nearestLandmark: "" })) },
        },

        {
            type: "address",
            label: "Residential Address",
            name: "residentAddress",
            placeholder: "Enter residential address",
            value: formData?.residentAddress,
            errMsg: error?.residentAddress,
            onChange: (e) => { handleChange(e, setFormData), setError((prev) => ({ ...prev, residentAddress: "" })) },
        },

        {
            type: "select",
            placeholder: "Select ID type",
            label: "ID Type",
            id: "id",
            option: options.id,
            selected: formData.id || "",
            errMsg: error.id,
            onClick: () => { setActiveId("id") },
            onSelect: (value) => { handleSelect("id", value, setFormData), setError((prev) => ({ ...prev, id: "" })) }

        },
        {
            type: "text",
            label: "ID Number",
            name: "idNo",
            placeholder: "Enter Parent or ID Number",
            value: formData.idNo || "",
            errMsg: error.idNo,

            onChange: (e) => { handleChange(e, setFormData), setError((prev) => ({ ...prev, idNo: "" })) },
        },

    ]


    useEffect(() => {
        if (validate) {
            validateForm(formData, setError, NextForm)
            setValidate(false)
        }

    }, [validate])





    return (

        <FormInfoFields formInfo={formInfo} activeId={activeId} />

    )
}

export default PersonalInfo
