"use client"


import PhoneNoInput from "@/components/ui/PhoneNoInput"
import { useEffect, useState } from "react"
import { styles } from '@/utils/constants'
import { validateForm } from "@/utils/FormValidator"
import { getRelevantData } from "@/utils/filter"
import FormInfoFields from "../../FormInfoFields"
import { handleChange, handlePhoneNoChange } from "@/utils/InputFunctions"

const allFields = {
    nokFirstName: "", nokLastName: "", nokEmail: "", nokPhoneNo: "", nokAddress: "",
}

const NextOfKin = ({ activeId, validate, setValidate, NextForm }) => {
    const [initData, setInitData] = useState(JSON.parse(sessionStorage.getItem("formData")))
    const relevantData = getRelevantData(allFields, initData)
    const [formData, setFormData] = useState(relevantData || allFields)

    const [error, setError] = useState({})

    useEffect(() => {
        setInitData((prev) => ({ ...prev, ...formData }))
    }, [formData])

    useEffect(() => {
        sessionStorage.setItem("formData", JSON.stringify(initData))
    }, [initData])

    const formInfo = [
        {
            type: "text",
            label: "Next of Kin First Name",
            name: "nokFirstName",
            placeholder: "Enter next of kin's first Name",
            value: formData?.nokFirstName,
            errMsg: error?.nokFirstName,
            onChange: (e) => {
                handleChange(e, setFormData),
                    setError((prev) => ({ ...prev, nokFirstName: "" }))
            },
        },
        {
            type: "text",
            label: "Next of Kin Last Name",
            name: "nokLastName",
            placeholder: "Enter Next of kin's Last Name",
            value: formData?.nokLastName,
            errMsg: error?.nokLastName,
            onChange: (e) => {
                handleChange(e, setFormData),
                    setError((prev) => ({ ...prev, nokLastName: "" }))
            },
        },
        {
            type: "email",
            name: "nokEmail",
            value: formData.nokEmail,
            errMsg: error.nokEmail,
            onChange: (e) => {
                handleChange(e, setFormData),
                    setError((prev) => ({ ...prev, nokEmail: "" }))
            },
        },
        {
            type: "phoneNo",
            name: "nokPhoneNo",
            value: formData.nokPhoneNo || "",
            errMsg: error.nokPhoneNo,
            onChange: (value) => {
                handlePhoneNoChange("nokPhoneNo", value, setFormData),
                    setError((prev) => ({ ...prev, nokPhoneNo: "" }))
            },
        },

        {
            type: "address",
            label: "Next of Kin address Address",
            name: "nokAddress",
            placeholder: "Enter Next of Kin address",
            value: formData?.nokAddress,
            errMsg: error?.nokAddress,
            onChange: (e) => { handleChange(e, setFormData), setError((prev) => ({ ...prev, nokAddress: "" })) },
        },


    ]


    useEffect(() => {
        if (validate) {
            validateForm(formData, setError, NextForm)
            setValidate(false)
        }
    }, [validate])

    return (
        <FormInfoFields formInfo={formInfo} activeId={activeId} />
    )
}

export default NextOfKin




