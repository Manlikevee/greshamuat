"use client"
import { useEffect, useState } from "react"
import { options } from '@/utils/constants'
import { validateForm } from "@/utils/FormValidator"
import { getRelevantData } from "@/utils/filter"
import FormInfoFields from "../../FormInfoFields"
import { handleChange, handleSelect } from "@/utils/InputFunctions"

const allFields = {
    jobTitle: "", workSector: "", officeAddress: "", sourceOfIncome: "", risk: "",

}

const EmploymentInfo = ({ activeId, setActiveId, validate, setValidate, NextForm }) => {
    const [initData, setInitData] = useState(JSON.parse(sessionStorage.getItem("formData")))
    const relevantData = getRelevantData(allFields, initData)
    const [formData, setFormData] = useState(relevantData || allFields)

    const [error, setError] = useState({})

    useEffect(() => {
        setInitData((prev) => ({ ...prev, ...formData }))
    }, [formData])

    useEffect(() => {
        sessionStorage.setItem("formData", JSON.stringify(initData))
    }, [initData])


    const formInfo = [
        {
            type: "text",
            label: "Job Title",
            name: "jobTitle",
            placeholder: "Enter First Name",
            value: formData?.jobTitle,
            errMsg: error?.jobTitle,
            onChange: (e) => {
                handleChange(e, setFormData),
                    setError((prev) => ({ ...prev, jobTitle: "" }))
            },
        },
        {
            type: "select",
            placeholder: "Select Suffix",
            label: "Work Sector",
            id: "workSector",
            option: options.workSector,
            selected: formData?.workSector,
            errMsg: error?.workSector,
            onClick: () => { setActiveId("workSector") },
            onSelect: (value) => { handleSelect("workSector", value, setFormData), setError((prev) => ({ ...prev, workSector: "" })) }

        },
        {
            type: "address",
            label: "Office Address",
            name: "officeAddress",
            placeholder: "Enter Office address",
            value: formData?.officeAddress,
            errMsg: error?.officeAddress,
            onChange: (e) => { handleChange(e, setFormData), setError((prev) => ({ ...prev, officeAddress: "" })) },
        },
        {
            type: "text",
            label: "Source of Income",
            name: "sourceOfIncome",
            placeholder: "enter source of income",
            value: formData.sourceOfIncome || "",
            errMsg: error?.sourceOfIncome,

            onChange: (e) => {
                handleChange(e, setFormData),
                    setError((prev) => ({ ...prev, sourceOfIncome: "" }))
            },
        },
        {
            type: "select",
            placeholder: "Select risk level",
            label: "Risk Tolerance",
            id: "risk",
            option: options.risk,
            selected: formData?.risk,
            errMsg: error?.risk,
            onClick: () => { setActiveId("risk") },
            onSelect: (value) => { handleSelect("risk", value, setFormData), setError((prev) => ({ ...prev, risk: "" })) }
        },
    ]


    useEffect(() => {
        if (validate) {
            validateForm(formData, setError, NextForm)
            setValidate(false)
        }
    }, [validate])




    return (
        <FormInfoFields formInfo={formInfo} activeId={activeId} />
    )


}

export default EmploymentInfo

