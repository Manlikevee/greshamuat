"use client"

import Select from '@/components/ui/Select'
import React, { useEffect, useState } from 'react'
import { styles, banks, options } from '@/utils/constants'
import FormInfoFields from '../FormInfoFields'
import { handleChange, handleNoChange, handleSelect } from '@/utils/InputFunctions'
import { getRelevantData } from '@/utils/filter'
import { validateForm } from '@/utils/FormValidator'


const allFields = {
    bankName: "", accountNo: "", bvn: "", accountName: "",
}

const BankInfo = ({ activeId, setActiveId, validate, setValidate, NextForm }) => {
    const [initData, setInitData] = useState(JSON.parse(localStorage.getItem("formData")))
    const relevantData = getRelevantData(allFields, initData)
    const [formData, setFormData] = useState(relevantData || allFields)
    const [error, setError] = useState({})
    const bankName = banks.map((bank) => bank.name)


    console.log(formData)

    useEffect(() => {
        setInitData((prev) => ({ ...prev, ...formData }))
    }, [formData])

    useEffect(() => {
        localStorage.setItem("formData", JSON.stringify(initData))
    }, [initData])









    const formInfo = [
        {
            type: "select",
            placeholder: "Select Bank Name",
            label: "Bank Name",
            id: "bank",
            option: bankName,
            selected: formData.bankName || "",
            errMsg: error?.bankName,
            onClick: () => { setActiveId("bank") },
            onSelect: (value) => {
                handleSelect("bankName", value, setFormData),
                    setError((prev) => ({ ...prev, bankName: "" }))

            }
        },
        {
            type: "text",
            label: "Account Number",
            name: "accountNo",
            placeholder: "e.g 0022662200",
            value: formData.accountNo,
            errMsg: error?.accountNo,

            onChange: (e) => {
                handleNoChange(e, setFormData),
                    setError((prev) => ({ ...prev, accountNo: "" }))
            },
        },
        {
            type: "text",
            label: "BVN",
            name: "bvn",
            placeholder: "e.g 0022662200",
            value: formData.bvn || "",
            errMsg: error?.bvn,

            onChange: (e) => {
                handleNoChange(e, setFormData),
                    setError((prev) => ({ ...prev, bvn: "" }))

            },
        },
        {
            type: "text",
            label: "Account Name",
            name: "accountName",
            placeholder: "e.g 0022662200",
            value: formData.accountName || "",
            errMsg: error?.accountName,

            onChange: (e) => {
                handleChange(e, setFormData),
                    setError((prev) => ({ ...prev, accountName: "" }))

            },
            readOnly: true,
        },
    ]

    useEffect(() => {
        if (validate) {
            validateForm(formData, setError, NextForm)
            setValidate(false)
        }

    }, [validate])

    return (
        <FormInfoFields formInfo={formInfo} activeId={activeId} />
    )
}

export default BankInfo
