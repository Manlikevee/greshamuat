"use client"

import { options } from "@/utils/constants"
import { handleChange, handleDateChange, handleSelect } from "@/utils/InputFunctions"
import { Country, State } from "country-state-city"
import { useEffect, useState } from "react"
import { stateLga } from "@/utils/constants"
import FormInfoFields from "../../FormInfoFields"
import { validateForm } from "@/utils/FormValidator"
import { getRelevantData } from "@/utils/filter"

const allFields = {
    firstName: "", middleName: "", lastName: "", dob: "", sex: "", religion: "", nationality: "",
    stateOfOrigin: "", lga: "", residentAddress: ""
}

const ChildrenPersonalInfo = ({ activeId, setActiveId, validate, setValidate, NextForm }) => {

    const [initData, setInitData] = useState(JSON.parse(sessionStorage.getItem("formData")))
    const relevantData = getRelevantData(allFields, initData)
    const [formData, setFormData] = useState(relevantData || allFields)


    const [startDate, setStartDate] = useState(new Date())
    const allCountry = Country.getAllCountries()
    const countryNames = allCountry.map(country => country.name)
    const [selectedCountry, setSelectedCountry] = useState(formData?.country || null)
    const selectedCountryInfo = allCountry.find(country => country.name === selectedCountry)
    const [selectedCountryStatesName, setSelectedCountryStatesName] = useState(["Others"])
    const [error, setError] = useState({})
    const [resetState, setResetState] = useState(false)
    const [resetLga, setResetLga] = useState(false)
    const nigeriaState = stateLga.find((state) => state.state === formData?.stateOfOrigin)
    const [naijaState, setNaijaState] = useState("")



    useEffect(() => {
        setNaijaState(nigeriaState)
    }, [nigeriaState])

    useEffect(() => {
        if (selectedCountry) {
            if (selectedCountryInfo) {
                const countryStates = State.getStatesOfCountry(selectedCountryInfo.isoCode);
                setSelectedCountryStatesName(countryStates.map(state => state.name));
            } else {
                setSelectedCountryStatesName([]);
            }
        }

    }, [selectedCountry]);

    useEffect(() => {
        setInitData((prev) => ({ ...prev, ...formData }))
    }, [formData])

    useEffect(() => {
        sessionStorage.setItem("formData", JSON.stringify(initData))
    }, [initData])


    const formInfo = [
        {

            type: "text",
            label: "First Name",
            name: "firstName",
            placeholder: "Enter First Name",
            value: formData?.firstName,
            errMsg: error?.firstName,
            onChange: (e) => {
                handleChange(e, setFormData),
                    setError((prev) => ({ ...prev, firstName: "" }))
            },
        },
        {
            type: "text",
            label: "Middle Name",
            name: "middleName",
            placeholder: "Enter Middle Name",
            value: formData?.middleName,
            errMsg: error?.middleName,
            onChange: (e) => { handleChange(e, setFormData), setError((prev) => ({ ...prev, middleName: "" })) },
        },
        {
            type: "text",
            label: "Last Name",
            name: "lastName",
            placeholder: "Enter Last Name",
            value: formData?.lastName,
            errMsg: error?.lastName,

            onChange: (e) => {
                handleChange(e, setFormData),
                    setError((prev) => ({ ...prev, lastName: "" }))
            },
        },
        {
            type: "date",
            label: "Date of Birth",
            selected: formData?.dob || startDate,
            readOnly: false,
            errMsg: error?.dob,
            onCalendarClose: () => { handleDateChange("dob", setFormData, startDate) },
            onChange: (date) => {
                setStartDate(date), setError((prev) => ({ ...prev, dob: "" }))
            }
        },
        {
            type: "select",
            placeholder: "Select Gender",
            label: "sex",
            id: "sex",
            option: options.sex,
            selected: formData?.sex,
            errMsg: error?.sex,

            onClick: () => { setActiveId("sex") },
            onSelect: (value) => { handleSelect("sex", value, setFormData), setError((prev) => ({ ...prev, sex: "" })) }

        },
        {
            type: "select",
            placeholder: "Select Religion",
            label: "Religion",
            id: "religion",
            option: options.religion,
            selected: formData?.religion,
            errMsg: error?.religion,

            onClick: () => { setActiveId("religion") },
            onSelect: (value) => { handleSelect("religion", value, setFormData), setError((prev) => ({ ...prev, religion: "" })) }
        },
        {
            type: "select",
            placeholder: "Select Nationality",
            label: "Nationality",
            id: "nationality",
            option: countryNames,
            selected: formData?.nationality,
            errMsg: error?.nationality,

            onClick: () => {
                setActiveId("nationality"),
                    setResetState(true),
                    setResetLga(true)
            },
            onSelect: (value) => {
                handleSelect("nationality", value, setFormData),
                    setSelectedCountry(value), setError((prev) => ({ ...prev, nationality: "" }))
            }
        },
        {
            type: "select",
            placeholder: "Select State of Origin",
            label: "State of Origin",
            id: "stateOfOrigin",
            option: selectedCountryStatesName || ["Others"],
            selected: formData?.stateOfOrigin,
            reset: resetState,
            setReset: setResetState,
            errMsg: error?.stateOfOrigin,

            onClick: () => { setActiveId("stateOfOrigin"), setResetLga(true) },
            onSelect: (value) => { handleSelect("stateOfOrigin", value, setFormData), setError((prev) => ({ ...prev, stateOfOrigin: "" })) }
        },
        {
            type: "select",
            placeholder: "Select LGA",
            label: "LGA",
            id: "lga",
            option: naijaState?.lgas || ["Others"],
            selected: formData?.lga,
            reset: resetLga,
            setReset: setResetLga,
            errMsg: error?.lga,

            onClick: () => { setActiveId("lga") },
            onSelect: (value) => { handleSelect("lga", value, setFormData), setError((prev) => ({ ...prev, lga: "" })) }
        },
        {
            type: "address",
            label: "Residential Address",
            name: "residentAddress",
            placeholder: "Enter residential address",
            value: formData?.residentAddress,
            errMsg: error?.residentAddress,
            onChange: (e) => { handleChange(e, setFormData), setError((prev) => ({ ...prev, residentAddress: "" })) },
        },

    ]

    useEffect(() => {
        if (validate) {
            validateForm(formData, setError, NextForm)
            setValidate(false)
        }

    }, [validate])



    return (
        <FormInfoFields formInfo={formInfo} activeId={activeId} />
    )
}

export default ChildrenPersonalInfo