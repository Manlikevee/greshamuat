"use client"
import { handleChange } from '@/utils/InputFunctions'
import { useEffect, useState } from 'react'
import FormInfoFields from '../../FormInfoFields'
import { getRelevantData } from '@/utils/filter'
import { validateForm } from '@/utils/FormValidator'

const allFields = {
    parentOccupation: "", parentEmployer: "", parentSourceOfIncome: "", investmentObjective: "", parentOfficeAddress: "",
}

const ParentEmploymentInfo = ({ validate, setValidate, NextForm }) => {
    const [initData, setInitData] = useState(JSON.parse(sessionStorage.getItem("formData")))
    const relevantData = getRelevantData(allFields, initData)
    const [formData, setFormData] = useState(relevantData || allFields)
    const [error, setError] = useState({})


    useEffect(() => {
        setInitData((prev) => ({ ...prev, ...formData }))
    }, [formData])

    useEffect(() => {
        sessionStorage.setItem("formData", JSON.stringify(initData))
    }, [initData])

    const formInfo = [
        {
            type: "text",
            label: "Parent/Guardian Occupation",
            name: "parentOccupation",
            placeholder: "Enter Parent or Guidian Occupation",
            value: formData.parentOccupation || "",
            errMsg: error?.parentOccupation,
            onChange: (e) => {
                handleChange(e, setFormData),
                    setError((prev) => ({ ...prev, parentOccupation: "" }))
            },
        },
        {
            type: "text",
            label: "Employer",
            name: "parentEmployer",
            placeholder: "e.g gresham investment inc",
            value: formData.parentEmployer || "",
            errMsg: error?.parentEmployer,

            onChange: (e) => {
                handleChange(e, setFormData),
                    setError((prev) => ({ ...prev, parentEmployer: "" }))

            },
        },
        {
            type: "text",
            label: "Source of Income",
            name: "parentSourceOfIncome",
            placeholder: "enter source of income",
            value: formData.parentSourceOfIncome || "",
            errMsg: error?.parentSourceOfIncome,

            onChange: (e) => {
                handleChange(e, setFormData),
                    setError((prev) => ({ ...prev, parentSourceOfIncome: "" }))

            },
        },
        {
            type: "text",
            label: "Investment Objective",
            name: "investmentObjective",
            placeholder: "Please Enter investment objective",
            value: formData.investmentObjective || "",
            errMsg: error?.investmentObjective,

            onChange: (e) => {
                handleChange(e, setFormData),
                    setError((prev) => ({ ...prev, investmentObjective: "" }))

            },
        },
        {
            type: "address",
            label: "Office Address",
            name: "parentOfficeAddress",
            placeholder: "Please Enter Office Address",
            value: formData.parentOfficeAddress || "",
            errMsg: error?.parentOfficeAddress,

            onChange: (e) => {
                handleChange(e, setFormData),
                    setError((prev) => ({ ...prev, parentOfficeAddress: "" }))
            },
        },
    ]

    useEffect(() => {
        if (validate) {
            validateForm(formData, setError, NextForm)
            setValidate(false)
        }

    }, [validate])


    return (
        <FormInfoFields formInfo={formInfo} />
    )
}

export default ParentEmploymentInfo



