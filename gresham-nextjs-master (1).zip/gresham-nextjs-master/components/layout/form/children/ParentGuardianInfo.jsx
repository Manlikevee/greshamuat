"use client"
import { options } from '@/utils/constants'
import { handleChange, handlePhoneNoChange, handleSelect } from '@/utils/InputFunctions'
import { useEffect, useState } from 'react'
import FormInfoFields from '../../FormInfoFields'
import { validateForm } from '@/utils/FormValidator'
import { getRelevantData } from '@/utils/filter'


const allFields = {
    parentName: "", parentPhoneNo: "", id: "", idNo: "", parentEmail: ""

}


const ParentGuardianInfo = ({ activeId, setActiveId, validate, setValidate, NextForm }) => {
    const [initData, setInitData] = useState(JSON.parse(sessionStorage.getItem("formData")))

    const relevantData = getRelevantData(allFields, initData)


    const [formData, setFormData] = useState(relevantData || allFields)
    const [error, setError] = useState({})

    console.log("err", error)

    useEffect(() => {
        setInitData((prev) => ({ ...prev, ...formData }))
    }, [formData])

    useEffect(() => {
        sessionStorage.setItem("formData", JSON.stringify(initData))
    }, [initData])

    const formInfo = [
        {
            type: "text",
            label: "Parent/Guardian Name",
            name: "parentName",
            placeholder: "Enter Parent or Guidian name",
            value: formData.parentName || "",
            errMsg: error.parentName,
            onChange: (e) => { handleChange(e, setFormData), setError((prev) => ({ ...prev, parentName: "" })) },
        },
        {
            type: "phoneNo",
            name: "parentPhoneNo",
            value: formData.parentPhoneNo || "",
            errMsg: error.parentPhoneNo,

            onChange: (value) => { handlePhoneNoChange("parentPhoneNo", value, setFormData), setError((prev) => ({ ...prev, parentPhoneNo: "" })) },
        },
        {
            type: "email",
            name: "parentEmail",
            value: formData.parentEmail,
            errMsg: error.parentEmail,
            onChange: (e) => { handleChange(e, setFormData), setError((prev) => ({ ...prev, parentEmail: "" })) },
        },
        {
            type: "select",
            placeholder: "Select ID type",
            label: "ID Type",
            id: "id",
            option: options.id,
            selected: formData.id || "",
            errMsg: error.id,
            onClick: () => { setActiveId("id") },
            onSelect: (value) => { handleSelect("id", value, setFormData), setError((prev) => ({ ...prev, id: "" })) }

        },
        {
            type: "text",
            label: "ID Number",
            name: "idNo",
            placeholder: "Enter Parent or ID Number",
            value: formData.idNo || "",
            errMsg: error.idNo,

            onChange: (e) => { handleChange(e, setFormData), setError((prev) => ({ ...prev, idNo: "" })) },
        },
    ]

    console.log(error)
    console.log(formData)

    useEffect(() => {
        if (validate) {
            validateForm(formData, setError, NextForm)
            setValidate(false)

        } else {

        }

    }, [validate])

    return (
        <FormInfoFields formInfo={formInfo} activeId={activeId} />
    )
}

export default ParentGuardianInfo