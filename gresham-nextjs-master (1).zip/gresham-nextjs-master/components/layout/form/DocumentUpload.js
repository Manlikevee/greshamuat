"use client"

import { IoCloudUploadSharp } from 'react-icons/io5'
import { FaUpload } from "react-icons/fa6";
import { useEffect, useState } from 'react';
import { styles } from '@/utils/constants'

const DocumentUpload = ({

    validate,
    setValidate,
    submitForm,
    isFileSelected,
    setIsfileSelected,
    files,
    setFiles,
    setFile,
    file

}) => {

    const [formData, setFormData] = useState({})
    const [error, setError] = useState({})
    useEffect(() => {
        sessionStorage.setItem("kycDocs", JSON.stringify(formData))
    }, [formData])



    const handleFileChange = (e) => {
        const image = e.target.files[0]
        setFile((prev) => ({
            ...prev, [e.target.name]: image
        }))
        const reader = new FileReader()
        console.log(image)

        // Set maximum image size to 2MB
        const maxSize = 2 * 1024 * 1024; // 2MB

        if (image.size > maxSize) {
            setError((prev) => ({
                ...prev, [e.target.name]: "Selected image is larger than 2MB"
            }))
            // Display error message or prevent image upload
            return;
        }


        reader.onload = () => {
            const imgUrl = reader.result
            setFormData((prev) => ({
                ...prev, [e.target.name]: imgUrl
            }))
            setIsfileSelected((prev) => ({
                ...prev,
                [e.target.name]: true
            }))

            setFiles((prev) => ({
                ...prev,
                [e.target.name]: {
                    name: image.name,
                    size: image.size,
                    type: image.type,
                    image: imgUrl,
                }
            }))
        }

        reader.readAsDataURL(image)
    }



    const fileUploadData = {
        passportPhoto: formData.passportPhoto,
        utility: formData.utility,

    }

    const validationSchema = {
        passportPhoto: {
            required: true,
            message: {
                required: "Passport Photograph upload is required"
            }
        },
        utility: {
            required: true,
            message: {
                required: "Utility Bill upload is required"
            }
        },

    }

    const validateInput = (data) => {
        const errors = {}

        Object.keys(validationSchema).forEach((field) => {
            const value = data[field]
            const rule = validationSchema[field]

            if (rule.required && !value) {
                errors[field] = rule.message.required
            }
        })
        return errors
    }

    const validateForm = () => {
        const errors = validateInput(fileUploadData)
        console.log(errors)
        if (Object.keys(errors).length > 0) {
            console.log(errors)
            setError(errors)
            window.scrollTo(0, 0)
        } else if (error.length > 0) {
            console.log("one found error")
        } else {
            submitForm()


        }
    }

    useEffect(() => {
        if (validate) {
            validateForm()
            setValidate(false)
        }
    }, [validate])


    return (
        <div className='grid gap-6'>


            <div className={`${styles.inputFieldStyle} `}>

                <small>Passport Photo <span className={styles.red}>*</span></small>
                <input
                    name='passportPhoto'
                    onChange={(e) => { handleFileChange(e) }}
                    type="file"
                    accept="image/*"
                    id="passport" className="hidden"
                />


                {isFileSelected.passportPhoto
                    ? <div className='flex p-4 flex-col md:flex-row  md:items-end gap-6'>
                        <div className=' h-[20rem] w-full  md:w-64  md:aspect-square rounded-lg bg-contain bg-no-repeat bg-center'
                            style={{
                                backgroundImage: `url(${files.passportPhoto?.image})`
                            }}>

                        </div>

                        <div className='grid gap-4 md:gap-8'>
                            <div className='grid gap-1'>
                                <p className=' text-nowrap text-ellipsis overflow-hidden text-black/60'><span className='text-baseblue'>Name: </span>{files.passportPhoto?.name}</p>
                                <p className=' text-black/60'><span className='text-baseblue'>Size: </span>{(files.passportPhoto?.size / (1024 * 1024)).toFixed(4)} MB</p>
                            </div>

                            <label className='bg-baseblue justify-center flex gap-4 w-full md:w-fit text-white rounded-md py-4 px-6 cursor-pointer' htmlFor="passport">
                                Change Image <FaUpload />

                            </label>
                        </div>
                    </div> :

                    <div >

                        <div className='w-full'>
                            <label htmlFor="passport" className="grid place-content-center bg-[#f6f6f6] h-[182px] cursor-pointer rounded-sm text-6xl justify-center transition-[all_0.25s_ease-in-out]">
                                <IoCloudUploadSharp className="mx-auto" />
                                <p className='text-base text-center'>Click to  upload image</p>
                                <p className='text-base text-center'>maximum size <span className='text-baseblue' >2MB</span></p>
                                <small className="text-red-500 text-sm text-center mt-4">{error.passportPhoto}</small>

                            </label>

                        </div>



                    </div>
                }



            </div>


            <div className={`${styles.inputFieldStyle} `}>

                <small>Utility Photo <span className={styles.red}>*</span></small>
                <input
                    name='utility'
                    onChange={(e) => { handleFileChange(e) }}
                    type="file"
                    accept="image/*"
                    id="utility" className="hidden"

                />

                {isFileSelected.utility
                    ? <div className='flex p-4 flex-col md:flex-row  md:items-end gap-6'>
                        <div className=' h-[20rem] w-full md:w-64 md:aspect-square rounded-lg bg-contain bg-no-repeat bg-center'
                            style={{
                                backgroundImage: `url(${files.utility?.image})`
                            }}>

                        </div>

                        <div className='grid gap-4 md:gap-8'>
                            <div className='grid gap-1'>
                                <p className=' text-nowrap text-ellipsis overflow-hidden text-black/60'><span className='text-baseblue'>Name: </span>{files.utility?.name}</p>
                                <p className=' text-black/60'><span className='text-baseblue'>Size: </span>{(files.utility?.size / (1024 * 1024)).toFixed(4)} MB</p>
                            </div>

                            <label className='bg-baseblue justify-center flex gap-4 w-full md:w-fit text-white rounded-md py-4 px-6 cursor-pointer' htmlFor="utility">
                                Change Image <FaUpload />

                            </label>
                        </div>
                    </div> :

                    <div >

                        <div className='w-full'>
                            <label htmlFor="utility" className="grid place-content-center bg-[#f6f6f6] h-[182px] cursor-pointer rounded-sm text-6xl justify-center transition-[all_0.25s_ease-in-out]">
                                <IoCloudUploadSharp className="mx-auto" />
                                <p className='text-base text-center'>Click to  upload image</p>
                                <p className='text-base text-center'>maximum size <span className='text-baseblue' >2MB</span></p>
                                <small className="text-red-500 text-sm text-center mt-4">{error.utility}</small>

                            </label>

                        </div>



                    </div>
                }



            </div>


        </div>
    )
}

export default DocumentUpload