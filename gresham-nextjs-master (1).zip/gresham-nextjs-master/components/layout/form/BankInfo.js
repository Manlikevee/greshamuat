"use client"

import { useEffect, useState } from 'react'
import { banks } from '@/utils/constants'
import FormInfoFields from '../FormInfoFields'
import { handleNoChange, handleSelect } from '@/utils/InputFunctions'
import { getRelevantData } from '@/utils/filter'
import { validateForm } from '@/utils/FormValidator'
import toast, { Toaster } from 'react-hot-toast'


const allFields = {
    bankName: "", accountNo: "", bvn: "", accountName: "",
}

const BankInfo = ({ activeId, setActiveId, validate, setValidate, NextForm }) => {
    const [initData, setInitData] = useState(JSON.parse(localStorage.getItem("formData")))
    const relevantData = getRelevantData(allFields, initData)
    const [formData, setFormData] = useState(relevantData || allFields)
    const [isLoading, setIsLoading] = useState(false)
    const [error, setError] = useState({})
    const bankName = banks.map((bank) => bank.name)

    const [selectedBank, setSelectedBank] = useState(formData.bankName || "")
    const [accountName, setAccountName] = useState(formData.accountName || "")


    const bankCode = banks.filter(bank => bank.name === selectedBank)[0]?.code


    useEffect(() => {
        setInitData((prev) => ({ ...prev, ...formData }))
    }, [formData])

    useEffect(() => {
        localStorage.setItem("formData", JSON.stringify(initData))
    }, [initData])

    const notify = (type, message) => toast[type](message)


    useEffect(() => {
        const getAccountDetails = async () => {
            if (!accountName) {
                try {
                    const res = await fetch(`http://api.issl.ng:7777/ibank/api/v1/getbankaccountdetails?bankcode=${bankCode}&nuban=${formData.accountNo}`)
                    const data = await res.json()
                    if (res.ok) {

                        const accName = data.account_name
                        !accName && setError((prev) => ({ ...prev, accountName: "failed to fetch account name Check account number and try again" }))

                        setAccountName(accName)
                        setFormData((prev) => ({ ...prev, accountName: accName }))
                    }
                } catch {
                    console.log("couldn't get account name")
                    notify("error", "No internet connection")
                }
            }


        }

        if (formData.accountNo.length === 10 && bankCode) {
            getAccountDetails()
        } else {
            setAccountName("")
            setFormData((prev) => ({ ...prev, accountName: "" }))

        }
    }, [formData.accountNo])




    const formInfo = [
        {
            type: "select",
            placeholder: "Select Bank Name",
            label: "Bank Name",
            id: "bank",
            option: bankName,
            selected: formData.bankName || "",
            errMsg: error?.bankName,
            onClick: () => { setActiveId("bank") },
            onSelect: (value) => {
                handleSelect("bankName", value, setFormData),
                    setError((prev) => ({ ...prev, bankName: "" })),
                    setFormData((prev) => ({ ...prev, accountNo: "", accountName: "" }))
                setSelectedBank(value)

            }
        },
        {
            type: "text",
            label: "Account Number",
            name: "accountNo",
            placeholder: "e.g 0022662200",
            value: formData.accountNo,
            errMsg: error?.accountNo,
            maxLength: 10,

            onChange: (e) => {
                handleNoChange(e, setFormData),
                    setError((prev) => ({ ...prev, accountNo: "", accountName: "" }))
            },
        },
        {
            type: "text",
            label: "BVN",
            name: "bvn",
            placeholder: "e.g 0022662200",
            value: formData.bvn || "",
            errMsg: error?.bvn,
            maxLength: 11,


            onChange: (e) => {
                handleNoChange(e, setFormData),
                    setError((prev) => ({ ...prev, bvn: "" }))

            },
        },
        {
            type: "text",
            label: "Account Name",
            name: "accountName",
            placeholder: "e.g 0022662200",
            value: accountName,
            errMsg: error?.accountName,
            readOnly: true,
        },
    ]

    useEffect(() => {
        if (validate) {
            validateForm(formData, setError, NextForm)
            setValidate(false)
        }

    }, [validate])

    return (
        <>
            <Toaster />
            <FormInfoFields formInfo={formInfo} activeId={activeId} />

        </>
    )
}

export default BankInfo
