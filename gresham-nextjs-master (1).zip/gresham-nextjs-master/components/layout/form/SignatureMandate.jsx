"use client"


import { useEffect } from 'react'

const SignatureMandate = ({ validate, setValidate, NextForm }) => {

    useEffect(() => {
        if (validate) {
            NextForm()
            setValidate(false)
        }

    }, [validate])
    return (
        <div>
            <p className='mb-6'>Kindly tick the authorized combination for all the mandates</p>
            <div className='grid gap-4'>
                <div className='flex gap-6'>
                    <p className='w-28'>Acting Alone</p>
                    <div className='flex gap-4 items-center' >
                        <div className='w-6 aspect-square'></div>
                        <div className='w-2 aspect-square '></div>
                        <div className='w-6 grid place-content-center aspect-square bg-baseblue text-white'>A</div>
                        <div>
                            <input defaultChecked className='hidden tick' id='tick1' name='tick' type="radio" />

                            <label htmlFor="tick1">
                                <div className='w-6 aspect-square border-2 rounded-sm border-baseblue cursor-pointer bg-white text-white'></div>
                            </label>
                        </div>
                        <p>Any one of the signatories</p>
                    </div>
                </div>
                <div className='flex gap-6'>
                    <p className='w-28'>Acting together</p>
                    <div className='flex gap-4 items-center' >
                        <div className='w-6 aspect-square grid place-content-center bg-baseblue text-white'>A</div>
                        <div className='w-2 grid place-content-center aspect-square'>+</div>
                        <div className='w-6 grid place-content-center aspect-square bg-baseblue text-white'>A</div>
                        <div>
                            <input className='hidden tick' id='tick2' name='tick' type="radio" />

                            <label htmlFor="tick2">
                                <div className='w-6 aspect-square border-2 rounded-sm border-baseblue cursor-pointer bg-white text-white'></div>
                            </label>
                        </div>
                        <p>Any one of the signatories</p>
                    </div>
                </div>
                <div className='flex gap-6'>
                    <p className='w-28'>Acting together</p>
                    <div className='flex gap-4 items-center' >
                        <div className='w-6 aspect-square grid place-content-center bg-baseblue text-white'>B</div>
                        <div className='w-2 grid place-content-center aspect-square'>+</div>
                        <div className='w-6 grid place-content-center aspect-square bg-baseblue text-white'>B</div>
                        <div>
                            <input className='hidden tick' id='tick3' name='tick' type="radio" />

                            <label htmlFor="tick3">
                                <div className='w-6 aspect-square border-2 rounded-sm border-baseblue cursor-pointer bg-white text-white'></div>
                            </label>
                        </div>
                        <p>Any one of the signatories</p>
                    </div>
                </div>
                <div className='flex gap-6'>
                    <p className='w-28'>Acting together</p>
                    <div className='flex gap-4 items-center' >
                        <div className='w-6 aspect-square grid place-content-center bg-baseblue text-white'>A</div>
                        <div className='w-2 grid place-content-center aspect-square'>+</div>
                        <div className='w-6 grid place-content-center aspect-square bg-baseblue text-white'>B</div>
                        <div>
                            <input className='hidden tick' id='tick4' name='tick' type="radio" />

                            <label htmlFor="tick4">
                                <div className='w-6 aspect-square border-2 rounded-sm border-baseblue cursor-pointer bg-white text-white'></div>
                            </label>
                        </div>
                        <p>Any one of the signatories</p>
                    </div>
                </div>

            </div>

        </div>
    )
}

export default SignatureMandate