
"use client"

import { options } from "@/utils/constants"
import { getRelevantData } from "@/utils/filter"
import { validateForm } from "@/utils/FormValidator"
import { useEffect, useState } from "react"
import FormInfoFields from "../../FormInfoFields"
import { handleChange, handleDateChange, handlePhoneNoChange, handleSelect } from "@/utils/InputFunctions"




const allFields = {
    estateName: "", companyPhoneNoA: "", companyPhoneNoB: "", companyEmail: "", companyWebsite: "", incorporationNumber: "", dateIncorporated: "", incorporationNumber: "", registeredAddress: "",
}
const EstateInfo = ({ activeId, setActiveId, validate, setValidate, NextForm }) => {

    const [initData, setInitData] = useState(JSON.parse(sessionStorage.getItem("formData")))
    const relevantData = getRelevantData(allFields, initData)
    const [formData, setFormData] = useState(relevantData || allFields)
    const [error, setError] = useState({})
    const [startDate, setStartDate] = useState(new Date())


    useEffect(() => {
        setInitData((prev) => ({ ...prev, ...formData }))
    }, [formData])

    useEffect(() => {
        sessionStorage.setItem("formData", JSON.stringify(initData))
    }, [initData])



    const formInfo = [
        {

            type: "text",
            label: "Estate Name",
            name: "estateName",
            placeholder: "Enter Joint Account Name",
            value: formData?.estateName,
            errMsg: error?.estateName,
            onChange: (e) => {
                handleChange(e, setFormData),
                    setError((prev) => ({ ...prev, estateName: "" }))
            },
        },
        {
            type: "phoneNo",
            name: "companyPhoneNoA",
            value: formData.companyPhoneNoA || "",
            errMsg: error.companyPhoneNoA,

            onChange: (value) => { handlePhoneNoChange("companyPhoneNoA", value, setFormData), setError((prev) => ({ ...prev, parentPhoneNo: "" })) },
        },
        {
            type: "phoneNo",
            name: "companyPhoneNoB",
            value: formData.companyPhoneNoB || "",
            errMsg: error.companyPhoneNoB,

            onChange: (value) => { handlePhoneNoChange("companyPhoneNoB", value, setFormData), setError((prev) => ({ ...prev, parentPhoneNo: "" })) },
        },
        {
            type: "email",
            name: "companyEmail",
            value: formData.companyEmail,
            errMsg: error.companyEmail,
            onChange: (e) => { handleChange(e, setFormData), setError((prev) => ({ ...prev, companyEmail: "" })) },
        },

        {
            type: "text",
            label: "Website",
            name: "companyWebsite",
            placeholder: "Please Enter company website ",
            value: formData.companyWebsite || "",
            errMsg: error?.companyWebsite,

            onChange: (e) => {
                handleChange(e, setFormData),
                    setError((prev) => ({ ...prev, companyWebsite: "" }))

            },
        },
        {
            type: "text",
            label: "Incorporation Number",
            name: "incorporationNumber",
            placeholder: "Please Enter Company Incorporation Number ",
            value: formData.incorporationNumber || "",
            errMsg: error?.incorporationNumber,

            onChange: (e) => {
                handleChange(e, setFormData),
                    setError((prev) => ({ ...prev, incorporationNumber: "" }))

            },
        },
        {
            type: "date",
            label: "Date Incorporated",
            selected: formData?.dateIncorporated || startDate,
            readOnly: false,
            errMsg: error?.dateIncorporated,
            onCalendarClose: () => { handleDateChange("dateIncorporated", setFormData, startDate) },
            onChange: (date) => {
                setStartDate(date), setError((prev) => ({ ...prev, dateIncorporated: "" }))
            }
        },
        {
            type: "address",
            label: "Registered Address",
            name: "registeredAddress",
            placeholder: "Enter Registered address",
            value: formData?.registeredAddress,
            errMsg: error?.registeredAddress,
            onChange: (e) => { handleChange(e, setFormData), setError((prev) => ({ ...prev, registeredAddress: "" })) },
        },
    ]

    useEffect(() => {
        if (validate) {
            validateForm(formData, setError, NextForm)
            setValidate(false)
        }

    }, [validate])

    return (
        <FormInfoFields formInfo={formInfo} activeId={activeId} />
    )
}

export default EstateInfo




