"use client"


import { Country, State } from 'country-state-city'
import { useEffect, useState } from 'react'
import { options, stateLga } from '@/utils/constants'
import { getRelevantData } from '@/utils/filter'
import FormInfoFields from '../../FormInfoFields'
import { validateForm } from '@/utils/FormValidator'
import { handleChange, handleDateChange, handlePhoneNoChange, handleSelect } from '@/utils/InputFunctions'






const allFields = {
    title: "", firstName: "", middleName: "", lastName: "", email: "", phoneNo: "", dob: "", maritalStatus: "", nationality: "", country: "", state: "", lga: "", religion: "", mothersMaidenName: "", residentAddress: "", id: "", idNo: "", sex: "", authorisedSignatoryEmployer: "", authorisedSignatorySourceOfIncome: "", signatureMandate: "", bvn: "",
}


const EstateAuthorizedSignatory = ({ activeId, setActiveId, validate, setValidate, NextForm }) => {
    const [initData, setInitData] = useState(JSON.parse(sessionStorage.getItem("formData")))

    const relevantData = getRelevantData(allFields, initData)
    const [formData, setFormData] = useState(relevantData || allFields)
    const [startDate, setStartDate] = useState(new Date())
    const allCountry = Country.getAllCountries()
    const countryNames = allCountry.map(country => country.name)
    const [selectedCountry, setSelectedCountry] = useState(formData.country || null)
    const selectedCountryInfo = allCountry.find(country => country.name === selectedCountry)
    const [selectedCountryStatesName, setSelectedCountryStatesName] = useState(null)
    const [error, setError] = useState({})
    const [resetState, setResetState] = useState(false)
    const [resetLga, setResetLga] = useState(false)
    const nigeriaState = stateLga.find((state) => state.state === formData?.stateOfOrigin)
    const [naijaState, setNaijaState] = useState("")


    console.log(relevantData)

    useEffect(() => {
        setNaijaState(nigeriaState)
    }, [nigeriaState])

    useEffect(() => {
        if (selectedCountry) {
            if (selectedCountryInfo) {
                const countryStates = State.getStatesOfCountry(selectedCountryInfo.isoCode);
                setSelectedCountryStatesName(countryStates.map(state => state.name));
            } else {
                setSelectedCountryStatesName([]);
            }
        }

    }, [selectedCountry]);

    useEffect(() => {
        setInitData((prev) => ({ ...prev, ...formData }))
    }, [formData])



    useEffect(() => {

        sessionStorage.setItem("formData", JSON.stringify(initData))

    }, [initData])



    console.log(error)
    const formInfo = [
        {
            type: "select",
            placeholder: "Select Suffix",
            label: "Title",
            id: "title",
            option: options.title,
            selected: formData?.title,
            errMsg: error?.title,
            onClick: () => { setActiveId("title") },
            onSelect: (value) => { handleSelect("title", value, setFormData), setError((prev) => ({ ...prev, title: "" })) }

        },
        {

            type: "text",
            label: "First Name",
            name: "firstName",
            placeholder: "Enter First Name",
            value: formData?.firstName,
            errMsg: error?.firstName,
            onChange: (e) => {
                handleChange(e, setFormData),
                    setError((prev) => ({ ...prev, firstName: "" }))
            },
        },
        {
            type: "text",
            label: "Middle Name",
            name: "middleName",
            placeholder: "Enter Middle Name",
            value: formData?.middleName,
            errMsg: error?.middleName,
            onChange: (e) => { handleChange(e, setFormData), setError((prev) => ({ ...prev, middleName: "" })) },
        },
        {
            type: "text",
            label: "Last Name",
            name: "lastName",
            placeholder: "Enter Last Name",
            value: formData?.lastName,
            errMsg: error?.lastName,

            onChange: (e) => {
                handleChange(e, setFormData),
                    setError((prev) => ({ ...prev, lastName: "" }))
            },
        },
        {
            type: "date",
            label: "Date of Birth",
            selected: formData?.dob || startDate,
            readOnly: false,
            errMsg: error?.dob,
            onCalendarClose: () => { handleDateChange("dob", setFormData, startDate) },
            onChange: (date) => {
                setStartDate(date), setError((prev) => ({ ...prev, dob: "" }))
            }
        },

        {
            type: "select",
            placeholder: "Select Gender",
            label: "sex",
            id: "sex",
            option: options.sex,
            selected: formData?.sex,
            errMsg: error?.sex,

            onClick: () => { setActiveId("sex") },
            onSelect: (value) => { handleSelect("sex", value, setFormData), setError((prev) => ({ ...prev, sex: "" })) }

        },
        {
            type: "select",
            placeholder: "Select Marital Status",
            label: "Marital Status",
            id: "maritalStatus",
            option: options.maritalStatus,
            selected: formData?.maritalStatus,
            errMsg: error?.maritalStatus,
            onClick: () => { setActiveId("maritalStatus") },
            onSelect: (value) => {
                handleSelect("maritalStatus", value, setFormData),
                    setError((prev) => ({ ...prev, maritalStatus: "" }))
            }

        },
        {
            type: "select",
            placeholder: "Select Nationality",
            label: "Nationality",
            id: "nationality",
            option: countryNames,
            selected: formData?.nationality,
            errMsg: error?.nationality,

            onClick: () => {
                setActiveId("nationality"),
                    setResetState(true),
                    setResetLga(true)
            },
            onSelect: (value) => {
                handleSelect("nationality", value, setFormData),
                    setSelectedCountry(value), setError((prev) => ({ ...prev, nationality: "" }))
            }
        },




        {
            type: "select",
            placeholder: "Select Country",
            label: "Country",
            id: "country",
            option: countryNames,
            selected: formData?.country,
            errMsg: error?.country,

            onClick: () => {
                setActiveId("country"),
                    setResetState(true),
                    setResetLga(true)
            },
            onSelect: (value) => {
                handleSelect("country", value, setFormData),
                    setSelectedCountry(value), setError((prev) => ({ ...prev, country: "" }))
            }
        },
        {
            type: "select",
            placeholder: "Select State of Origin",
            label: "State of Origin",
            id: "state",
            option: selectedCountryStatesName || ["Others"],
            selected: formData?.state,
            reset: resetState,
            setReset: setResetState,
            errMsg: error?.state,

            onClick: () => { setActiveId("state"), setResetLga(true) },
            onSelect: (value) => { handleSelect("state", value, setFormData), setError((prev) => ({ ...prev, stateOfOrigin: "" })) }
        },
        {
            type: "select",
            placeholder: "Select LGA",
            label: "LGA",
            id: "lga",
            option: naijaState?.lgas || ["Others"],
            selected: formData?.lga,
            reset: resetLga,
            setReset: setResetLga,
            errMsg: error?.lga,

            onClick: () => { setActiveId("lga") },
            onSelect: (value) => { handleSelect("lga", value, setFormData), setError((prev) => ({ ...prev, lga: "" })) }
        },

        {
            type: "select",
            placeholder: "Select Religion",
            label: "Religion",
            id: "religion",
            option: options.religion,
            selected: formData?.religion,
            errMsg: error?.religion,

            onClick: () => { setActiveId("religion") },
            onSelect: (value) => { handleSelect("religion", value, setFormData), setError((prev) => ({ ...prev, religion: "" })) }
        },
        {
            type: "text",
            label: "Mother's Maiden Name",
            name: "mothersMaidenName",
            placeholder: "Enter Mothers Maiden Name",
            value: formData.mothersMaidenName || "",
            errMsg: error.mothersMaidenName,

            onChange: (e) => { handleChange(e, setFormData), setError((prev) => ({ ...prev, mothersMaidenName: "" })) },
        },


        {
            type: "address",
            label: "Residential Address",
            name: "residentAddress",
            placeholder: "Enter residential address",
            value: formData?.residentAddress,
            errMsg: error?.residentAddress,
            onChange: (e) => { handleChange(e, setFormData), setError((prev) => ({ ...prev, residentAddress: "" })) },
        },
        {
            type: "phoneNo",
            name: "phoneNo",
            value: formData.phoneNo || "",
            errMsg: error.phoneNo,
            onChange: (value) => {
                handlePhoneNoChange("phoneNo", value, setFormData),
                    setError((prev) => ({ ...prev, phoneNo: "" }))
            },
        },
        {
            type: "email",
            name: "email",
            value: formData.email,
            errMsg: error.email,
            onChange: (e) => {
                handleChange(e, setFormData),
                    setError((prev) => ({ ...prev, email: "" }))
            },
        },
        {
            type: "select",
            placeholder: "Select ID type",
            label: "ID Type",
            id: "id",
            option: options.id,
            selected: formData.id || "",
            errMsg: error.id,
            onClick: () => { setActiveId("id") },
            onSelect: (value) => { handleSelect("id", value, setFormData), setError((prev) => ({ ...prev, id: "" })) }

        },
        {
            type: "text",
            label: "ID Number",
            name: "idNo",
            placeholder: "Enter Parent or ID Number",
            value: formData.idNo || "",
            errMsg: error.idNo,

            onChange: (e) => { handleChange(e, setFormData), setError((prev) => ({ ...prev, idNo: "" })) },
        },
        {
            type: "text",
            label: "Employer",
            name: "authorisedSignatoryEmployer",
            placeholder: "e.g gresham investment inc",
            value: formData.authorisedSignatoryEmployer || "",
            errMsg: error?.authorisedSignatoryEmployer,

            onChange: (e) => {
                handleChange(e, setFormData),
                    setError((prev) => ({ ...prev, authorisedSignatoryEmployer: "" }))

            },
        },
        {
            type: "text",
            label: "Source of Income",
            name: "parentSourceOfIncome",
            placeholder: "enter source of income",
            value: formData.authorisedSignatorySourceOfIncome || "",
            errMsg: error?.authorisedSignatorySourceOfIncome,

            onChange: (e) => {
                handleChange(e, setFormData),
                    setError((prev) => ({ ...prev, authorisedSignatorySourceOfIncome: "" }))

            },
        },
        {
            type: "select",
            placeholder: "Select Signature Mandate class",
            label: "Signature Mandate",
            id: "signatureMandate",
            option: options.signatureMandate,
            selected: formData?.signatureMandate,
            errMsg: error?.signatureMandate,
            onClick: () => { setActiveId("signatureMandate") },
            onSelect: (value) => {
                handleSelect("signatureMandate", value, setFormData),
                    setError((prev) => ({ ...prev, signatureMandate: "" }))
            }

        },
        {
            type: "text",
            label: "BVN",
            name: "bvn",
            placeholder: "e.g 0022662200",
            value: formData.bvn || "",
            errMsg: error?.bvn,

            onChange: (e) => {
                handleChange(e, setFormData),
                    setError((prev) => ({ ...prev, bvn: "" }))

            },
        },


    ]


    useEffect(() => {
        if (validate) {
            validateForm(formData, setError, NextForm)
            setValidate(false)
        }

    }, [validate])





    return (

        <FormInfoFields formInfo={formInfo} activeId={activeId} />

    )
}
export default EstateAuthorizedSignatory


