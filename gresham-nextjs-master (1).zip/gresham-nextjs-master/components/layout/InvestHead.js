import { IoCaretDownSharp } from "react-icons/io5";

const InvestHead = ({ investType, investName, investDescription, searchHolder }) => {
    return (
        <div className="">
            <p className="mb-4 lg:mb-8">Investment /  <span className="font-bold text-[#101111]">{investType}</span> </p>

            <div className="grid gap-6">
                <div className="briefing grid gap-4 text-[#101111]">
                    <p>{investName || "INVEST"}</p>
                    <p>{investDescription}</p>
                </div>
                {/* <div className="flex gap-4 md:gap-12 items-end w-full flex-wrap justify-end md:justify-between md:flex-nowrap">
                    <input type="text" className="py-3 px-4 w-full rounded-md lg:max-w-[555px] border-0 outline-0"
                        placeholder={searchHolder || "search something"}

                    />

                    <button className="flex items-center justify-between bg-white rounded-md py-3 px-4 w-[156px]">
                        Sort by
                        <IoCaretDownSharp />
                    </button>
                </div> */}
            </div>
        </div>

    )
}

export default InvestHead