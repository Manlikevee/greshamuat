import { styles } from "@/utils/constants"
import { AddressField, DateField, EmailField, PhoneNoField, SelectField, TextInputField } from "../ui/InputField"


const FormInfoFields = ({ formInfo, activeId }) => {
    return (
        <div className={styles.formContainer}>

            {
                formInfo.map((item, index) => {
                    return (
                        item.type === "date" ? <DateField
                            key={index}
                            label={item.label}
                            selected={item.selected}
                            onCalendarClose={item.onCalendarClose}
                            onChange={item.onChange}
                            readOnly={item.readOnly}
                            errorMsg={item.errMsg}

                        /> : item.type === "email" ? <EmailField
                            key={index}
                            value={item.value}
                            onChange={item.onChange}
                            name={item.name}
                            errorMsg={item.errMsg}

                        /> : item.type === "phoneNo" ? <PhoneNoField
                            key={index}
                            value={item.value}
                            onChange={item.onChange}
                            errorMsg={item.errMsg}

                        /> : item.type === "select" ? <SelectField
                            key={index}
                            label={item.label}
                            id={item.id}
                            placeholder={item.placeholder}
                            options={item.option}
                            onClick={item.onClick}
                            onSelect={item.onSelect}
                            activeId={activeId}
                            reset={item.reset}
                            setReset={item.setReset}
                            errorMsg={item.errMsg}
                            selected={item.selected}

                        /> : item.type === "address" ? <AddressField
                            key={index}
                            label={item.label}
                            name={item.name}
                            onChange={item.onChange}
                            value={item.value}
                            errorMsg={item.errMsg}

                        /> : <TextInputField
                            key={index}
                            label={item.label}
                            name={item.name}
                            value={item.value}
                            placeholder={item.placeholder}
                            onChange={item.onChange}
                            errorMsg={item.errMsg}
                            maxLength={item.maxLength}
                            readOnly={item.readOnly}

                        />
                    )
                })
            }
        </div>
    )
}

export default FormInfoFields