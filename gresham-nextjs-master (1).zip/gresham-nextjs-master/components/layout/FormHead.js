import Link from "next/link";
import { FaXmark } from "react-icons/fa6";

const FormHead = ({ formName }) => {
    return (
        <div className="flex gap-1">
            <div className="bg-red-500 inline-block h-14 md:h-16 w-5" ></div>
            <div className="bg-baseblue items-center px-4 justify-between text-white flex w-full">
                <h1 className="text-lg md:text-2xl">{formName}</h1>
                <Link href={"/"} className="bg-white rounded-full h-6 w-6 grid place-content-center">
                    <FaXmark className="text-baseblue" />
                </Link>

            </div>
        </div>
    )
}

export default FormHead