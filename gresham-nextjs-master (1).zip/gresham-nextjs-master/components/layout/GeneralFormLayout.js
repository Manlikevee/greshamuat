import FormHead from "./FormHead"


const GeneralFormLayout = ({ formName, children }) => {
    return (
        <div className="my-12">
            <div className="bg-white max-w-[1035px] mx-auto">

                <FormHead
                    formName={formName}
                />
                {children}



            </div>


        </div>

    )
}

export default GeneralFormLayout