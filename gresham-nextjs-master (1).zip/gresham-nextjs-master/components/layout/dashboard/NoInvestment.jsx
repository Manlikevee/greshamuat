

const NoInvestment = () => {
    return (
        <div className="grid place-content-center h-40 text-center gap-4">
            <h2 className="text-2xl font-bold">No Active Investment</h2>
            <p className="text-black/60">You do not have any active investment at the moment. <br /> To add a new investment use the Add Investment button
            </p>
        </div>
    )
}

export default NoInvestment