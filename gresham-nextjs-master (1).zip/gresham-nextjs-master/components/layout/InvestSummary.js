import React from 'react'
import { Button } from '../ui/Button'

const InvestSummary = ({
    investType,
    onClick,
    children, }) => {
    return (
        <div>
            <div className="p-4 pb-8 md:px-12 investSummary">
                <div className="pb-4 border-b border-black/5">
                    <h1 className='font-bold text-lg'>Investment Information</h1>
                </div>

                <div className="mt-6 mb-10">
                    <p className='mb-6 text-black/60'>This investment summary page provides you with a clear overview of the {investType} investment details, including the investor's information, investment terms, calculated interest, and total maturity amount. Users can confirm or cancel their booking based on their preferences.</p>

                    <ul className='grid gap-4 mb-8 '>
                        <li>Product Type - <span className="text-baseblue">{investType}</span>
                        </li>
                        <>
                            {children}
                        </>
                    </ul>

                    <div>
                        <p className='text-black/60'>By confirming your investment booking, you agree to the <span className="text-red-500"> terms and conditions </span> outlined above. Click the <span className='font-semibold' > "Confirm Booking" </span> button below to proceed with the investment.</p>
                    </div>

                </div>
                <div className="">
                    <Button
                        onClick={onClick}
                        className={"w-full font-bold sm:max-w-40 sm:ml-auto"}
                    >
                        Confirm
                    </Button>
                </div>

            </div>

        </div>
    )
}

export default InvestSummary