import Link from "next/link"


export const Button = ({ onClick, children, type, className }) => {


    return (
        <button className={`${type === "transparent"
            ? "bg-transparent text-baseblue hover:bg-[#219ecc33] border border-baseblue hover:border-transparent "
            : type === "white"
                ? "bg-white text-baseblue hover:bg-baseblue hover:text-white"
                : type === "black"
                    ? 'bg-black/80 text-white py-2 px-4 rounded-lg'
                    : "bg-baseblue text-white hover:bg-[#0d81ac]"} rounded-lg ${className} flex gap-2  transition-all justify-center items-center px-6 py-4`}
            onClick={onClick}>
            {children}
        </button>

    )
}

export const LinkButton = ({ path, children, type, className }) => {
    return (
        <div  >
            <Link
                className={`${type === "transparent"
                    ? "bg-transparent text-baseblue hover:bg-[#219ecc33] border border-baseblue hover:border-transparent "
                    : type === "white"
                        ? "bg-white text-baseblue hover:bg-baseblue hover:text-white"
                        : "bg-baseblue text-white hover:bg-[#0d81ac]"} rounded-lg ${className} flex gap-2  transition-all justify-center items-center px-6 py-4`}
                href={path}>
                {children}
            </Link>
        </div>

    )
}

