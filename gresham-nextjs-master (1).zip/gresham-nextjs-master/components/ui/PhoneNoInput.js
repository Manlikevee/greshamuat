import 'react-phone-number-input/style.css'
import PhoneInput from 'react-phone-number-input'

const PhoneNoInput = ({ value, onChange, className, placeholder }) => {
    return (
        <PhoneInput
            placeholder={placeholder}
            value={value}
            onChange={onChange}
            className={`${className} phoneNoInput`}
            defaultCountry='NG'

        />
    )
}

export default PhoneNoInput