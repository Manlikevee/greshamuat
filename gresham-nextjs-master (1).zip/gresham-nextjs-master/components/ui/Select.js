import { useEffect, useRef, useState } from "react";
import { MdOutlineArrowDropDown } from "react-icons/md";

const Select = ({ placeholder, options, onSelect, id, onClick, activeId, selected, resetSelect, setResetSelect }) => {
    const [dropDownOpen, setdropDownOpen] = useState(false)
    const [selectedItem, setSelectedItem] = useState(selected || placeholder)
    const [selectedIndex, setSelectedIndex] = useState(0)
    const selectItemRef = useRef([])
    const itemList = useRef()
    const selectOptions = useRef()



    useEffect(() => {

        const reset = () => {
            setSelectedItem(placeholder)
            onSelect("")
            setResetSelect(false)

        }
        resetSelect && reset()

    }, [resetSelect])


    // when an item is selected on the list set the focus back to the selected button

    const returnFocus = () => {
        itemList.current.focus()
    }


    const selectItemFromList = (e) => {
        if (e.key === 'ArrowDown' && dropDownOpen) {
            e.preventDefault()
            selectItemRef.current[0]?.focus()
        }
        if (e.key === 'ArrowUp' && dropDownOpen) {
            e.preventDefault()
            selectItemRef.current[0]?.focus()
        }
    }

    useEffect(() => {
        setSelectedIndex(0)
    }, [dropDownOpen])

    const handleSelectItem = (item, index) => {
        setSelectedItem(item),
            returnFocus(),
            setSelectedIndex(index),
            setdropDownOpen(false),
            onSelect(item)
    };



    const handleKeydown = (e) => {

        e.stopPropagation()
        if (e.key === 'ArrowDown') {
            e.preventDefault()
            if (selectedIndex < options.length - 1) {
                selectItemRef.current[selectedIndex + 1].focus()
                setSelectedIndex((prev) => (prev + 1))
            }
        }
        else if (e.key === 'ArrowUp') {
            e.preventDefault()

            if (selectedIndex > 0) {
                selectItemRef.current[selectedIndex - 1].focus()
                setSelectedIndex((prev) => (prev - 1))
            }
        }

    }

    const handleEnterKeyPress = (e) => {
        if (e.key === "Enter") {
            e.preventDefault()

            selectItemRef.current[selectedIndex].click()
            setdropDownOpen(false)

        }
    }
    const handleSelectToggle = () => {
        setdropDownOpen(true);
        onClick();
    };


    const [position, setPosition] = useState('bottom')


    useEffect(() => {
        const handleScroll = () => {
            if (selectItemRef.current && selectOptions.current) {
                const buttonRect = itemList.current.getBoundingClientRect();
                const viewportHeight = window.innerHeight;
                const switchPosition = buttonRect.bottom + selectOptions.current.offsetHeight;

                if (switchPosition > viewportHeight) {
                    setPosition('top')
                } else {
                    setPosition('bottom')
                }
            }
        }
        handleScroll()

        window.addEventListener('scroll', handleScroll)

        return () => {
            window.removeEventListener('scroll', handleScroll)
        }
    }, [itemList, selectOptions, dropDownOpen]);

    return (
        <div className="relative ">


            <button
                id={id}
                ref={itemList}
                aria-expanded={dropDownOpen}
                aria-controls={`${id}-dropdown`}
                onClick={handleSelectToggle}
                className="flex justify-between w-full p-4 focus:outline focus:outline-2 focus:outline-baseblue bg-[#f6f6f6] rounded-md cursor-pointer text-gray-500 text-sm"
                onKeyDown={selectItemFromList}
            >
                <span className="pointer-events-none text-black ">
                    {selectedItem}
                </span>
                <MdOutlineArrowDropDown />
            </button>

            {activeId === id && (
                dropDownOpen && <ul
                    ref={selectOptions}
                    className={`grid selectDropDown  max-h-[15rem] overflow-y-auto gap-2 p-2 h-fit bg-[#fcfcfc]  shadow-[0_0_10px_rgba(0,0,0,0.2)] absolute w-full left-0 z-10 rounded-md  text-gray-500 ${position === 'top' ? 'bottom-[3.8rem]' : 'top-14'}`}>
                    {/* <li ref={(ref) => { selectItemRef.current[0] = ref }}
                        tabIndex={0}
                        className="cursor-pointer bg-gray-300/10 hover:bg-gray-500 rounded-md hover:text-white transition-[all_0.25s_ease-in-out] px-3 py-2 outline-0 focus:bg-gray-500 focus:text-white"

                        onClick={() => {
                            handleSelectItem("Others", 0)
                        }}
                        onKeyDown={(e) => { handleKeydown(e), handleEnterKeyPress(e) }}
                    >
                        Others
                    </li> */}
                    {options.map((item, index) => {

                        return (
                            <li ref={(ref) => { selectItemRef.current[index] = ref }}
                                tabIndex={0}
                                className="cursor-pointer bg-gray-300/10 hover:bg-gray-500 rounded-md hover:text-white transition-[all_0.25s_ease-in-out] px-3 py-2 outline-0 focus:bg-gray-500 focus:text-white"
                                key={index}
                                onClick={() => {
                                    handleSelectItem(item, index)
                                }}
                                onKeyDown={(e) => { handleKeydown(e), handleEnterKeyPress(e) }}
                            >
                                {item}
                            </li>
                        )
                    })}


                </ul>
            )

            }


        </div >
    )
}

export default Select