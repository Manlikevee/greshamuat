import { styles } from "@/utils/constants"
import Select from "./Select"
import PhoneNoInput from "./PhoneNoInput"
import DateInput from "./DateInput"



export const SelectField = ({ options, onSelect, onClick, activeId, selected, reset, setReset, errorMsg, label, placeholder, id }) => {
    return (
        <div className={styles.inputFieldStyle}>
            <small className={styles.small}>{label} <span className={styles.red}>*</span></small>
            <Select
                placeholder={placeholder}
                options={options}
                onSelect={onSelect}
                id={id}
                onClick={onClick}
                activeId={activeId}
                selected={selected}
                resetSelect={reset}
                setResetSelect={setReset}
            />
            <small className="text-red-500 pl-1 absolute bottom-[-18px]">{errorMsg}</small>
        </div>
    )
}

export const AddressField = ({ onChange, value, errorMsg, name, label }) => {
    return (
        <div className={`${styles.inputFieldStyle} h-[7rem] sm:col-span-2`}>
            <label className={styles.small}>{label}<span className={styles.red}>*</span></label>
            <textarea
                className={styles.inputStyle}
                onChange={onChange}
                name={name}
                id="" value={value}>
            </textarea>

            <small className="text-red-500 pl-1 absolute bottom-[-18px]">{errorMsg}</small>

        </div>

    )
}

export const TextInputField = ({ onChange, value, errorMsg, name, label, readOnly, placeholder, maxLength }) => {
    return (
        <div className={styles.inputFieldStyle}>
            <label className={styles.small}>{label} <span className={styles.red}>*</span></label>
            <input
                className={styles.inputStyle}
                name={name}
                readOnly={readOnly}
                onChange={onChange}
                type="text"
                placeholder={placeholder}
                value={value}
                maxLength={maxLength}
            />

            <small className="text-red-500 pl-1 absolute bottom-[-18px]">{errorMsg}</small>

        </div>

    )
}

export const PhoneNoField = ({ value, onChange, errorMsg }) => {
    return (
        <div className={styles.inputFieldStyle}>
            <label className={styles.small}>Phone number</label>
            <PhoneNoInput
                placeholder={"Enter Phone No"}
                value={value}
                className={styles.inputStyle}
                onChange={onChange}

            />

            <small className="text-red-500 pl-1 absolute bottom-[-18px]">{errorMsg}</small>
        </div>
    )
}

export const DateField = ({ label, selected, onCalendarClose, onChange, readOnly, errorMsg }) => {
    return (
        <div className={styles.inputFieldStyle}>
            <small className={styles.small}> {label}<span className={styles.red}>*</span></small>
            <DateInput
                selected={selected}
                onCalendarClose={onCalendarClose}
                onChange={onChange}
                readOnly={readOnly}
            />
            <small className="text-red-500 pl-1 absolute bottom-[-18px]">{errorMsg}</small>

        </div>
    )
}

export const EmailField = ({ onChange, value, errorMsg, readOnly, name }) => {
    return (
        <div className={styles.inputFieldStyle}>
            <label className={styles.small}>Email Address<span className={styles.red}>*</span></label>
            <input
                className={styles.inputStyle}
                name={name}
                readOnly={readOnly}
                onChange={onChange}
                type="text"
                placeholder="Enter Email Address"
                value={value}
            />

            <small className="text-red-500 pl-1 absolute bottom-[-18px]">{errorMsg}</small>

        </div>

    )
}