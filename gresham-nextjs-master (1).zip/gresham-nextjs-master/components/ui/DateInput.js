"use client"

import DatePicker from "react-datepicker"
import "react-datepicker/dist/react-datepicker.css";


const DateInput = ({
    selected,
    className,
    onCalendarClose,
    onChange,
    DateName,
    readOnly
}) => {
    return (
        <DatePicker
            name={DateName}
            showIcon
            selected={selected}
            className={className}
            onCalendarClose={onCalendarClose}
            onChange={onChange}
            dateFormat={"dd/MM/yyyy"}
            readOnly={readOnly}
        />
    )
}

export default DateInput