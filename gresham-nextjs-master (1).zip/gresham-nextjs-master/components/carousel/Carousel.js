"use client"

import { Swiper, SwiperSlide } from 'swiper/react'
import 'swiper/css';
import 'swiper/css/pagination';
import 'swiper/css/navigation';
import { Autoplay, Pagination, Navigation } from 'swiper/modules';


export const Carousel = ({ slides, renderSlide }) => {
    return (
        <div className='carousel'>
            <Swiper

                spaceBetween={30}
                navigation={true}
                freeMode={true}
                pagination={{
                    clickable: true,
                }}
                breakpoints={{
                    0: {
                        slidesPerView: 1,
                        spaceBetween: 10,
                    },
                    640: {
                        slidesPerView: 2,
                        spaceBetween: 10,

                    },
                    1280: {
                        slidesPerView: 3,
                        spaceBetween: 10,

                    },

                }}
                modules={[Pagination, Navigation]}
                className="mySwiper"
            >
                {
                    slides.map((card, index) => (
                        <SwiperSlide key={index}>
                            {renderSlide(card, index) || ""}
                        </SwiperSlide>

                    ))
                }

            </Swiper>
        </div>
    )
}

export const AutoPlayCarousel = ({ slides, children }) => {
    return (
        <Swiper
            spaceBetween={30}
            centeredSlides={true}
            autoplay={{
                delay: 2500,
                disableOnInteraction: false,
            }}
            pagination={{
                clickable: true,
            }}
            navigation={true}
            modules={[Autoplay, Navigation]}
            className="autoplayswiper"
        >
            {
                slides?.map((card, index) => (
                    <SwiperSlide key={index}>
                        {card}
                    </SwiperSlide>

                ))
            }
        </Swiper>
    )
}