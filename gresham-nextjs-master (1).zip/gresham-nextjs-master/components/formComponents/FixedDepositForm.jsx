"use client"

import { Button } from "../ui/Button"
import { useEffect, useRef, useState } from "react"
import { addDays } from "date-fns"
import { useFormData } from "@/hooks/useStore"
import DateInput from "../ui/DateInput"
import { useRouter } from "next/navigation"
import { formatString } from "@/utils/FormatString"
import { userFormData } from "@/hooks/useFormData"


const styles = {
    inputFieldStyle: "grid gap-2  relative content-end",
    inputStyle: "grid gap-2 relative content-start bg-[#f6f6f6] p-4 rounded-md outline-baseblue",
    inputStyleNoEdit: "grid gap-2 relative p-4 rounded-md outline-baseblue content-start bg-[#f6f6f6] pointer-events-none",
    noEdit: "pointer-events-none",
    red: "text-red-500 text-xl",
    small: "text-[#737373/80]"
}




const FixedDepositForm = ({ formData, setFormData, startDate, setStartDate }) => {


    // const [startDate, setStartDate] = useState(new Date())
    const [errMsg, setErrmsg] = useState('')
    const investAmount = useRef()



    useEffect(() => {
        investAmount.current.focus()
    }, [])

    const handleChange = (e) => {
        const inputValue = e.target.value.replace(/[^0-9]/g, "")

        setFormData((prev) => ({
            ...prev,
            [e.target.name]: Number(inputValue)
        }))

        console.log(formData)
    }



    useEffect(() => {

        const payableInterest = ((Number(formData?.amount) * formData?.interestRate * formData?.tenor) / (360 * 100)) || 0
        const payableAtMaturity = formData?.amount + payableInterest || 0
        console.log(payableInterest)

        setFormData((prev) => ({
            ...prev,
            effectiveDate: startDate,
            tenor: 140,
            maturityDate: addDays(startDate, 140),
            payableInterest: payableInterest.toFixed(2) || 0,
            payableAtMaturity: payableAtMaturity.toFixed(2) || 0,
        }))

    }, [formData?.amount])

    const router = useRouter()
    const validate = () => {
        if (!formData.amount) {
            setErrmsg("This field is required")
        } else {
            setErrmsg("")
            router.push("/investment/new/summary")

        }
    }

    return (
        <div className="p-4 pb-8 md:px-12">

            <div className="pb-4 pointer-events-none border-b mb-4 border-[#0000000d]">
                <h1 className="text-xl font-semibold text-black/60">Investment Information </h1>
            </div>

            <div className="grid gap-6 md:gap-x-14 sm:grid-cols-2">
                <div className={styles.inputFieldStyle}>
                    <small className={styles.small}>Investment Amount <span className={styles.red}>*</span></small>
                    <div className="investAmount relative w-full">
                        <input
                            ref={investAmount}
                            onChange={(e) => { handleChange(e), setErrmsg("") }}
                            value={formData?.amount?.toLocaleString("en-Us") || ""}
                            name="amount"
                            type="text"
                            placeholder="0.00"
                            className={`pl-8 w-full ${styles.inputStyle}`}
                        />

                    </div>
                    <p className="text-red-500 absolute -bottom-[20px] text-sm pl-1">{errMsg}</p>

                </div>

                <div className={styles.inputFieldStyle}>
                    <small className={styles.small}>Effective Date</small>

                    <DateInput
                        selected={startDate}
                        className={styles.noEdit}
                        // onCalendarClose={updateData}
                        onChange={(date) => { setStartDate(date) }}
                    />

                </div>

                <div className={styles.inputFieldStyle}>
                    <small className={styles.small}>Tenor</small>
                    <input
                        className={styles.inputStyleNoEdit}
                        readOnly
                        name="tenor"
                        type="text"
                        inputMode="number"
                        value={`${formData?.tenor} days`}
                        placeholder="Tenor in days" />
                </div>

                <div className={styles.inputFieldStyle}>
                    <small className={styles.small}>Interest Rate</small>
                    <input
                        className={styles.inputStyleNoEdit}
                        name="rate"
                        type="text"
                        value={`${formData?.interestRate}%`}
                        readOnly

                    />
                </div>

                <div className={styles.inputFieldStyle}>
                    <small className={styles.small}>Maturity Date</small>
                    <DateInput
                        name="maturityDate"
                        className={styles.noEdit}
                        selected={formData?.maturityDate} />
                </div>

                <div className={styles.inputFieldStyle}>
                    <small className={styles.small}>Interest Payable at Maturity</small>
                    <input
                        className={styles.inputStyleNoEdit}
                        value={`₦ ${formatString(formData?.payableInterest)}`}
                        name="payableInterest"
                        type="text"
                        inputMode="number"
                        placeholder="N 0.00"
                        readOnly
                    />

                </div>

                <div className={styles.inputFieldStyle}>
                    <small className={styles.small}>Total Payable at Maturity</small>
                    <input
                        className={styles.inputStyleNoEdit}
                        value={`₦ ${formatString(formData?.payableAtMaturity)}`}
                        name="payableAmount"
                        type="text"
                        readOnly
                    />
                </div>
            </div>

            <div className="w-full mt-6 font-semibold">
                {


                    <Button
                        onClick={validate}
                        className={`w-full sm:ml-auto cursor-pointer sm:w-[150px]`}
                    >
                        Next
                    </Button>
                }



            </div>

        </div>
    )
}

export default FixedDepositForm