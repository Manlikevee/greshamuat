import bngo from "@/assets/Bionano.png"
import access from "@/assets/Access.png"
import aapl from "@/assets/Aapl.png"
import intc from "@/assets/Intc.png"
import gevo from "@/assets/Gevo.png"
import fcel from "@/assets/Fcel.png"

export const BalanceCardNames = ["Total Investment Balance", "Total Cash Balance", "Total Number of Investment"]

export const accountCard = [
    {
        name: "Fixed Deposit",
        acctNo: "346577782",
        principal: "10,000,000.00",
        maturityDate: "12/04/2023",
        interestRate: "16%"
    },
    {
        name: "Treasury Bills",
        acctNo: "346577782",
        principal: "10,000,000.00",
        maturityDate: "12/04/2023",
        interestRate: "10%"
    },
    {
        name: "Fixed Deposit",
        acctNo: "346577782",
        principal: "10,000,000.00",
        maturityDate: "12/04/2023",
        interestRate: "10%"
    },
    {
        name: "Commercial Paper",
        acctNo: "346577782",
        principal: "10,000,000.00",
        maturityDate: "12/04/2023",
        interestRate: "10%"
    },
]

export const bonds = [
    {
        image: bngo,
        name: "BNGO",
        company: "Bionano Genomic Inc.",
        value: 12.50,
        rate: 18,
    },
    {
        image: access,
        name: "ACCESSCORP",
        company: "Access Holdings PLC",
        value: 12.50,
        rate: 10,
    },
    {
        image: aapl,
        name: "AAPL",
        company: "Apple Inc",
        value: 12.50,
        rate: 90,
    },
    {
        image: intc,
        name: "INTC",
        company: "Intel Corp",
        value: 12.50,
        rate: 6,
    },
    {
        image: gevo,
        name: "GEVO",
        company: "Gevo Inc",
        value: 12.50,
        rate: 5,
    }, {
        image: aapl,
        name: "AAPL",
        company: "Apple Inc",
        value: 12.50,
        rate: 19,
    },
    {
        image: access,
        name: "ACCESSCORP",
        company: "Access Holdings PLC",
        value: 12.50,
        rate: 10,
    },
    {
        image: fcel,
        name: "FCEL",
        company: "Fuelcell Energy Inc",
        value: 12.50,
        rate: 10,
    },
    {
        image: bngo,
        name: "BNGO",
        company: "Bionano Genomic Inc.",
        value: 12.50,
        rate: 19,
    }, {
        image: access,
        name: "ACCESSCORP",
        company: "Access Holdings PLC",
        value: 12.50,
        rate: 13,
    },

]

export const treasury = [
    {
        name: "Digital Capital Group Limited",
        rate: 16.7,
        yield: 17.67,
        maturity: "22 Aug 2024"
    },
    {
        name: "Fidson Healthcare Commercial Papers",
        rate: 16.7,
        yield: 17.67,
        maturity: "22 Aug 2024"
    },
    {
        name: "Nigeria Treasury Bills-115 Days",
        rate: 16.7,
        yield: 17.67,
        maturity: "22 Aug 2024"
    },
    {
        name: "Nigeria Treasury Bills-150 Days",
        rate: 16.7,
        yield: 17.67,
        maturity: "22 Aug 2024"
    },
    {
        name: "Nigeria Treasury Bills-120 Days",
        rate: 16.7,
        yield: 17.67,
        maturity: "22 Aug 2024"
    },
    {
        name: "Digital Capital Group Limited",
        rate: 16.7,
        yield: 17.67,
        maturity: "22 Aug 2024"
    },
    {
        name: "Nigeria Treasury Bills-89 Days",
        rate: 16.7,
        yield: 17.67,
        maturity: "22 Aug 2024"
    },
]


export const investmentInstruments = {
    bonds: [
        {
            name: "BNGO",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "Bonds"
        },
        {
            name: "BNGO",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "Bonds",

        },
        {
            name: "BNGO",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "Bonds"

        },
        {
            name: "BNGO",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "Bonds"

        },
        {
            name: "BNGO",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "Bonds"

        },
        {
            name: "BNGO",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "Bonds"

        },
        {
            name: "BNGO",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "Bonds"

        },
    ],
    bills: [
        {
            name: "Nigeria Treasury Bills-120 Days",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "Treasury Bills"

        },
        {
            name: "Nigeria Treasury Bills-120 Days",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "Treasury Bills"

        },
        {
            name: "Nigeria Treasury Bills-120 Days",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "Treasury Bills"

        },
        {
            name: "Nigeria Treasury Bills-120 Days",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "Treasury Bills"

        },
        {
            name: "Nigeria Treasury Bills-120 Days",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "Treasury Bills"

        },
        {
            name: "Nigeria Treasury Bills-120 Days",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "Treasury Bills"

        },
        {
            name: "Nigeria Treasury Bills-120 Days",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "Treasury Bills"

        },

    ],
    greshambills: [
        {
            name: "Digital Capital Group Limited",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "Gresham Bills"

        },
        {
            name: "Digital Capital Group Limited",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "Gresham Bills"

        },
        {
            name: "Digital Capital Group Limited",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "Gresham Bills"

        },
        {
            name: "Digital Capital Group Limited",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "Gresham Bills"

        },
        {
            name: "Digital Capital Group Limited",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "Gresham Bills"

        },
        {
            name: "Digital Capital Group Limited",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "Gresham Bills"

        },
        {
            name: "Digital Capital Group Limited",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "Gresham Bills"

        },

    ],
    greshamBonds: [
        {
            name: "ACCESSCORP",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "Gresham Bonds"

        },
        {
            name: "ACCESSCORP",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "Gresham Bonds"

        },
        {
            name: "ACCESSCORP",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "Gresham Bonds"

        },
        {
            name: "ACCESSCORP",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "Gresham Bonds"

        },
        {
            name: "ACCESSCORP",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "Gresham Bonds"

        },
        {
            name: "ACCESSCORP",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "Gresham Bonds"

        },
        {
            name: "ACCESSCORP",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024"
            , productType: "Gresham Bonds"

        },

    ],
    cps: [
        {
            name: "Fidson Healthcare Commercial Papers",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "CPs"

        },
        {
            name: "Fidson Healthcare Commercial Papers",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "CPs"

        },
        {
            name: "Fidson Healthcare Commercial Papers",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "CPs"

        },
        {
            name: "Fidson Healthcare Commercial Papers",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "CPs"

        },
        {
            name: "Fidson Healthcare Commercial Papers",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "CPs"

        },
        {
            name: "Fidson Healthcare Commercial Papers",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "CPs"

        },
        {
            name: "Fidson Healthcare Commercial Papers",
            rate: 16.7,
            yield: 17.67,
            maturity: "22 Aug 2024",
            productType: "CPs"

        },

    ],


}