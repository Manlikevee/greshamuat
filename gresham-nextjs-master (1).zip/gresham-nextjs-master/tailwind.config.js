/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      padding: {
        inline: 'var(--padding-inline)',
      },
      colors: {
        baseblue: "#219ecc",
        basered: "#cb3532"
      },
      screens: {
        sm: '480px'
      }
    },
  },
  plugins: [],
};
