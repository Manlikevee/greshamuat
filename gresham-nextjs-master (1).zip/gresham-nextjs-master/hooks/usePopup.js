
import { useContext } from "react"
import { PopUpContext } from "@/context/PopUpContext"



const usePopup = () => {
    const { popupOpen, setPopupOpen } = useContext(PopUpContext)

    const openPopup = () => {
        setPopupOpen(true)
        document.body.classList.add('h-[dvh]', 'overflow-hidden', 'bg-red')
    }

    const closePopup = () => {
        setPopupOpen(false)
        document.body.classList.remove('h-[dvh]', 'overflow-hidden', 'bg-red')
        window.scrollTo(0, 0)
    }



    return {
        popupOpen,
        openPopup,
        closePopup,
        setPopupOpen
    }
}

export default usePopup