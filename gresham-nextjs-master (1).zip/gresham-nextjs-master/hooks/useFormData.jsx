"use client"

import { useEffect, useState } from "react"

export const useFormData = () => {
    const [formData, setFormData] = useState(null)
    const [mount, setMount] = useState(false)

    useEffect(() => {
        const data = JSON.parse(sessionStorage.getItem("formData"))
        if (data) {
            setFormData(data)
        }
    }, [])


    useEffect(() => {
        if (mount === true) {
            sessionStorage.setItem("formData", JSON.stringify(formData))
        } else {
            setMount(true)
        }
    }, [formData])

    return { formData, setFormData }
}