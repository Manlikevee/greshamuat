import { SignupContext } from "@/context/SignupContext"
import { useContext } from "react"


const useSignupData = () => {
    const { signupData, setSignupData } = useContext(SignupContext)

    return {
        signupData, setSignupData
    }
}

export default useSignupData






