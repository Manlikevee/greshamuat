import { useEffect, useState } from "react"

const useActiveUserData = () => {
    const [activeUserData, setActiveUserData] = useState(JSON.parse(localStorage.getItem('userData')) || [])

    useEffect(() => {
        sessionStorage.setItem('userData', JSON.stringify(userData))
    }, [activeUserData])

    return { activeUserData, setActiveUserData }
}

export default useActiveUserData