"use client"
import { useContext, useEffect, useState } from "react"
import { DataStoreContext } from "@/context/DataStoreContext"





export const useFormName = () => {
    const { formName, setFormName } = useContext(DataStoreContext)

    return { formName, setFormName }
}




export const useActiveUser = () => {
    const [user, setUser] = useState(null);

    useEffect(() => {
        // Check if we're in a browser environment
        if (typeof window !== 'undefined') {
            const userData = localStorage.getItem("user");
            if (userData) {
                setUser(JSON.parse(userData)); // Update state with user info
                console.log(userData)
            } else {
                setUser({}); // Fallback to an empty object if no user is found
            }
        }
    }, []); // Run effect only once when component mounts

    return { user }; // Return user info
};