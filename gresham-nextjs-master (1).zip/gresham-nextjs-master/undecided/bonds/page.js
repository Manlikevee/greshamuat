"use client"
import BondsCard from '@/components/cards/BondsCard'
import InvestHead from '@/components/layout/InvestHead'
import { bonds } from '@/data/data'
import { useFormData } from '@/hooks/useStore'

const Bonds = () => {

    const { setStoredData } = useFormData()
    return (
        <div>
            <InvestHead
                investName={"Bonds View"}
                investType={"Bonds"}
                searchHolder={"Search the list of available bonds by name..."}

            />
            <div className='grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:flex xl:flex-wrap gap-4 my-16'>
                {
                    bonds.map((card, index) => {
                        const BondData = {
                            productName: "Fixed Deposit",
                            productType: "Fixed Deposit",
                            value: card.value,
                            interestRate: card.rate
                        }

                        return (
                            <BondsCard
                                onClick={() => { setStoredData(BondData) }}
                                key={index}
                                bondImg={card.image}
                                bondCompany={card.company}
                                bondName={card.name}
                                value={card.value}
                                rate={card.rate}
                                LinkTo={'/investment/bonds/fixedDeposit'}

                            />
                        )

                    })
                }

            </div>
        </div>
    )
}

export default Bonds