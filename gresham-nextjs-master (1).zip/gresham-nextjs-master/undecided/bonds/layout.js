"use client"

import React, { useState } from "react"


const BondLayout = ({ children }) => {


    return (

        <div>

            {children}

        </div>

    )
}

export default BondLayout