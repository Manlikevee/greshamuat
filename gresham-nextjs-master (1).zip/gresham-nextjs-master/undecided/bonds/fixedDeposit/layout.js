import GeneralFormLayout from "@/components/layout/form/GeneralFormLayout"
import FormHead from "@/components/layout/FormHead"
import { useFormName } from "@/hooks/useStore"


const FixedDepositLayout = ({ children }) => {
    return (
        <GeneralFormLayout formName={"Fixed Deposit"}>
            {children}
        </GeneralFormLayout>

    )
}

export default FixedDepositLayout