

import FixedDepositForm from "@/components/formComponents/FixedDepositForm"


const fixedDeposit = () => {


    return (
        <FixedDepositForm />
    )
}

export default fixedDeposit