"use client"

import FormHead from "@/components/layout/FormHead"



const TreasuryLayout = ({ children }) => {


    return (

        <div >


            {children}





        </div>

    )
}

export default TreasuryLayout