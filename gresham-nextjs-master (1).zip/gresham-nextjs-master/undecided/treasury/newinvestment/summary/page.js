"use client"
import InvestSummary from "@/components/layout/InvestSummary"
import { SuccessModal } from "@/components/modals/Modal"
import usePopup from "@/hooks/usePopup"
import { useFormData } from "@/hooks/useStore"
import { formatDate, formatString } from "@/utils/FormatString"

const FixedDepositSummary = () => {
    const { storedData } = useFormData()
    const { popupOpen, openPopup, closePopup } = usePopup()
    console.log(storedData)

    console.log(storedData)


    return (

        <>
            <InvestSummary investType={storedData?.productType} onClick={() => { openPopup() }}>
                <li>Principal - <span className="text-baseblue">N {formatString(storedData?.amount)}</span></li>
                <li>Tenure - <span className="text-baseblue">{storedData?.tenor} days</span></li>
                <li>Interest Rate - <span className="text-baseblue">{storedData?.interestRate}%</span></li>
                <li>Yield - <span className="text-baseblue">{storedData?.yield}%</span></li>
                <li>Maturity Date - <span className="text-baseblue"> {formatDate(storedData?.maturityDate, '-')} </span></li>
                <li>Total Payable at Maturity - <span className="text-baseblue"> N {formatString(storedData?.payableAtMaturity)}</span></li>
            </InvestSummary>


            {
                popupOpen && < SuccessModal
                    message={"Your Investment request for a New Investment was successfully submitted. "}
                    header={"Successful"}
                    path={"/"}
                    clickFunc={() => { closePopup() }}
                />
            }



        </>

    )
}

export default FixedDepositSummary