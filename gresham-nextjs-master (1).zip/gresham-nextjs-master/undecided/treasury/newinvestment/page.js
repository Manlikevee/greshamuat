"use client"
import { Button } from "@/components/ui/Button"
import DateInput from "@/components/ui/DateInput"
import { useFormData } from "@/hooks/useStore"
import { formatString } from "@/utils/FormatString"
import { addDays } from "date-fns"
import { useRouter } from "next/navigation"
import { useEffect, useRef, useState } from "react"

const styles = {
    inputFieldStyle: "grid gap-2 relative content-start",
    inputStyle: "grid gap-2 relative content-start bg-[#f6f6f6] p-4 rounded-md outline-baseblue",
    inputStyleNoEdit: "grid gap-2 relative p-4 rounded-md outline-baseblue content-start bg-[#f6f6f6] pointer-events-none",
    noEdit: "pointer-events-none",
    red: "text-red-500 text-xl",
    small: "text-[#737373/80]",
    errMsg: "text-red-500 text-xs"
}


const newInvestment = () => {
    const [startDate, setStartDate] = useState(new Date())
    const [errMsg, setErrmsg] = useState('')
    const investAmount = useRef()
    const { storedData, setStoredData } = useFormData()

    useEffect(() => {
        investAmount.current.focus()
    }, [])




    const handleChange = (e) => {
        const inputValue = e.target.value.replace(/[^0-9]/g, "")

        setStoredData((prev) => ({
            ...prev,
            [e.target.name]: Number(inputValue)
        }))

    }


    useEffect(() => {
        const payableInterest = (Number(storedData?.amount) * storedData?.interestRate * storedData?.tenor) / (360 * 100)
        const payableAtMaturity = Number(storedData?.amount) + payableInterest || 0


        setStoredData((prev) => ({
            ...prev,
            payableInterest: payableInterest.toFixed(2),
            payableAtMaturity: payableAtMaturity.toFixed(2),
            tenor: 140,
            maturityDate: addDays(startDate, 140),
        }))



    }, [storedData?.amount])

    const router = useRouter()
    const validate = () => {
        if (!storedData.amount) {
            setErrmsg("This field is required")
        } else {
            setErrmsg("")
            router.push("newinvestment/summary")

        }
    }


    return (
        <div className="p-4 pb-8 md:px-12">
            <div className="pb-4 pointer-events-none border-b mb-4 border-[#0000000d]">
                <h1 className="text-xl font-semibold mb-2 text-black/60">Treasury Bills (Digital Capital Group Limited)</h1>
                <p className="minimumInvestmentText">Minimum investment amount N 100,000. Amount must be multiples of N100, Rates are applicable between 11am-2:30pm Nigerian time</p>
            </div>

            <div className="grid gap-6 md:gap-x-14 sm:grid-cols-2">

                <div className={styles.inputFieldStyle}>
                    <small className={styles.small}>Investment Amount <span className={styles.red}>*</span></small>
                    <div className="investAmount relative w-full">
                        <input
                            ref={investAmount}
                            onChange={(e) => { handleChange(e), setErrmsg("") }}
                            value={storedData?.amount?.toLocaleString("en-Us") || ""}
                            name="amount"
                            type="text"
                            placeholder="0.00"
                            className={`pl-8 w-full ${styles.inputStyle}`}
                        />

                    </div>
                    <p className="text-red-500 absolute -bottom-[20px] text-sm pl-1">{errMsg}</p>

                </div>

                <div className={styles.inputFieldStyle}>
                    <small className={styles.small}>Rate</small>
                    <input
                        className={styles.inputStyle}
                        type="text"
                        readOnly
                        placeholder="16.7%"
                        value={`${storedData?.interestRate}%`}
                    />
                </div>
                <div className={styles.inputFieldStyle}>
                    <small className={styles.small}>Yield</small>
                    <input
                        className={styles.inputStyle}
                        readOnly
                        type="text"
                        value={`${storedData?.yield}%`}
                        placeholder="28.00%" />
                </div>
                <div className={styles.inputFieldStyle}>
                    <small className={styles.small}>Total Payable at Maturity</small>
                    <input
                        readOnly
                        className={styles.inputStyle}
                        value={`₦ ${formatString(storedData?.payableAtMaturity) || 0}`}
                        type="text"
                        placeholder="Amount to get at maturity (N)" />
                </div>
                <div className={styles.inputFieldStyle}>
                    <small className={styles.small}>Tenure (Days)</small>
                    <input
                        readOnly
                        className={styles.inputStyle}
                        name="tenor"
                        type="text"
                        placeholder="e.g 187"
                        value={`${storedData?.tenor || 0} days`}
                    />

                </div>
                <div className={styles.inputFieldStyle}>
                    <small className={styles.small}>Maturity Date</small>
                    <DateInput
                        name="maturityDate"
                        className="noEdit"
                        selected={storedData?.maturityDate}
                        readOnly={true}

                    />
                </div>


            </div>
            <div className="w-full mt-8  font-semibold">

                <Button
                    onClick={validate}
                    className={`w-full sm:ml-auto cursor-pointer sm:w-[150px]`}
                >
                    Next
                </Button>
            </div>

        </div>
    )
}

export default newInvestment