

import GeneralFormLayout from "@/components/layout/form/GeneralFormLayout"
import FormHead from "@/components/layout/FormHead"



const NewInvestmentLayout = ({ children }) => {


    return (
        { children }
    )
}

export default NewInvestmentLayout