"use client"
import TreasuryCard from "@/components/cards/TreasuryCard"
import InvestHead from "@/components/layout/InvestHead"
import { treasury } from "@/data/data"
import { useFormData } from "@/hooks/useStore"


const Treasury = () => {

    const { setStoredData } = useFormData()

    return (
        <div>
            <InvestHead
                investName={"Treasury Bills"}
                investType={"Treasury Bills"}
                searchHolder={"Search the list of available Treasury bills by name..."}

            />
            <div className="grid gap-4 my-16 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-6">
                {
                    treasury.map((card, index) => {

                        const treasuryData = {
                            productName: "New Investment",
                            productType: "New Investment",
                            yield: card.yield,
                            interestRate: card.rate
                        }


                        return (
                            <TreasuryCard
                                LinkTo={"/investment/treasury/newinvestment"}
                                key={index}
                                name={card.name}
                                rate={card.rate}
                                yieldValue={card.yield}
                                maturity={card.maturity}
                                onClick={() => { setStoredData(treasuryData) }}
                            />
                        )
                    })
                }

            </div>
        </div>

    )
}

export default Treasury